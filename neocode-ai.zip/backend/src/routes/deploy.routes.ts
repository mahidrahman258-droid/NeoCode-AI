import { Router } from 'express';
import { DeployController } from '../controllers/deploy.controller';
import { requireAuth } from '../middleware/auth';

const router = Router();

router.use(requireAuth as any);

router.post('/:projectId/deploy', DeployController.triggerDeployment);
router.get('/:projectId/deployments', DeployController.getProjectDeployments);

export default router;
export { router as DeployRouter };
