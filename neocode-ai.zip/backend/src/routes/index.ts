import { Router } from 'express';
import authRoutes from './auth.routes';
import projectRoutes from './project.routes';
import fileRoutes from './file.routes';
import aiRoutes from './ai.routes';
import execRoutes from './exec.routes';
import deployRoutes from './deploy.routes';

const router = Router();

// Register and namespace all NeoCode modular endpoints
router.use('/auth', authRoutes);
router.use('/projects', projectRoutes);
router.use('/files', fileRoutes);
router.use('/ai', aiRoutes);
router.use('/exec', execRoutes);
router.use('/deploy', deployRoutes);

export default router;
