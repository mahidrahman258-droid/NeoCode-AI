import { Router } from 'express';
import { ExecController } from '../controllers/exec.controller';
import { requireAuth } from '../middleware/auth';

const router = Router();

router.use(requireAuth as any);

router.post('/direct', ExecController.executeDirectly);
router.post('/enqueue', ExecController.enqueueCompileTask);

export default router;
