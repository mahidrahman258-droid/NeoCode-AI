import { Router } from 'express';
import { FileController } from '../controllers/file.controller';
import { requireAuth } from '../middleware/auth';

const router = Router();

router.use(requireAuth as any);

router.post('/:projectId/nodes', FileController.createFile);
router.get('/:projectId/tree', FileController.getFileTree);
router.put('/nodes/:nodeId', FileController.updateFileContent);

export default router;
