import { Router } from 'express';
import { AiController } from '../controllers/ai.controller';
import { requireAuth } from '../middleware/auth';

const router = Router();

// Streaming endpoint requires token credentials which can be supplied via query headers
router.get('/stream', requireAuth as any, AiController.streamSse);

// Enforce standard bearer tokens for all transactional POST instructions
router.use(requireAuth as any);

router.post('/chat', AiController.chat);
router.post('/autocomplete', AiController.autocomplete);
router.post('/debug', AiController.debug);
router.post('/explain', AiController.explain);
router.post('/refactor', AiController.refactor);
router.post('/ui', AiController.generateUI);
router.post('/backend', AiController.generateBackend);
router.post('/voice', AiController.voiceCoding);
router.post('/nodes/:nodeId/analyze', AiController.analyzeFile);

export default router;
