import { Router } from 'express';
import { ProjectController } from '../controllers/project.controller';
import { requireAuth } from '../middleware/auth';

const router = Router();

router.use(requireAuth as any);

router.post('/', ProjectController.createProject);
router.get('/', ProjectController.listProjects);
router.delete('/:projectId', ProjectController.deleteProject);

export default router;
