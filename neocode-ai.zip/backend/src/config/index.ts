import dotenv from 'dotenv';
import path from 'path';

// Load .env file
dotenv.config({ path: path.resolve(__dirname, '../../.env') });

export const config = {
  env: process.env.NODE_ENV || 'development',
  port: parseInt(process.env.PORT || '5000', 10),
  jwtSecret: process.env.JWT_SECRET || 'neocode-super-secure-cyan-quantum-key-2026',
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '7d',
  mongoUri: process.env.MONGO_URI || 'mongodb://localhost:27017/neocode',
  redisUrl: process.env.REDIS_URL || 'redis://localhost:6379',
  geminiApiKey: process.env.GEMINI_API_KEY || '',
  github: {
    clientId: process.env.GITHUB_CLIENT_ID || '',
    clientSecret: process.env.GITHUB_CLIENT_SECRET || '',
    redirectUri: process.env.GITHUB_REDIRECT_URI || 'http://localhost:5000/api/v1/auth/github/callback',
  },
  sandbox: {
    maxMemoryMb: parseInt(process.env.SANDBOX_MAX_MEMORY_MB || '128', 10),
    timeoutMs: parseInt(process.env.SANDBOX_TIMEOUT_MS || '5000', 10),
  },
};

// Check for critical missing config in production
if (config.env === 'production') {
  if (!process.env.JWT_SECRET) {
    console.warn('WARNING: JWT_SECRET is not set in production. Using insecure default!');
  }
  if (!process.env.MONGO_URI) {
    console.warn('WARNING: MONGO_URI is not set in production. Falling back to localhost!');
  }
  if (!config.geminiApiKey) {
    console.warn('WARNING: GEMINI_API_KEY is not set. Gemini AI functionalities will operate in mock mode.');
  }
}
