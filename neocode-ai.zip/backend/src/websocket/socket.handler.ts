import { Server, Socket } from 'socket.io';
import { CollabService } from '../services/collab.service';
import { SandboxService } from '../services/sandbox.service';
import { AiOrchestrator, AIProvider } from '../services/ai.orchestrator';
import { PromptManager } from '../services/ai.prompt-manager';
import { logger } from '../utils/logger';

export const configureWebSockets = (io: Server) => {
  io.on('connection', (socket: Socket) => {
    logger.info(`New Web Socket connection registered: SocketId=${socket.id}`);

    /**
     * Connects developer to active collaborative project workspace room
     */
    socket.on('join-project', (payload: { roomId: string; projectId: string; userId: string; username: string }) => {
      const { roomId, projectId, userId, username } = payload;
      
      socket.join(roomId);
      
      // Update local cache structures
      CollabService.joinRoom(roomId, projectId, socket.id, userId, username);
      
      // Notify active residents
      socket.to(roomId).emit('user-joined', { socketId: socket.id, username, userId });
      
      // Dispatch current room occupants specs to incoming client
      const members = CollabService.getSerializableMembers(roomId);
      socket.emit('room-members-list', { members });

      logger.info(`Web Socket Room link established: user=${username} RoomId=${roomId}`);
    });

    /**
     * Broadcasts collaborative document adjustments key-for-key across room
     */
    socket.on('code-change', (payload: { roomId: string; filePath: string; delta: any; content: string }) => {
      const { roomId, filePath, delta, content } = payload;
      
      // Propagate edits to alternative developers
      socket.to(roomId).emit('code-change-broadcast', {
        socketId: socket.id,
        filePath,
        delta,
        content,
      });
    });

    /**
     * Propagates real-time cursor mouse tracking
     */
    socket.on('cursor-move', (payload: { roomId: string; cursor: { line: number; ch: number }; filePath?: string }) => {
      const { roomId, cursor, filePath } = payload;
      
      const updatedUser = CollabService.updatePointer(socket.id, cursor, filePath);
      if (updatedUser) {
        socket.to(roomId).emit('cursor-move-broadcast', {
          socketId: socket.id,
          userId: updatedUser.userId,
          username: updatedUser.username,
          cursor,
          filePath,
        });
      }
    });

    /**
     * Triggers dynamic terminal commands and streams outputs asynchronously back to standard client outputs.
     */
    socket.on('terminal-command', async (payload: { command: string; sessionLanguage: string }) => {
      const { command, sessionLanguage } = payload;
      
      logger.info(`Interactive Shell Command received from SocketId=${socket.id}: "${command}"`);

      socket.emit('terminal-output', { text: `\nneocode-sandbox@terminal:~$ ${command}\n` });

      try {
        // Evaluate command safely within Sandbox context
        const execution = await SandboxService.executeCode(command, sessionLanguage);
        
        if (execution.stdout) {
          socket.emit('terminal-output', { text: `${execution.stdout}\n` });
        }
        if (execution.stderr) {
          socket.emit('terminal-output', { text: `[ERROR] ${execution.stderr}\n` });
        }
        
        socket.emit('terminal-output', { text: `Process exited with code ${execution.exitCode} (duration: ${execution.durationMs}ms)\n` });
      } catch (err: any) {
        socket.emit('terminal-output', { text: `Terminal spawn crash: ${err.message}\n` });
      }
    });

    /**
     * REAL-TIME AD-HOC SOCKET AI CHAT STREAMING
     * Streaming response system via WebSockets
     */
    socket.on('ai-chat-stream', async (payload: { prompt: string; provider?: string; model?: string; systemInstruction?: string; imageB64?: string }) => {
      const { prompt, provider = 'gemini', model = 'gemini-3.5-flash', systemInstruction, imageB64 } = payload;
      logger.info(`Socket AI Query stream requested: id=${socket.id}, provider=${provider}, model=${model}`);

      try {
        // Query core AI pipelines
        const result = await AiOrchestrator.query({
          prompt,
          systemInstruction,
          provider: provider as AIProvider,
          model,
          imageB64,
        });

        // Split response into word sequences and stream with fine-grained delay to simulate realtime output
        const chunks = result.text.split(' ');
        let index = 0;

        const interval = setInterval(() => {
          if (index < chunks.length) {
            const batch = chunks.slice(index, index + 3).join(' ') + ' ';
            socket.emit('ai-chat-token', { text: batch, isFinal: false });
            index += 3;
          } else {
            socket.emit('ai-chat-token', { text: '', isFinal: true });
            clearInterval(interval);
          }
        }, 60);

      } catch (err: any) {
        logger.error(`Socket AI transaction failure: ${err.message}`);
        socket.emit('ai-chat-token', { error: `Compiler exception: ${err.message}`, isFinal: true });
      }
    });

    /**
     * REAL-TIME VOICE CODING AUDIO INTERPRETER
     */
    socket.on('ai-voice-coding', async (payload: { transcript: string; activeCode?: string; language?: string }) => {
      const { transcript, activeCode, language = 'kotlin' } = payload;
      logger.info(`Socket AI vocal mapping request received: transcript="${transcript}"`);

      try {
        const { prompt: formattedPrompt, systemInstruction } = PromptManager.getPrompt('voice-coding', {
          code: activeCode,
          additionalContext: transcript,
          language,
        });

        const result = await AiOrchestrator.query({
          prompt: formattedPrompt,
          systemInstruction,
          provider: 'gemini',
          model: 'gemini-3.5-flash',
        });

        socket.emit('ai-voice-response', {
          success: true,
          interpretation: result.text,
        });
      } catch (err: any) {
        logger.error(`Socket Vocal compilation fault: ${err.message}`);
        socket.emit('ai-voice-response', {
          success: false,
          error: err.message,
        });
      }
    });

    /**
     * Gracefully drops socket sessions on exit parameters
     */
    socket.on('disconnect', () => {
      const leaveResult = CollabService.leaveRoom(socket.id);
      
      if (leaveResult) {
        const { roomId, username } = leaveResult;
        socket.to(roomId).emit('user-left', { socketId: socket.id, username });
        logger.info(`Broadcasting user exit: ${username} dropped from Room ${roomId}`);
      }
      
      logger.info(`Web socket disconnected: SocketId=${socket.id}`);
    });
  });
};
