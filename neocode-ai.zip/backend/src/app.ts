import express from 'express';
import { configureSecurity } from './middleware/security';
import apiRoutes from './routes';
import { errorHandler } from './middleware/error';
import { logger } from './utils/logger';

const app = express();

// Assemble CORS header adjustments & Payload weights limits
configureSecurity(app);

// Mount diagnostic health checks
app.get('/health', (req, res) => {
  res.status(200).json({
    status: 'ONLINE',
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
    service: 'NeoCode Core Compiler System',
  });
});

// Bind Master Version 1 API routes
app.use('/api/v1', apiRoutes);

// Catch-all route handler for unspecified endpoints
app.use('*', (req, res, next) => {
  res.status(404).json({
    status: 'error',
    message: `Endpoint ${req.originalUrl} not active on NeoCode Engine.`,
  });
});

// Configure Global Exception limits
app.use(errorHandler);

logger.info('Express App middleware configurations assembled safely.');

export default app;
