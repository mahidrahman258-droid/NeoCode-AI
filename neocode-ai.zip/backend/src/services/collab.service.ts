import { logger } from '../utils/logger';

export interface CollabUser {
  socketId: string;
  userId: string;
  username: string;
  cursor: { line: number; ch: number };
  activeFilePath?: string;
}

export interface CollabRoom {
  roomId: string;
  projectId: string;
  members: Map<string, CollabUser>; // socketId -> CollabUser
}

export class CollabService {
  private static rooms = new Map<string, CollabRoom>();

  /**
   * Links a new developer user socket to an editing room
   */
  public static joinRoom(
    roomId: string,
    projectId: string,
    socketId: string,
    userId: string,
    username: string
  ): CollabRoom {
    logger.info(`Developer ${username} (${userId}) linking to Room ${roomId}`);

    if (!this.rooms.has(roomId)) {
      this.rooms.set(roomId, {
        roomId,
        projectId,
        members: new Map(),
      });
    }

    const room = this.rooms.get(roomId)!;
    room.members.set(socketId, {
      socketId,
      userId,
      username,
      cursor: { line: 0, ch: 0 },
    });

    return room;
  }

  /**
   * Drops a socket session link on disconnection
   */
  public static leaveRoom(socketId: string): { roomId: string; username: string } | null {
    for (const [roomId, room] of this.rooms.entries()) {
      if (room.members.has(socketId)) {
        const user = room.members.get(socketId)!;
        room.members.delete(socketId);
        logger.info(`Developer ${user.username} unlinked from Room ${roomId}`);

        // If room is vacant, clear cache references
        if (room.members.size === 0) {
          this.rooms.delete(roomId);
          logger.info(`Room ${roomId} was vacant. Flushed memory structures.`);
        }

        return { roomId, username: user.username };
      }
    }
    return null;
  }

  /**
   * Tracks real-time pointer coordinate updates
   */
  public static updatePointer(
    socketId: string,
    cursor: { line: number; ch: number },
    activeFilePath?: string
  ): CollabUser | null {
    for (const room of this.rooms.values()) {
      if (room.members.has(socketId)) {
        const user = room.members.get(socketId)!;
        user.cursor = cursor;
        if (activeFilePath) user.activeFilePath = activeFilePath;
        return user;
      }
    }
    return null;
  }

  /**
   * Fetches room properties
   */
  public static getRoom(roomId: string): CollabRoom | undefined {
    return this.rooms.get(roomId);
  }

  /**
   * Returns list of participants in standard JSON formats
   */
  public static getSerializableMembers(roomId: string): any[] {
    const room = this.rooms.get(roomId);
    if (!room) return [];
    return Array.from(room.members.values()).map((m) => ({
      userId: m.userId,
      username: m.username,
      cursor: m.cursor,
      activeFilePath: m.activeFilePath,
    }));
  }
}
