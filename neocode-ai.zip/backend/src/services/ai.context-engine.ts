import { logger } from '../utils/logger';

export interface FileNodeContext {
  name: string;
  path: string;
  isFolder: boolean;
  content?: string;
}

export class ContextEngine {
  private static MAX_FILE_SIZE_CHARS = 40000; // Limit large source logs to ~10k tokens
  private static SLIDING_WINDOW_LINES = 100;   // In autocomplete, fetch only adjacent lines

  /**
   * Trims, token-optimizes, and sanitizes code content before submitting to external AI endpoints
   */
  public static optimizeFileContext(content: string, language: string): string {
    if (!content) return '';

    let optimized = content;

    // 1. If code exceeds length boundaries, truncate and add a warning label to prevent crash
    if (optimized.length > this.MAX_FILE_SIZE_CHARS) {
      logger.warn(`File exceeds max character limits (${content.length} chars). Applying token optimization truncation.`);
      optimized = optimized.slice(0, this.MAX_FILE_SIZE_CHARS) + 
        '\n\n// [... CONTEXT TRUNCATED HERE BY NEO-TOKEN OPTIMIZATION ENGINE to avoid exceeding model context limits ...]';
    }

    // 2. Trim trailing whitespaces line-by-line to reduce unnecessary string tokens
    optimized = optimized
      .split('\n')
      .map((line) => line.trimEnd())
      .join('\n');

    return optimized;
  }

  /**
   * Exposes sliding window lines relative to the cursor position to save tokens in local compilations
   */
  public static getSlidingCursorWindow(
    content: string,
    cursorLine: number,
    windowRange: number = this.SLIDING_WINDOW_LINES
  ): { before: string; after: string } {
    if (!content) return { before: '', after: '' };

    const lines = content.split('\n');
    const safeCursor = Math.max(0, Math.min(cursorLine, lines.length - 1));

    const startLine = Math.max(0, safeCursor - windowRange);
    const endLine = Math.min(lines.length, safeCursor + windowRange);

    const prefixLines = lines.slice(startLine, safeCursor);
    const suffixLines = lines.slice(safeCursor, endLine);

    return {
      before: prefixLines.join('\n'),
      after: suffixLines.join('\n'),
    };
  }

  /**
   * Optimizes tokens by stripping heavy multi-line comments from large code documents
   */
  public static stripRedundantComments(code: string, language: string): string {
    const lang = language.toLowerCase();

    if (['javascript', 'typescript', 'js', 'ts', 'kotlin', 'kt', 'java', 'rust', 'rs'].includes(lang)) {
      // Strips multi-line comment blocks block /* ... */
      return code.replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/\s*#region[\s\S]*?\/\/\s*#endregion/g, '');
    }

    if (['python', 'py'].includes(lang)) {
      // Strips triple-quote blocks """ ... """
      return code.replace(/"""[\s\S]*?"""/g, '').replace(/'''[\s\S]*?'''/g, '');
    }

    return code;
  }

  /**
   * Generates a sleek, high-level string representation of the project workspace tree
   */
  public static formatWorkspaceTree(files: FileNodeContext[]): string {
    if (!files || files.length === 0) return 'Empty Workspace';

    const folders = files.filter((f) => f.isFolder);
    const nodes = files.filter((f) => !f.isFolder);

    let treeText = 'PROJECT STRUCTURE WORKSPACE MAP:\n';
    
    // Group files by root directories cleanly
    folders.forEach((folder) => {
      treeText += `📁 /${folder.path}\n`;
      const children = nodes.filter((n) => n.path.startsWith(folder.path));
      children.forEach((child) => {
        treeText += `   |--- 📄 ${child.name}\n`;
      });
    });

    // Uncategorized root files
    const rootFiles = nodes.filter((n) => !n.path.includes('/'));
    if (rootFiles.length > 0) {
      treeText += '📁 / (root)\n';
      rootFiles.forEach((rf) => {
        treeText += `   |--- 📄 ${rf.name}\n`;
      });
    }

    return treeText;
  }

  /**
   * Static token estimation (approx 4 chars per token) to prevent token overload errors
   */
  public static estimateTokensCount(text: string): number {
    if (!text) return 0;
    return Math.ceil(text.length / 4);
  }
}
