import { Octokit } from 'octokit';
import { logger } from '../utils/logger';
import { config } from '../config';

export class GitHubService {
  /**
   * Generates direct OAuth login URI using Client ID and requested scopes (repo, user)
   */
  public static getOAuthAuthorizeUrl(state: string): string {
    const params = new URLSearchParams({
      client_id: config.github.clientId,
      redirect_uri: config.github.redirectUri,
      scope: 'repo user',
      state: state,
    });
    return `https://github.com/login/oauth/authorize?${params.toString()}`;
  }

  /**
   * Trades an interactive code code-grant for a long-lived GitHub developer access token
   */
  public static async tradeCodeForToken(code: string): Promise<string> {
    try {
      const response = await fetch('https://github.com/login/oauth/access_token', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
        body: JSON.stringify({
          client_id: config.github.clientId,
          client_secret: config.github.clientSecret,
          code,
          redirect_uri: config.github.redirectUri,
        }),
      });

      const data: any = await response.json();
      if (data.error) {
        throw new Error(`GitHub auth provider trade warning: ${data.error_description}`);
      }
      return data.access_token;
    } catch (error: any) {
      logger.error(`Failed to trade GitHub OAuth Code: ${error.message}`);
      throw error;
    }
  }

  /**
   * Pushes compiler source code direct to GitHub branch recursively matching local indexes
   */
  public static async pushPayloadToRepo(
    token: string,
    repoOwner: string,
    repoName: string,
    branch: string,
    filePath: string,
    content: string,
    commitMessage: string
  ): Promise<any> {
    logger.info(`Commit payload init: repo=${repoOwner}/${repoName}, branch=${branch}`);
    const octokit = new Octokit({ auth: token });

    try {
      // 1. Get SHA of file if it exists, to support overwrites cleanly
      let sha: string | undefined = undefined;
      try {
        const existing = await octokit.rest.repos.getContent({
          owner: repoOwner,
          repo: repoName,
          path: filePath,
          ref: branch,
        });

        if (!Array.isArray(existing.data) && existing.data.type === 'file') {
          sha = existing.data.sha;
        }
      } catch (error) {
        // File does not exist yet (acceptable error block)
        logger.debug(`File ${filePath} is untracked on remote. Proceeding without reference SHA.`);
      }

      // 2. Put content (commit)
      const res = await octokit.rest.repos.createOrUpdateFileContents({
        owner: repoOwner,
        repo: repoName,
        path: filePath,
        message: commitMessage,
        content: Buffer.from(content).toString('base64'),
        branch,
        sha,
      });

      return res.data;
    } catch (error: any) {
      logger.error(`Octokit commit payload failed: ${error.message}`);
      throw error;
    }
  }
}
