import { GoogleGenAI } from '@google/generative-ai';
import { config } from '../config';
import { logger } from '../utils/logger';

export class AiService {
  private static ai: any = null;

  private static getClient() {
    if (!this.ai && config.geminiApiKey) {
      try {
        // Initialize the standard Google GenAI client (compatible with SDK guidelines)
        this.ai = new GoogleGenAI({ apiKey: config.geminiApiKey });
        logger.info('Gemini Generative AI client initialized successfully.');
      } catch (error) {
        logger.error(`Failed to initialize Gemini AI client: ${error}`);
      }
    }
    return this.ai;
  }

  /**
   * Generates AI responses for custom coding inquiries (Explain, Refactor, Fix, or Chat)
   */
  public static async generateResponse(
    prompt: string,
    systemInstruction?: string
  ): Promise<string> {
    const client = this.getClient();

    if (!client) {
      logger.warn('GEMINI_API_KEY is not configured. Simulating AI output...');
      return this.generateSimulatedResponse(prompt, systemInstruction);
    }

    try {
      // Use the standard model for developer instructions: gemini-3.5-flash
      const model = client.getGenerativeModel({
        model: 'gemini-3.5-flash',
        systemInstruction: systemInstruction || 'You are an advanced hacker-level coding co-pilot assisting in the NeoCode AI compiler workspace.',
      });

      const response = await model.generateContent(prompt);
      return response.text;
    } catch (error: any) {
      logger.error(`Gemini API execution error: ${error.message}`);
      return `[API ERROR] Core LLM pipeline encounter: ${error.message}. Falling back to default assistant stream.`;
    }
  }

  /**
   * Refined cyberpunk local mock generator for sandbox offline execution
   */
  private static generateSimulatedResponse(prompt: string, instruction?: string): string {
    const rawLower = prompt.toLowerCase();
    
    if (rawLower.includes('explain')) {
      return `// NEOCONTEXT INTERPRETER (OFFLINE SANDBOX MODE)
// Analyzing lexical AST representations...
// File matches generic JS/TS/Rust components standards.

The requested logic encapsulates an elegant algorithmic routine. Here is an execution analysis:
1. **Instantiation**: Sets up clean state scopes in memory.
2. **Evaluation Loop**: Computes changes reactively.
3. **Execution Delivery**: Returns output or updates the container stack.

*Tip: Link your official Gemini API Key inside Settings tab to get precise neural explanations!*`;
    }

    if (rawLower.includes('refactor')) {
      return `// NEOCONTEXT REFACTOR (OFFLINE SANDBOX MODE)
// Performance target: O(log n) overhead, 0 garbage collection pauses.

export function optimizedRoutine(data) {
  // Memoized cache to prevent heavy recomputations
  const cache = new Map();
  
  return function(param) {
    if (cache.has(param)) return cache.get(param);
    
    // Cyberpunk efficient bitwise evaluation
    const result = data(param);
    cache.set(param, result);
    return result;
  };
}`;
    }

    if (rawLower.includes('fix') || rawLower.includes('bug')) {
      return `// NEOCONTEXT DEBUGGER (OFFLINE SANDBOX MODE)
// Tracing stack frames... 0 critical memory leaks found.
// Recommended modification:

// Ensure null safe checks exist for all asynchronous endpoints
if (!payload || typeof payload !== 'object') {
  throw new Error('[Validation Error] Payload corrupt or missing essential tokens.');
}`;
    }

    return `Greeting, Developer! Welcome to NeoCode AI environment.
Currently operating in offline mockup mode since no GEMINI_API_KEY was found in process variables.

I can help you build elegant mobile client views, trace nested folder definitions, organize Git VCS commits, or simulate Docker sandbox deployment flows. How shall we coordinate our code compiler today?`;
  }
}
