import { logger } from '../utils/logger';

export interface PromptPayload {
  language?: string;
  code?: string;
  fileName?: string;
  cursorLine?: number;
  cursorChar?: number;
  snippetBefore?: string;
  snippetAfter?: string;
  additionalContext?: string;
  errorLogs?: string;
}

export class PromptManager {
  /**
   * Generates tailored prompt payloads and system directions for different coding task vectors
   */
  public static getPrompt(task: string, payload: PromptPayload): { prompt: string; systemInstruction: string } {
    logger.info(`Formatting prompt for task=${task}, filename=${payload.fileName || 'unspecified'}`);

    switch (task.toLowerCase()) {
      case 'autocomplete':
        return this.getFimPrompt(payload);
      case 'debug':
        return this.getDebugPrompt(payload);
      case 'explain':
        return this.getExplainPrompt(payload);
      case 'refactor':
        return this.getRefactorPrompt(payload);
      case 'ui-generation':
        return this.getUiGenerationPrompt(payload);
      case 'backend-generation':
        return this.getBackendGenerationPrompt(payload);
      case 'voice-coding':
        return this.getVoiceCodingPrompt(payload);
      case 'chat':
      default:
        return this.getGeneralChatPrompt(payload);
    }
  }

  /**
   * Fill-In-the-Middle (FIM) prompt for intelligent local autocomplete operations
   */
  private static getFimPrompt(payload: PromptPayload): { prompt: string; systemInstruction: string } {
    const sysInstruction = 
      'You are a high-speed, local code autocomplete extension operating inside an elite editor. ' +
      'Your job is to provide EXACTLY the code that fits between the prefix and suffix context. ' +
      'DO NOT explain, DO NOT wrap in markdown code blocks unless requested. Return ONLY the auto-completed snippet text.';

    const userPrompt = `
PREFIX CODE:
"${payload.snippetBefore || ''}"

SUFFIX CODE:
"${payload.snippetAfter || ''}"

ACTIVE FILE METADATA:
Language: ${payload.language || 'typescript'}
Filename: ${payload.fileName || 'editor_view.ts'}

Given the prefix and suffix contexts, generate the logical code that must exist between them. Provide nothing except the raw code completion.`;

    return { prompt: userPrompt, systemInstruction: sysInstruction };
  }

  /**
   * Prompt template for advanced AST / memory / security auditing and bug fixing
   */
  private static getDebugPrompt(payload: PromptPayload): { prompt: string; systemInstruction: string } {
    const sysInstruction = 
      'You are an expert systems level kernel debugger and cyber security auditor. ' +
      'Scan the provided source code and system runtime errors. Highlight critical warnings, ' +
      'address security exploits (OWASP Top 10, memory leaks, raw overflows), and output corrected code.';

    const userPrompt = `
ACTIVE FILE: ${payload.fileName || 'App.kt'}
LANGUAGE: ${payload.language || 'kotlin'}

SOURCE CODE TO EVALUATE:
\`\`\`${payload.language || ''}
${payload.code || ''}
\`\`\`

SYSTEM EXECUTION / LINT / COMPILER ERRORS:
"""
${payload.errorLogs || 'No explicit log inputs provided.'}
"""

ADDITIONAL DEVELOPER CONTEXT:
${payload.additionalContext || 'Evaluate generic faults.'}

Please locate all critical flaws, specify the root cause simply, and deliver a fully corrected and highly secure code block.`;

    return { prompt: userPrompt, systemInstruction: sysInstruction };
  }

  /**
   * Explains source code blocks simply, detailing execution flow and complexity classes
   */
  private static getExplainPrompt(payload: PromptPayload): { prompt: string; systemInstruction: string } {
    const sysInstruction = 
      'You are an exceptional computer science professor and tech lead. ' +
      'Break down the user\'s code block into clear, highly digestible execution phases. ' +
      'Detail the algorithmic logic, complexity constraints, and side effects.';

    const userPrompt = `
TARGET FILE: ${payload.fileName || 'unknown'}
LANGUAGE: ${payload.language || 'javascript'}

CODE:
\`\`\`${payload.language || ''}
${payload.code || ''}
\`\`\`

Please analyze and explain:
1. **Execution Workflow**: A walk-through of the control and data paths.
2. **Complexity Profile**: Time complexity (Big O) and Space complexity.
3. **Key Dependencies/Functions**: Any external dependencies or main structures.
4. **Resiliency Index**: Edge cases or inputs that could trigger exception paths.`;

    return { prompt: userPrompt, systemInstruction: sysInstruction };
  }

  /**
   * Refactors code for structural elegance, speed, and modern conventions
   */
  private static getRefactorPrompt(payload: PromptPayload): { prompt: string; systemInstruction: string } {
    const sysInstruction = 
      'You are a senior staff performance engineer. ' +
      'Your task is to refactor code for supreme readability, peak performance, correct caching, and O(log n) optimization. ' +
      'Never alter intended functionality, but improve structure and styling dramatically.';

    const userPrompt = `
Refactor the following:
Language: ${payload.language || 'typescript'}
Filename: ${payload.fileName || 'utility.js'}

CRITIQUE TARGET CODE:
\`\`\`${payload.language || ''}
${payload.code || ''}
\`\`\`

CONTEXT / PREFERENCES:
${payload.additionalContext || 'Make it modern, clean, modular, and optimized.'}

Provide:
1. **Summary of Refactoring Upgrades**: Bullet points detailing exact changes (e.g., dry violations fixed, performance improvements).
2. **Refactored Code Block**: Clean, production-ready implementation.`;

    return { prompt: userPrompt, systemInstruction: sysInstruction };
  }

  /**
   * Generates highly visual, polished UI layouts and views
   */
  private static getUiGenerationPrompt(payload: PromptPayload): { prompt: string; systemInstruction: string } {
    const sysInstruction = 
      'You are a high-fidelity frontend designer and UX developer specializing in responsive interfaces (Jetpack Compose / React / Tailwind M3). ' +
      'Generate stunning visual code blocks honoring spacing grids, high-contrast dynamic colors, and smooth enter transitions.';

    const userPrompt = `
Please generate a fully functional, visually striking UI Component.
UI Paradigm / Tech Stack: ${payload.language || 'Jetpack Compose (Material 3)'}
Focus Area: ${payload.additionalContext || 'Show interactive state transformations'}

Ensure you follow these rules:
1. Implement elegant interactive visual elements (ripple effects, active touch scale modifications).
2. Adhere strictly to consistent padding (standard 8dp scale) and design spacing.
3. Provide descriptive test tags for automated interaction checks.
4. Deliver immediately usable, clean code blocks.`;

    return { prompt: userPrompt, systemInstruction: sysInstruction };
  }

  /**
   * Spawns scalable production-ready backend code, endpoints, or DB pipelines
   */
  private static getBackendGenerationPrompt(payload: PromptPayload): { prompt: string; systemInstruction: string } {
    const sysInstruction = 
      'You are an advanced software architect specializing in scalable microservice backend setups (Express, NestJS, Go, Python FastAPI). ' +
      'Generate robust, highly performant, type-safe API controllers, middleware, DB schemas, or queues.';

    const userPrompt = `
Please generate a complete server-side backend logic unit:
Framework / Language: ${payload.language || 'Node.js Express TypeScript'}
Core Functionality: ${payload.additionalContext || 'CRUD router with validation'}

Ensure:
1. Robust input validation schemas (such as Zod, Joi, or native class validators).
2. Clean database persistence logic (Mongoose schemas, SQL transactions, or Redis caches).
3. Secure headers and graceful exception middleware handling.
4. Thorough documentation of route endpoints and performance qualities.`;

    return { prompt: userPrompt, systemInstruction: sysInstruction };
  }

  /**
   * Translates spoken vocal descriptions and intents into structural instructions or code changes
   */
  private static getVoiceCodingPrompt(payload: PromptPayload): { prompt: string; systemInstruction: string } {
    const sysInstruction = 
      'You are a conversational audio compiler assistant. ' +
      'You receive vocal transcripts (sometimes disjointed or imperfect due to voice-to-text translators) ' +
      'and map them to exact compiler code actions, edits, or descriptions.';

    const userPrompt = `
VOICE TRANSCRIPTION TEXT:
"${payload.additionalContext || ''}"

ACTIVE COMPILER CODE FILE:
\`\`\`${payload.language || 'typescript'}
${payload.code || ''}
\`\`\`

The user issued this voice command. Please interpret their intent:
1. **Developer Intent Resolution**: What are they trying to do? (e.g. "Add a field", "Define an endpoint", "Fix the variable").
2. **Action Plan**: Specify what edits or replacements are needed.
3. **Generated Code Update**: Present the code block or implementation representing this voice command.`;

    return { prompt: userPrompt, systemInstruction: sysInstruction };
  }

  /**
   * Fallback generic programmer-focused chat assistant
   */
  private static getGeneralChatPrompt(payload: PromptPayload): { prompt: string; systemInstruction: string } {
    const sysInstruction = 
      'You are NeoCode AI Co-Pilot, an elite hacker-class AI assistant helping in the browser workspace. ' +
      'Help developers build, review, learn, and test code files recursively across their file system trees.';

    const userPrompt = `
DEVELOPER INQUIRY:
"${payload.additionalContext || ''}"

FILE CONTEXT ON SCREEN (IF REGISTERED):
Target file: ${payload.fileName || 'none'}
Source:
\`\`\`
${payload.code || 'No active file selected on workspace screen.'}
\`\`\`

Respond comprehensively and help the developer complete their goal.`;

    return { prompt: userPrompt, systemInstruction: sysInstruction };
  }
}
