import { GoogleGenAI } from '@google/generative-ai';
import { config } from '../config';
import { logger } from '../utils/logger';
import { ContextEngine } from './ai.context-engine';

export type AIProvider = 'gemini' | 'openai' | 'claude' | 'ollama';

export interface OrchestrationPayload {
  prompt: string;
  systemInstruction?: string;
  provider?: AIProvider;
  model?: string;
  imageB64?: string; // Optional base64 image representation for Multimodal evaluation
  history?: { role: 'user' | 'assistant'; content: string }[];
  apiKeyOverride?: string; // Permit developers to supply their own keys via Settings
}

export class AiOrchestrator {
  private static DEFAULT_PROVIDER: AIProvider = 'gemini';

  /**
   * Orchestrates the incoming request to the desired provider, executing failovers if necessary
   */
  public static async query(payload: OrchestrationPayload): Promise<{ text: string; providerUsed: AIProvider; modelUsed: string }> {
    const selectedProvider = payload.provider || this.DEFAULT_PROVIDER;
    const model = payload.model || this.getDefaultModelForProvider(selectedProvider);

    logger.info(`Orchestrator: Router received task. TargetProvider=${selectedProvider}, TargetModel=${model}`);

    try {
      const response = await this.executeCall(selectedProvider, model, payload);
      return {
        text: response,
        providerUsed: selectedProvider,
        modelUsed: model,
      };
    } catch (primaryError: any) {
      logger.error(`Orchestrator Primary Error: ${primaryError.message}. Initiating AI fallback system...`);
      return this.handleFallback(selectedProvider, payload, primaryError);
    }
  }

  /**
   * Evaluates backup model paths recursively (Claude -> Gemini -> OpenAI -> Local/Mockup)
   */
  private static async handleFallback(
    failedProvider: AIProvider,
    payload: OrchestrationPayload,
    originalError: Error
  ): Promise<{ text: string; providerUsed: AIProvider; modelUsed: string }> {
    const providersSequence: AIProvider[] = ['gemini', 'openai', 'claude', 'ollama'];
    const nextProviders = providersSequence.filter((p) => p !== failedProvider);

    for (const fallbackProvider of nextProviders) {
      // Avoid querying Ollama if not configured (can block processes waiting on localhost sockets)
      if (fallbackProvider === 'ollama' && !process.env.OLLAMA_API_URL) continue;

      const fallbackModel = this.getDefaultModelForProvider(fallbackProvider);
      logger.warn(`Fallback: Executing backup pipeline on provider=${fallbackProvider}, model=${fallbackModel}`);

      try {
        const text = await this.executeCall(fallbackProvider, fallbackModel, payload);
        logger.info(`Fallback resolved successfully on provider=${fallbackProvider}`);
        return {
          text: `[FALLBACK WARNING] Your selected provider "${failedProvider.toUpperCase()}" failed (${originalError.message}). Seamlessly migrated task to "${fallbackProvider.toUpperCase()}" fallback cluster.\n\n${text}`,
          providerUsed: fallbackProvider,
          modelUsed: fallbackModel,
        };
      } catch (fallbackError: any) {
        logger.error(`Fallback failed on provider=${fallbackProvider}: ${fallbackError.message}`);
        // Continue searching sequence loop
      }
    }

    // 0 online survivors: Drop back to optimized local synthetic compiler mockup
    logger.warn('All configured neural clusters failed to respond. Providing local code mock answers.');
    const simulatedResponse = this.generateOfflineAlternative(payload.prompt);
    return {
      text: `[OFFLINE MODE] Core models unavailable. Generated direct sandbox compiler logic response:\n\n${simulatedResponse}`,
      providerUsed: 'ollama',
      modelUsed: 'local-mockup',
    };
  }

  /**
   * Router executing call based on targeted provider selection
   */
  private static async executeCall(provider: AIProvider, model: string, payload: OrchestrationPayload): Promise<string> {
    switch (provider) {
      case 'openai':
        return this.queryOpenAI(model, payload);
      case 'claude':
        return this.queryClaude(model, payload);
      case 'ollama':
        return this.queryOllama(model, payload);
      case 'gemini':
      default:
        return this.queryGemini(model, payload);
    }
  }

  /**
   * 1. GOOGLE GEMINI CORE LINKAGE
   */
  private static async queryGemini(modelName: string, payload: OrchestrationPayload): Promise<string> {
    const key = payload.apiKeyOverride || config.geminiApiKey;
    if (!key) {
      throw new Error('No valid GEMINI_API_KEY could be fetched from process settings or runtime config.');
    }

    logger.debug(`Gemini Call: model=${modelName}`);
    // Initialize the standard verified GoogleGenAI client (SDK compliant)
    const ai = new GoogleGenAI({ apiKey: key });

    // Ensure model selection aligns with allowed/supported modern versions
    // Map alias or select fallback gracefully
    let resolvedModelName = modelName;
    if (modelName.includes('pro')) {
      resolvedModelName = 'gemini-3.1-pro-preview';
    } else if (modelName.includes('flash') || modelName === 'default') {
      resolvedModelName = 'gemini-3.5-flash';
    }

    const modelInstance = ai.getGenerativeModel({
      model: resolvedModelName,
      systemInstruction: payload.systemInstruction || 'You are an elite developer co-pilot inside NeoCode AI compiler.',
    });

    // Support standard or multimodal payload definitions
    if (payload.imageB64) {
      const result = await modelInstance.generateContent([
        payload.prompt,
        {
          inlineData: {
            mimeType: 'image/jpeg',
            data: payload.imageB64,
          },
        },
      ]);
      return result.text;
    }

    const result = await modelInstance.generateContent(payload.prompt);
    return result.text;
  }

  /**
   * 2. OPENAI INTEGRATION
   */
  private static async queryOpenAI(modelName: string, payload: OrchestrationPayload): Promise<string> {
    const key = payload.apiKeyOverride || process.env.OPENAI_API_KEY;
    if (!key) {
      throw new Error('OPENAI_API_KEY is not configured inside runtime process variables.');
    }

    logger.debug(`OpenAI HTTP call: model=${modelName}`);
    const messages: any[] = [];

    if (payload.systemInstruction) {
      messages.push({ role: 'system', content: payload.systemInstruction });
    }

    // Append history safely
    if (payload.history) {
      payload.history.forEach((h) => {
        messages.push({ role: h.role === 'user' ? 'user' : 'assistant', content: h.content });
      });
    }

    // Append text prompt / base64 images
    if (payload.imageB64) {
      messages.push({
        role: 'user',
        content: [
          { type: 'text', text: payload.prompt },
          {
            type: 'image_url',
            image_url: {
              url: `data:image/jpeg;base64,${payload.imageB64}`,
            },
          },
        ],
      });
    } else {
      messages.push({ role: 'user', content: payload.prompt });
    }

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${key}`,
      },
      body: JSON.stringify({
        model: modelName,
        messages,
        temperature: 0.2,
        max_tokens: 2048,
      }),
    });

    if (!response.ok) {
      const errBody = await response.text();
      throw new Error(`OpenAI cluster returned exception code ${response.status}: ${errBody}`);
    }

    const data: any = await response.json();
    return data.choices?.[0]?.message?.content || 'No text output returned from OpenAI.';
  }

  /**
   * 3. ANTHROPIC CLAUDE INTEGRATION
   */
  private static async queryClaude(modelName: string, payload: OrchestrationPayload): Promise<string> {
    const key = payload.apiKeyOverride || process.env.CLAUDE_API_KEY;
    if (!key) {
      throw new Error('CLAUDE_API_KEY is not defined in current deployment environment variables.');
    }

    logger.debug(`Anthropic Claude fetch: model=${modelName}`);
    const messages: any[] = [];

    // Anthropic structures messages with a root level 'system' property for systemInstruction
    if (payload.history) {
      payload.history.forEach((h) => {
        messages.push({ role: h.role === 'user' ? 'user' : 'assistant', content: h.content });
      });
    }

    // Handle multimodal format differences (image blocks sent along user messages array)
    if (payload.imageB64) {
      messages.push({
        role: 'user',
        content: [
          {
            type: 'image',
            source: {
              type: 'base64',
              media_type: 'image/jpeg',
              data: payload.imageB64,
            },
          },
          {
            type: 'text',
            text: payload.prompt,
          },
        ],
      });
    } else {
      messages.push({ role: 'user', content: payload.prompt });
    }

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': key,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: modelName,
        system: payload.systemInstruction,
        messages,
        max_tokens: 2048,
      }),
    });

    if (!response.ok) {
      const errBody = await response.text();
      throw new Error(`Anthropic endpoint returned exception code ${response.status}: ${errBody}`);
    }

    const data: any = await response.json();
    return data.content?.[0]?.text || 'No markdown output returned from Claude.';
  }

  /**
   * 4. OLLAMA / LOCAL AI OFFLINE INTEGRATION
   */
  private static async queryOllama(modelName: string, payload: OrchestrationPayload): Promise<string> {
    const ollamaUrl = process.env.OLLAMA_API_URL || 'http://localhost:11434';
    logger.debug(`Ollama call mapped: endpoint=${ollamaUrl}/api/generate, model=${modelName}`);

    const response = await fetch(`${ollamaUrl}/api/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: modelName,
        prompt: `${payload.systemInstruction ? payload.systemInstruction + '\n\n' : ''}${payload.prompt}`,
        stream: false,
        options: {
          temperature: 0.1,
        },
      }),
    });

    if (!response.ok) {
      const errBody = await response.text();
      throw new Error(`Local Ollama service failure code ${response.status}: ${errBody}`);
    }

    const data: any = await response.json();
    return data.response || 'No local text compiled.';
  }

  /**
   * Mapping defaults based on provider keys
   */
  private static getDefaultModelForProvider(provider: AIProvider): string {
    switch (provider) {
      case 'openai':
        return 'gpt-4o-mini';
      case 'claude':
        return 'claude-3-5-sonnet-20241022';
      case 'ollama':
        return 'llama3';
      case 'gemini':
      default:
        return 'gemini-3.5-flash';
    }
  }

  /**
   * Cyberpunk offline mockup developer generator
   */
  private static generateOfflineAlternative(prompt: string): string {
    const rawLower = prompt.toLowerCase();
    
    if (rawLower.includes('autocomplete')) {
      return `// LOCAL AUTOCONTENT FEEDBACK (FALLBACK ENGINE)
export function calculateLatencyRating(ticks: number) {
  const maximumBound = 5000;
  return Math.min(1.0, ticks / maximumBound);
}`;
    }

    if (rawLower.includes('ui') || rawLower.includes('compose')) {
      return `// LOCAL JETPACK COMPOSE COMPILER BLOCK (FALLBACK ENGINE)
@Composable
fun FallbackComponent(
    modifier: Modifier = Modifier,
    statusText: String = "Operating on Local Offline Buffer"
) {
    Card(
        modifier = modifier.fillMaxWidth().padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = "NETWORK DISRUPT DETECTION", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = statusText, style = MaterialTheme.typography.bodyMedium)
        }
    }
}`;
    }

    return `// LOCAL PROGRAMMER TERMINAL COMPILER CO-PILOT
// Operating fully local. Connect your cloud API Tokens under Settings page to restore neural pipelines.

We parsed your transaction details successfully. Recommended implementation actions:
1. Validate environmental ports mapping to Docker containers.
2. Ensure you have activated schema indexing logs to preserve persistent data files.
3. Call 'npm run compile' locally inside your shell sandbox terminal tools.`;
  }
}
