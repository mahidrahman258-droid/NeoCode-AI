import { Queue, Worker, Job } from 'bullmq';
import { SandboxService } from './sandbox.service';
import { config } from '../config';
import { logger } from '../utils/logger';

export class QueueService {
  private static taskQueue: Queue | null = null;
  private static worker: Worker | null = null;

  /**
   * Initializes Redis connection and boots the asynchronous job workers
   */
  public static initializeQueue() {
    try {
      const redisConnection = {
        url: config.redisUrl,
      };

      this.taskQueue = new Queue('compiler-sandbox-tasks', {
        connection: redisConnection,
      });

      this.worker = new Worker(
        'compiler-sandbox-tasks',
        async (job: Job) => {
          logger.info(`Compiler task executing - JobId: ${job.id}, target=${job.name}`);
          const { code, language } = job.data;
          
          // Triggers Sandbox isolated evaluation limits
          const result = await SandboxService.executeCode(code, language);
          return result;
        },
        {
          connection: redisConnection,
          concurrency: 5, // Process up to 5 compile executions concurrently
        }
      );

      this.worker.on('completed', (job) => {
        logger.info(`Task compilation resolved successfully: JobId=${job.id}`);
      });

      this.worker.on('failed', (job, err) => {
        logger.error(`Task queue execution failure on JobId=${job?.id || 'N/A'}: ${err.message}`);
      });

      logger.info('BullMQ Asynchronous Compiler Engine Queue initialized with Redis.');
    } catch (error: any) {
      logger.warn(
        `Unable to connect to Redis for BullMQ: ${error.message}. Running in fallback synchronous isolation modes.`
      );
    }
  }

  /**
   * Submits a compiler payload into task pipelines. Falls back to sync sandbox if Redis is offline.
   */
  public static async enqueueCompilation(
    language: string,
    code: string,
    userId: string
  ): Promise<{ jobId: string; status: string; result?: any }> {
    if (this.taskQueue) {
      try {
        const job = await this.taskQueue.add(`compile:${language}`, {
          language,
          code,
          userId,
          timestamp: Date.now(),
        });

        return {
          jobId: job.id || 'unknown_job',
          status: 'QUEUED',
        };
      } catch (err: any) {
        logger.error(`Fail to enqueue job context: ${err.message}, switching to safe direct sandbox evaluate`);
      }
    }

    // Fallback direct execution
    const syncRes = await SandboxService.executeCode(code, language);
    return {
      jobId: `sync_bypass_${Math.random().toString(36).substr(2, 6)}`,
      status: 'RESOLVED_SYNC',
      result: syncRes,
    };
  }
}
