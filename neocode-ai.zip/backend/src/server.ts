import http from 'http';
import { Server } from 'socket.io';
import mongoose from 'mongoose';
import app from './app';
import { config } from './config';
import { logger } from './utils/logger';
import { configureWebSockets } from './websocket/socket.handler';
import { QueueService } from './services/queue.service';

const server = http.createServer(app);

// Mount Web Server socket layers
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST'],
  },
});

configureWebSockets(io);

// Connect standard database scopes
const initDatabase = async () => {
  try {
    // Graceful schema connection setup
    mongoose.set('strictQuery', false);
    await mongoose.connect(config.mongoUri);
    logger.info('Mongoose Database Connection established.');
  } catch (dbError) {
    logger.error(`MongoDB failed to connect: ${dbError}. Operating in in-memory simulation mode.`);
  }
};

// Initialize background queue operations
QueueService.initializeQueue();

// Start Socket Server loop
const PORT = config.port;

const startServer = async () => {
  await initDatabase();

  server.listen(PORT, () => {
    logger.info(`===============================================`);
    logger.info(`⚡️ NeoCode AI Backend Server is live! ⚡️`);
    logger.info(`🌐 Mode: ${config.env}`);
    logger.info(`🚀 API Base: http://localhost:${PORT}/api/v1`);
    logger.info(`🩺 Health Check: http://localhost:${PORT}/health`);
    logger.info(`===============================================`);
  });
};

// Handle process termination cleanup actions
const handleGracefulShutdown = (signal: string) => {
  logger.warn(`Process wrapper received ${signal} signal. Freeing compiler connections...`);
  
  server.close(async () => {
    logger.info('HTTP & Socket servers shut down.');
    await mongoose.connection.close();
    logger.info('Database connections closed. Process terminating...');
    process.exit(0);
  });
};

process.on('SIGTERM', () => handleGracefulShutdown('SIGTERM'));
process.on('SIGINT', () => handleGracefulShutdown('SIGINT'));

startServer();
