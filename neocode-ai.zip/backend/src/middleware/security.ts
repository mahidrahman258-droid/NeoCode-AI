import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';

export const configureSecurity = (app: express.Application) => {
  // Use Helmet to set secure HTTP headers (XSS protector, frameguard, etc.)
  app.use(helmet());

  // Configure CORS for cloud compiler and interactive sandbox streaming
  app.use(
    cors({
      origin: '*', // In production, replace with specific origins for safety
      methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH'],
      allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
      credentials: true,
    })
  );

  // Parse JSON payloads with strict weight limits (protect against large compiler buffers overload)
  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true, limit: '10mb' }));

  // Global Rate Limiter to safeguard API route paths
  const apiLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 150, // limit each IP to 150 requests per windowMs
    standardHeaders: true,
    legacyHeaders: false,
    message: {
      status: 'error',
      message: 'Too many requests from this terminal agent. Please try again after 15 minutes.',
    },
  });

  app.use('/api/', apiLimiter);
};
