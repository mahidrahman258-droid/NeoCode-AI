import { Response, NextFunction } from 'express';
import { FileNodeModel } from '../models/file.model';
import { ProjectModel } from '../models/project.model';
import { AppError } from '../middleware/error';
import { logger } from '../utils/logger';

export class FileController {
  /**
   * Spawns a file or new subfolder inside the database workspace
   */
  public static async createFile(req: any, res: Response, next: NextFunction) {
    try {
      const { projectId } = req.params;
      const { name, path, isFolder, content, parentId } = req.body;

      if (!name || !path) {
        return next(new AppError('Filename and directory path are required to index.', 400));
      }

      // Check access permission
      const project = await ProjectModel.findOne({
        _id: projectId,
        $or: [{ ownerId: req.user.id }, { collaborators: req.user.id }],
      });

      if (!project) {
        return next(new AppError('Project block not accessible.', 403));
      }

      const extension = isFolder ? undefined : name.split('.').pop();

      // Create new file node
      const node = await FileNodeModel.create({
        projectId,
        name,
        path,
        isFolder,
        extension,
        content: content || '',
        gitStatus: 'added', // Mark as initially newly added
        parentId: parentId || null,
      });

      logger.info(`Node created: ${path} (Folder: ${isFolder}) under project ${projectId}`);

      res.status(201).json({
        status: 'success',
        node,
      });
    } catch (error: any) {
      if (error.code === 11000) {
        return next(new AppError('A file or directory already occupies this path layout.', 409));
      }
      next(error);
    }
  }

  /**
   * Returns whole project components formatted recursively to build directory trees
   */
  public static async getFileTree(req: any, res: Response, next: NextFunction) {
    try {
      const { projectId } = req.params;

      const nodes = await FileNodeModel.find({ projectId }).lean();

      // Build tree mapping recursively
      const buildTree = (parentId: string | null): any[] => {
        const list = nodes.filter((n) => {
          const parentStr = n.parentId ? n.parentId.toString() : null;
          return parentStr === parentId;
        });

        return list.map((node) => ({
          id: node._id,
          name: node.name,
          path: node.path,
          isFolder: node.isFolder,
          extension: node.extension,
          gitStatus: node.gitStatus,
          children: node.isFolder ? buildTree(node._id.toString()) : undefined,
        }));
      };

      const tree = buildTree(null);

      res.status(200).json({
        status: 'success',
        tree,
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Saves source code edits back to cloud database syncing states
   */
  public static async updateFileContent(req: any, res: Response, next: NextFunction) {
    try {
      const { nodeId } = req.params;
      const { content } = req.body;

      if (content === undefined) {
        return next(new AppError('Please supply content body update parameters.', 400));
      }

      const file = await FileNodeModel.findById(nodeId);
      if (!file) {
        return next(new AppError('File node not indexed.', 404));
      }

      file.content = content;
      // Mark as modified in Git VCS status if not already marked as newly added
      if (file.gitStatus !== 'added') {
        file.gitStatus = 'modified';
      }

      await file.save();
      logger.info(`Source code updated successfully - nodeId: ${nodeId}, len=${content.length}`);

      res.status(200).json({
        status: 'success',
        node: file,
      });
    } catch (error) {
      next(error);
    }
  }
}
