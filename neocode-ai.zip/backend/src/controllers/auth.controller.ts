import { Request, Response, NextFunction } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { UserModel } from '../models/user.model';
import { config } from '../config';
import { AppError } from '../middleware/error';
import { logger } from '../utils/logger';

export class AuthController {
  /**
   * Register a new developer record
   */
  public static async register(req: Request, res: Response, next: NextFunction) {
    try {
      const { username, email, password } = req.body;

      if (!username || !email || !password) {
        return next(new AppError('Missing required registration parameters.', 400));
      }

      const existingUser = await UserModel.findOne({ $or: [{ email }, { username }] });
      if (existingUser) {
        return next(new AppError('Developer credentials or username already exists.', 409));
      }

      // Hash password
      const salt = await bcrypt.genSalt(10);
      const passwordHash = await bcrypt.hash(password, salt);

      const newUser = await UserModel.create({
        username,
        email,
        passwordHash,
        streakDays: 1,
        lastActiveAt: new Date()
      });

      // Sign JWT Token
      const token = jwt.sign(
        { id: newUser._id, username: newUser.username, email: newUser.email },
        config.jwtSecret,
        { expiresIn: config.jwtExpiresIn }
      );

      logger.info(`Developer registered: ${username} (${email})`);

      res.status(201).json({
        status: 'success',
        token,
        user: {
          id: newUser._id,
          username: newUser.username,
          email: newUser.email,
          streakDays: newUser.streakDays,
        }
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Authenticate signature records
   */
  public static async login(req: Request, res: Response, next: NextFunction) {
    try {
      const { emailOrUsername, password } = req.body;

      if (!emailOrUsername || !password) {
        return next(new AppError('Please supply verification details.', 400));
      }

      const user = await UserModel.findOne({
        $or: [{ email: emailOrUsername.toLowerCase() }, { username: emailOrUsername }]
      });

      if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
        return next(new AppError('Invalid email/username or pass-credentials.', 401));
      }

      // Update developer active streak logs
      const now = new Date();
      const diffTime = Math.abs(now.getTime() - user.lastActiveAt.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

      if (diffDays === 1) {
        user.streakDays += 1;
      } else if (diffDays > 1) {
        user.streakDays = 1; // Restart streak
      }
      user.lastActiveAt = now;
      await user.save();

      const token = jwt.sign(
        { id: user._id, username: user.username, email: user.email },
        config.jwtSecret,
        { expiresIn: config.jwtExpiresIn }
      );

      logger.info(`Session approved: ${user.username} - current streak: ${user.streakDays} days`);

      res.status(200).json({
        status: 'success',
        token,
        user: {
          id: user._id,
          username: user.username,
          email: user.email,
          streakDays: user.streakDays
        }
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Retrieve active token developer logs
   */
  public static async getProfile(req: any, res: Response, next: NextFunction) {
    try {
      const user = await UserModel.findById(req.user.id);
      if (!user) {
        return next(new AppError('User profile not indexed.', 444));
      }

      res.status(200).json({
        status: 'success',
        user: {
          id: user._id,
          username: user.username,
          email: user.email,
          streakDays: user.streakDays,
          lastActiveAt: user.lastActiveAt,
          joinedAt: user.joinedAt
        }
      });
    } catch (error) {
      next(error);
    }
  }
}
