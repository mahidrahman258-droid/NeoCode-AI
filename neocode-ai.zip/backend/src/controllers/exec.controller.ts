import { Response, NextFunction } from 'express';
import { QueueService } from '../services/queue.service';
import { SandboxService } from '../services/sandbox.service';
import { AppError } from '../middleware/error';
import { logger } from '../utils/logger';

export class ExecController {
  /**
   * Evaluates a raw code block directly inside isolated sandboxing structures
   */
  public static async executeDirectly(req: any, res: Response, next: NextFunction) {
    try {
      const { code, language } = req.body;

      if (!code || !language) {
        return next(new AppError('Source code and compiler language specification is required.', 400));
      }

      logger.info(`Synchronous Direct Execution trigger - env=${language}`);
      const executionResult = await SandboxService.executeCode(code, language);

      res.status(200).json({
        status: 'success',
        result: executionResult,
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Pushes compiler routines into queues for async background evaluation (scalable for heavy workloads)
   */
  public static async enqueueCompileTask(req: any, res: Response, next: NextFunction) {
    try {
      const { code, language } = req.body;

      if (!code || !language) {
        return next(new AppError('Both source code and compilation environment language of compiler target must be supplied.', 400));
      }

      const queueResult = await QueueService.enqueueCompilation(language, code, req.user.id);

      res.status(202).json({
        status: 'success',
        message: 'Compilation payload accepted and enqueued.',
        task: queueResult,
      });
    } catch (error) {
      next(error);
    }
  }
}
