import { Response, NextFunction } from 'express';
import { ProjectModel } from '../models/project.model';
import { FileNodeModel } from '../models/file.model';
import { AppError } from '../middleware/error';
import { logger } from '../utils/logger';

export class ProjectController {
  /**
   * Instantiates a clean coding workspace container
   */
  public static async createProject(req: any, res: Response, next: NextFunction) {
    try {
      const { name, description, template } = req.body;

      if (!name) {
        return next(new AppError('Please supply a workspace label name.', 400));
      }

      // Create primary project record
      const project = await ProjectModel.create({
        name,
        description,
        ownerId: req.user.id,
        collaborators: [],
      });

      // Spawn default project structures matching chosen templates (eg: NodeJS/Standard)
      if (template === 'node') {
        const packageJson = await FileNodeModel.create({
          projectId: project._id,
          name: 'package.json',
          path: 'package.json',
          isFolder: false,
          extension: 'json',
          content: JSON.stringify({ name, version: '1.0.0', main: 'index.js', scripts: { start: 'node index.js' } }, null, 2),
        });

        const indexJs = await FileNodeModel.create({
          projectId: project._id,
          name: 'index.js',
          path: 'index.js',
          isFolder: false,
          extension: 'js',
          content: `// ${name} main script entry point\nconsole.log("Hello Cyberpunk compiler world!");`,
        });

        logger.info(`Workspace node template generated successfully under ${project.name}`);
      } else {
        // Fallback root setup
        await FileNodeModel.create({
          projectId: project._id,
          name: 'main.py',
          path: 'main.py',
          isFolder: false,
          extension: 'py',
          content: `print("Hello NeoCode sandbox!")`
        });
      }

      res.status(201).json({
        status: 'success',
        project,
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Fetches all project indices owned or co-authored by developer
   */
  public static async listProjects(req: any, res: Response, next: NextFunction) {
    try {
      const projects = await ProjectModel.find({
        $or: [{ ownerId: req.user.id }, { collaborators: req.user.id }],
      }).sort({ updatedAt: -1 });

      res.status(200).json({
        status: 'success',
        count: projects.length,
        projects,
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Triggers a delete command for an obsolete workspace
   */
  public static async deleteProject(req: any, res: Response, next: NextFunction) {
    try {
      const project = await ProjectModel.findOne({ _id: req.params.projectId, ownerId: req.user.id });
      
      if (!project) {
        return next(new AppError('Project node not found or authorization key rejected.', 404));
      }

      // Drop all files attached to the project
      await FileNodeModel.deleteMany({ projectId: project._id });
      await project.deleteOne();

      logger.info(`Destroyed project: _id=${project._id}, named=${project.name}`);

      res.status(200).json({
        status: 'success',
        message: 'Workspace contents deleted successfully.',
      });
    } catch (error) {
      next(error);
    }
  }
}
