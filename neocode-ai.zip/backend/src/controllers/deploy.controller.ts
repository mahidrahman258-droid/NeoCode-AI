import { Response, NextFunction } from 'express';
import { DeploymentModel } from '../models/deployment.model';
import { ProjectModel } from '../models/project.model';
import { AppError } from '../middleware/error';
import { logger } from '../utils/logger';

export class DeployController {
  /**
   * Triggers a cloud static/app deployment pipeline for the compiler project files
   */
  public static async triggerDeployment(req: any, res: Response, next: NextFunction) {
    try {
      const { projectId } = req.params;
      const { target } = req.body;

      if (!target || !['Vercel', 'Netlify', 'Docker', 'GitHub Pages'].includes(target)) {
        return next(new AppError('Please supply a valid deployment micro-cloud target.', 400));
      }

      const project = await ProjectModel.findById(projectId);
      if (!project) {
        return next(new AppError('Project key not found.', 404));
      }

      // Create a pending deployment record
      const deployment = await DeploymentModel.create({
        projectId,
        target,
        status: 'PENDING',
        logs: [
          `[${new Date().toISOString()}] Initiating deployment vector on ${target} cloud cluster hooks.`,
          `[${new Date().toISOString()}] Compiling project file assets recursively.`,
        ],
      });

      // Simulate step-by-step asynchronous deployment pipeline logs
      setTimeout(async () => {
        try {
          const activeDep = await DeploymentModel.findById(deployment._id);
          if (activeDep) {
            activeDep.logs.push(`[${new Date().toISOString()}] Minifying AST chunks and static JS buffers.`);
            activeDep.logs.push(`[${new Date().toISOString()}] DNS mappings updated successfully. routing to CDN.`);
            activeDep.status = 'SUCCESS';
            activeDep.url = `https://${project.name.toLowerCase().replace(/\s+/g, '-')}-${req.user.username.toLowerCase()}.neocode-cdn.io`;
            activeDep.logs.push(`[${new Date().toISOString()}] Webhook operation closed. Live URL issued: ${activeDep.url}`);
            await activeDep.save();
            logger.info(`Deployment completed successfully: depId=${activeDep._id} URL=${activeDep.url}`);
          }
        } catch (simError) {
          logger.error(`Deployment simulation log record error: ${simError}`);
        }
      }, 5000);

      res.status(202).json({
        status: 'success',
        message: 'Deployment triggered successfully.',
        deployment,
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Lists historic deployments for a given project ID
   */
  public static async getProjectDeployments(req: any, res: Response, next: NextFunction) {
    try {
      const { projectId } = req.params;
      const deployments = await DeploymentModel.find({ projectId }).sort({ timestamp: -1 });

      res.status(200).json({
        status: 'success',
        count: deployments.length,
        deployments,
      });
    } catch (error) {
      next(error);
    }
  }
}
