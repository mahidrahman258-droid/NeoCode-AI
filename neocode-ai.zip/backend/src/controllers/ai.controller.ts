import { Response, NextFunction } from 'express';
import { FileNodeModel } from '../models/file.model';
import { AiSessionModel } from '../models/ai-session.model';
import { PromptManager } from '../services/ai.prompt-manager';
import { ContextEngine } from '../services/ai.context-engine';
import { AiOrchestrator, AIProvider } from '../services/ai.orchestrator';
import { AppError } from '../middleware/error';
import { logger } from '../utils/logger';

export class AiController {
  /**
   * Evaluates standard chatting conversations, managing active user session memories
   */
  public static async chat(req: any, res: Response, next: NextFunction) {
    try {
      const { 
        prompt, 
        projectId, 
        provider = 'gemini', 
        model = 'gemini-3.5-flash', 
        imageB64, 
        apiKeyOverride 
      } = req.body;

      if (!prompt) {
        return next(new AppError('A user prompt instruction must be supplied.', 400));
      }

      // 1. Fetch or create AI memory session for this user/project
      let session = await AiSessionModel.findOne({ userId: req.user.id, projectId: projectId || null });
      if (!session) {
        session = await AiSessionModel.create({
          userId: req.user.id,
          projectId: projectId || null,
          provider: provider as any,
          model,
          history: [],
        });
      } else {
        // Apply on-the-fly model switching if developer adjusted preferences
        session.provider = provider as any;
        session.model = model;
        await session.save();
      }

      // 2. Fetch standard project structures (Context Engine)
      let additionalInfo = '';
      if (projectId) {
        const files = await FileNodeModel.find({ projectId }).select('name path isFolder').lean();
        additionalInfo = ContextEngine.formatWorkspaceTree(files);
      }

      // 3. Formulate prompts matching Prompt Manager definitions
      const { prompt: formattedPrompt, systemInstruction } = PromptManager.getPrompt('chat', {
        additionalContext: `${prompt}\n\n${additionalInfo}`,
      });

      // 4. Query AI Orchestration pipelines
      const result = await AiOrchestrator.query({
        prompt: formattedPrompt,
        systemInstruction,
        provider: provider as AIProvider,
        model,
        imageB64,
        apiKeyOverride,
      });

      // 5. Securely persist conversational turns in database (AI memory limits & token count tracking)
      session.history.push({ role: 'user', content: prompt, timestamp: new Date() });
      session.history.push({ 
        role: 'assistant', 
        content: result.text, 
        timestamp: new Date(),
        modelUsed: result.modelUsed 
      });

      // Simple rolling context eviction (keep last 30 turns to enforce token budget limits)
      if (session.history.length > 60) {
        session.history = session.history.slice(-60);
      }

      session.totalTokensUsed += ContextEngine.estimateTokensCount(formattedPrompt + result.text);
      await session.save();

      res.status(200).json({
        status: 'success',
        response: result.text,
        provider: result.providerUsed,
        model: result.modelUsed,
        totalTokens: session.totalTokensUsed,
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Intelligently autocompletes incomplete script statements based surrounding lines prefix/suffix context
   */
  public static async autocomplete(req: any, res: Response, next: NextFunction) {
    try {
      const { code, cursorLine, cursorChar, language, fileName } = req.body;

      if (code === undefined || cursorLine === undefined) {
        return next(new AppError('Missing files parameter or active cursor coordinates.', 400));
      }

      // Optimize payload weight by harvesting standard sliding regions surrounding cursor position
      const { before, after } = ContextEngine.getSlidingCursorWindow(code, cursorLine);

      // Generate localized autocompletion structures
      const { prompt, systemInstruction } = PromptManager.getPrompt('autocomplete', {
        snippetBefore: before,
        snippetAfter: after,
        language,
        fileName,
      });

      const result = await AiOrchestrator.query({
        prompt,
        systemInstruction,
        provider: req.body.provider || 'gemini',
        model: req.body.model || 'gemini-3.5-flash',
      });

      res.status(200).json({
        status: 'success',
        completion: result.text.trim(),
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Code auditing / Fault parsing controller
   */
  public static async debug(req: any, res: Response, next: NextFunction) {
    try {
      const { code, errorLogs, language, fileName, additionalContext } = req.body;

      const { prompt, systemInstruction } = PromptManager.getPrompt('debug', {
        code: ContextEngine.optimizeFileContext(code || '', language || 'typescript'),
        errorLogs,
        language,
        fileName,
        additionalContext,
      });

      const result = await AiOrchestrator.query({
        prompt,
        systemInstruction,
        provider: req.body.provider || 'gemini',
        model: req.body.model || 'gemini-3.5-flash',
      });

      res.status(200).json({
        status: 'success',
        analysis: result.text,
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Explains source code blocks step by step
   */
  public static async explain(req: any, res: Response, next: NextFunction) {
    try {
      const { code, language, fileName } = req.body;

      const { prompt, systemInstruction } = PromptManager.getPrompt('explain', {
        code: ContextEngine.optimizeFileContext(code || '', language || 'typescript'),
        language,
        fileName,
      });

      const result = await AiOrchestrator.query({
        prompt,
        systemInstruction,
        provider: req.body.provider || 'gemini',
        model: req.body.model || 'gemini-3.5-flash',
      });

      res.status(200).json({
        status: 'success',
        explanation: result.text,
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Refactors slow, redundant, or outdated constructs
   */
  public static async refactor(req: any, res: Response, next: NextFunction) {
    try {
      const { code, language, fileName, additionalContext } = req.body;

      const { prompt, systemInstruction } = PromptManager.getPrompt('refactor', {
        code: ContextEngine.optimizeFileContext(code || '', language || 'javascript'),
        language,
        fileName,
        additionalContext,
      });

      const result = await AiOrchestrator.query({
        prompt,
        systemInstruction,
        provider: req.body.provider || 'gemini',
        model: req.body.model || 'gemini-3.5-flash',
      });

      res.status(200).json({
        status: 'success',
        refactoredCode: result.text,
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * UI Mockups / Jetpack Compose layouts Generator
   */
  public static async generateUI(req: any, res: Response, next: NextFunction) {
    try {
      const { prompt: uiPrompt, language } = req.body;

      const { prompt, systemInstruction } = PromptManager.getPrompt('ui-generation', {
        additionalContext: uiPrompt,
        language,
      });

      const result = await AiOrchestrator.query({
        prompt,
        systemInstruction,
        provider: req.body.provider || 'gemini',
        model: req.body.model || 'gemini-3.5-flash',
      });

      res.status(200).json({
        status: 'success',
        uiCode: result.text,
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Micro backend setup generator
   */
  public static async generateBackend(req: any, res: Response, next: NextFunction) {
    try {
      const { prompt: backendPrompt, language } = req.body;

      const { prompt, systemInstruction } = PromptManager.getPrompt('backend-generation', {
        additionalContext: backendPrompt,
        language,
      });

      const result = await AiOrchestrator.query({
        prompt,
        systemInstruction,
        provider: req.body.provider || 'gemini',
        model: req.body.model || 'gemini-3.5-flash',
      });

      res.status(200).json({
        status: 'success',
        backendCode: result.text,
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Maps voice inputs text and executes compiler transformations
   */
  public static async voiceCoding(req: any, res: Response, next: NextFunction) {
    try {
      const { transcript, activeCode, language } = req.body;

      if (!transcript) {
        return next(new AppError('vocal transcript input missing.', 400));
      }

      const { prompt, systemInstruction } = PromptManager.getPrompt('voice-coding', {
        code: activeCode,
        language,
        additionalContext: transcript,
      });

      const result = await AiOrchestrator.query({
        prompt,
        systemInstruction,
        provider: req.body.provider || 'gemini',
        model: req.body.model || 'gemini-3.5-flash',
      });

      res.status(200).json({
        status: 'success',
        interpretation: result.text,
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * HTTP STREAMING ENDPOINT (Using standard Server-Sent Events)
   * Resolves: "Streaming response system"
   */
  public static async streamSse(req: any, res: Response, next: NextFunction) {
    try {
      const { prompt, provider = 'gemini', model = 'gemini-3.5-flash', systemInstruction } = req.query;

      if (!prompt) {
        return res.status(400).write('data: {"error": "Prompt query query-token is required"}\n\n');
      }

      // Configure SSE response parameters
      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache');
      res.setHeader('Connection', 'keep-alive');
      res.flushHeaders(); // Establish actual stream connection immediately

      logger.info(`SSE stream initiated: provider=${provider} model=${model}`);

      // Query core networks
      const resolvedRes = await AiOrchestrator.query({
        prompt: prompt as string,
        systemInstruction: systemInstruction as string || 'You are an advanced hacker co-pilot.',
        provider: provider as AIProvider,
        model: model as string,
      });

      // Simulate token-based live visualization by chunking response buffer text smoothly
      const words = resolvedRes.text.split(' ');
      let currentWordIndex = 0;

      const intervalId = setInterval(() => {
        if (currentWordIndex < words.length) {
          const chunk = words.slice(currentWordIndex, currentWordIndex + 3).join(' ') + ' ';
          res.write(`data: ${JSON.stringify({ chunk })}\n\n`);
          currentWordIndex += 3;
        } else {
          res.write('data: [DONE]\n\n');
          clearInterval(intervalId);
          res.end();
        }
      }, 70);

      req.on('close', () => {
        clearInterval(intervalId);
        logger.info('SSE user disconnected. Stream elements wiped.');
      });
    } catch (err: any) {
      logger.error(`SSE compilation error block: ${err.message}`);
      res.write(`data: ${JSON.stringify({ error: err.message })}\n\n`);
      res.end();
    }
  }
}
