import { Schema, model, Types } from 'mongoose';

export interface IProject {
  name: string;
  description?: string;
  ownerId: Types.ObjectId;
  collaborators: Types.ObjectId[];
  createdAt: Date;
  updatedAt: Date;
  activeBranch: string;
  githubRepoUrl?: string;
}

const ProjectSchema = new Schema<IProject>({
  name: { type: String, required: true, trim: true },
  description: { type: String },
  ownerId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  collaborators: [{ type: Schema.Types.ObjectId, ref: 'User' }],
  activeBranch: { type: String, default: 'main' },
  githubRepoUrl: { type: String },
}, {
  timestamps: true
});

export const ProjectModel = model<IProject>('Project', ProjectSchema);
