import { Schema, model, Types } from 'mongoose';

export interface IDeployment {
  projectId: Types.ObjectId;
  target: 'Vercel' | 'Netlify' | 'Docker' | 'GitHub Pages';
  status: 'PENDING' | 'SUCCESS' | 'FAILED';
  url?: string;
  logs: string[];
  timestamp: Date;
}

const DeploymentSchema = new Schema<IDeployment>({
  projectId: { type: Schema.Types.ObjectId, ref: 'Project', required: true },
  target: { type: String, enum: ['Vercel', 'Netlify', 'Docker', 'GitHub Pages'], required: true },
  status: { type: String, enum: ['PENDING', 'SUCCESS', 'FAILED'], default: 'PENDING' },
  url: { type: String },
  logs: [{ type: String }],
  timestamp: { type: Date, default: Date.now }
});

export const DeploymentModel = model<IDeployment>('Deployment', DeploymentSchema);
