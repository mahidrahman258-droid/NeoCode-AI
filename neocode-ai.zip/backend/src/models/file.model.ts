import { Schema, model, Types } from 'mongoose';

export interface IFileNode {
  projectId: Types.ObjectId;
  name: string;
  path: string;
  isFolder: boolean;
  extension?: string;
  content?: string;
  gitStatus?: 'added' | 'modified' | 'untracked' | null;
  parentId?: Types.ObjectId;
}

const FileNodeSchema = new Schema<IFileNode>({
  projectId: { type: Schema.Types.ObjectId, ref: 'Project', required: true },
  name: { type: String, required: true },
  path: { type: String, required: true },
  isFolder: { type: Boolean, required: true },
  extension: { type: String },
  content: { type: String, default: '' },
  gitStatus: { type: String, enum: ['added', 'modified', 'untracked', null], default: null },
  parentId: { type: Schema.Types.ObjectId, ref: 'FileNode', default: null }
});

// Ensure compound index for unique files under a project path
FileNodeSchema.index({ projectId: 1, path: 1 }, { unique: true });

export const FileNodeModel = model<IFileNode>('FileNode', FileNodeSchema);
