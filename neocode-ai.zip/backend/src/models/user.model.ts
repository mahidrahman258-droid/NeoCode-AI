import { Schema, model } from 'mongoose';

export interface IUser {
  username: string;
  email: string;
  passwordHash: string;
  avatarUrl?: string;
  streakDays: number;
  lastActiveAt: Date;
  joinedAt: Date;
}

const UserSchema = new Schema<IUser>({
  username: { type: String, required: true, unique: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  passwordHash: { type: String, required: true },
  avatarUrl: { type: String },
  streakDays: { type: Number, default: 1 },
  lastActiveAt: { type: Date, default: Date.now },
  joinedAt: { type: Date, default: Date.now }
});

export const UserModel = model<IUser>('User', UserSchema);
