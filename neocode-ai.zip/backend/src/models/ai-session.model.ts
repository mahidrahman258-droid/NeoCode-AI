import { Schema, model, Types } from 'mongoose';

export interface IMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: Date;
  modelUsed?: string;
}

export interface IAiSession {
  userId: Types.ObjectId;
  projectId?: Types.ObjectId;
  provider: 'gemini' | 'openai' | 'claude' | 'ollama';
  model: string;
  history: IMessage[];
  developerPreferences: string; // Condensed summary representing the long-term coder memory
  totalTokensUsed: number;
  createdAt: Date;
  updatedAt: Date;
}

const MessageSchema = new Schema<IMessage>({
  role: { type: String, enum: ['user', 'assistant', 'system'], required: true },
  content: { type: String, required: true },
  timestamp: { type: Date, default: Date.now },
  modelUsed: { type: String },
});

const AiSessionSchema = new Schema<IAiSession>({
  userId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  projectId: { type: Schema.Types.ObjectId, ref: 'Project' },
  provider: { type: String, enum: ['gemini', 'openai', 'claude', 'ollama'], default: 'gemini' },
  model: { type: String, default: 'gemini-3.5-flash' },
  history: [MessageSchema],
  developerPreferences: { type: String, default: '' },
  totalTokensUsed: { type: Number, default: 0 },
}, {
  timestamps: true,
});

export const AiSessionModel = model<IAiSession>('AiSession', AiSessionSchema);
