package com.example.data.models

data class ProjectFile(
    val name: String,
    val path: String,
    val extension: String,
    val content: String,
    val isFolder: Boolean = false,
    val children: List<ProjectFile>? = null,
    val gitStatus: String? = null // "added", "modified", null
)
