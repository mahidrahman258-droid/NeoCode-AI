package com.example.data.models

data class CodeSnippet(
    val title: String,
    val description: String,
    val language: String,
    val snippet: String,
    val category: String = "Utility"
)

data class ExtensionPlugin(
    val id: String,
    val name: String,
    val developer: String,
    val version: String,
    val description: String,
    val rating: Float,
    val downloads: String,
    val category: String, // "Themes", "Languages", "AI", "Linters"
    val isInstalled: Boolean = false,
    val iconResId: String = "code" // placeholder descriptor
)

data class DeploymentLog(
    val id: String,
    val timestamp: String,
    val message: String,
    val status: String // "SUCCESS", "PENDING", "FAILED"
)

data class LiveUser(
    val name: String,
    val colorHex: String,
    val avatarLetters: String,
    val cursorRow: Int,
    val cursorCol: Int,
    val isActive: Boolean = true
)

data class SemanticResult(
    val filename: String,
    val snippet: String,
    val lineNum: Int,
    val similarity: Int,
    val description: String
)

data class ServerProcess(
    val name: String,
    val port: Int,
    val status: String, // "RUNNING", "STOPPED", "ERROR"
    val logs: String
)

data class WorkflowAutomation(
    val id: String,
    val name: String,
    val triggerName: String,
    val actionName: String,
    val isEnabled: Boolean
)
