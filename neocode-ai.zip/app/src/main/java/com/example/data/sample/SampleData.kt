package com.example.data.sample

import com.example.data.models.*

object SampleData {
    val languages = listOf(
        "TypeScript", "JavaScript", "Python", "Dart", "Rust", "Go", "HTML", "CSS", "C++", "Java"
    )

    val extensionPlugins = listOf(
        ExtensionPlugin(
            id = "ext.copilot",
            name = "NeoCode Copilot Pro",
            developer = "NeoCode AI",
            version = "v2.8.5",
            description = "AI autocompletion with 100B parameter neural suggestions, intent guessing, and automatic docstring rendering.",
            rating = 4.9f,
            downloads = "2.4M",
            category = "AI",
            isInstalled = true
        ),
        ExtensionPlugin(
            id = "ext.synthwave",
            name = "Synthwave '84 Glow",
            developer = "RobbOwen",
            version = "v1.2.0",
            description = "Neon glow styling for active panels, gradient terminal cursors, and custom synth background palettes.",
            rating = 4.8f,
            downloads = "1.2M",
            category = "Themes",
            isInstalled = false
        ),
        ExtensionPlugin(
            id = "ext.rust_analyzer",
            name = "Rust Analyzer Mobile",
            developer = "The Rust Org",
            version = "v1.0.4",
            description = "Brings deep type coverage, borrow checker insights, macro expansion trees, and refactoring on the go.",
            rating = 4.7f,
            downloads = "340K",
            category = "Languages",
            isInstalled = false
        ),
        ExtensionPlugin(
            id = "ext.flutter_helper",
            name = "Flutter Widget Explorer",
            developer = "AwesomeFlutter",
            version = "v4.2.0",
            description = "Interactive widget trees, widget code snippets helper, reactive inspector, and live device frame renderer.",
            rating = 4.9f,
            downloads = "980K",
            category = "Languages",
            isInstalled = true
        ),
        ExtensionPlugin(
            id = "ext.eslint",
            name = "ESLint Dynamic Mobile",
            developer = "JS Studio",
            version = "v8.1.1",
            description = "Analyzes source code on-the-fly to find security vulnerabilities, code smells, and invalid imports.",
            rating = 4.6f,
            downloads = "1.5M",
            category = "Linters",
            isInstalled = true
        ),
        ExtensionPlugin(
            id = "ext.cyberpunk_theme",
            name = "GridRun Hacker Theme",
            developer = "HACKER_X",
            version = "v3.3.3",
            description = "Terminal green accents with digital grid overlays. Fully optimized for high contrast AMOLED screens.",
            rating = 4.9f,
            downloads = "540K",
            category = "Themes",
            isInstalled = false
        )
    )

    val snippets = listOf(
        CodeSnippet(
            title = "Bubble Sort",
            description = "Standard swap array sort implementation.",
            language = "JavaScript",
            snippet = """function bubbleSort(arr) {
  let len = arr.length;
  for (let i = 0; i < len; i++) {
    for (let j = 0; j < len - i - 1; j++) {
      if (arr[j] > arr[j + 1]) {
        let temp = arr[j];
        arr[j] = arr[j + 1];
        arr[j + 1] = temp;
      }
    }
  }
  return arr;
}""",
            category = "Algorithms"
        ),
        CodeSnippet(
            title = "Fast API Server Setup",
            description = "Launches stateful async Python endpoint.",
            language = "Python",
            snippet = """from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

class Project(BaseModel):
    name: str
    language: str

@app.post("/api/create")
async def create_project(proj: Project):
    return {"status": "SUCCESS", "id": proj.name.lower().replace(" ", "-")}
""",
            category = "Backend"
        ),
        CodeSnippet(
            title = "Rust Prime Checker",
            description = "Optimized mathematical prime solver.",
            language = "Rust",
            snippet = """pub fn is_prime(n: u64) -> bool {
    if n <= 1 { return false; }
    if n <= 3 { return true; }
    if n % 2 == 0 || n % 3 == 0 { return false; }
    let mut i = 5;
    while i * i <= n {
        if n % i == 0 || n % (i + 2) == 0 {
            return false;
        }
        i += 6;
    }
    true
}""",
            category = "Math"
        )
    )

    val defaultFiles = listOf(
        ProjectFile(
            name = "src",
            path = "src",
            extension = "",
            content = "",
            isFolder = true,
            children = listOf(
                ProjectFile(
                    name = "main.ts",
                    path = "src/main.ts",
                    extension = "ts",
                    content = """// NeoCode AI TypeScript Demo
import { AIModel, CodeCompiler } from "./neo_compiler";

interface EditorState {
  filename: string;
  cursorRow: number;
  cursorCol: number;
}

const activeState: EditorState = {
  filename: "main.ts",
  cursorRow: 14,
  cursorCol: 2
};

export async function processCompilation(code: string) {
  console.log("Analyzing tokens dynamically...");
  const tokens = await CodeCompiler.tokenize(code);
  const feedback = AIModel.suggestOptimization(tokens);
  
  if (tokens.hasErrors) {
    console.error("Critical Token Errors Encountered in AST.");
  }
  
  return {
    status: 200,
    optimizedContent: feedback.suggestedCode,
    insights: ["Remove unused imports", "Consolidate async closures"]
  };
}

console.log("Welcome to NeoCode AI Workspace!");
""",
                    gitStatus = "modified"
                ),
                ProjectFile(
                    name = "index.html",
                    path = "src/index.html",
                    extension = "html",
                    content = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NeoCode Holographic Live Preview</title>
    <style>
        body {
            background-color: #0b0c10;
            color: #66fcf1;
            font-family: 'JetBrains Mono', monospace;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            padding: 24px;
        }
        .container {
            border: 2px solid #1f2833;
            border-radius: 12px;
            padding: 40px;
            text-align: center;
            background: rgba(11, 12, 16, 0.85);
            box-shadow: 0 0 30px rgba(102, 252, 241, 0.25);
            backdrop-filter: blur(12px);
        }
        h1 {
            color: #fff;
            margin-bottom: 8px;
            text-shadow: 0 0 10px #00f0ff;
        }
        p { color: #c5c6c7; line-height: 1.6; }
        .accent { color: #c71585; font-weight: bold; }
    </style>
</head>
<body>
    <div class="container">
        <h1>NeoCode AI Studio</h1>
        <p>Live Web Simulator initialized correctly.</p>
        <p>FPS: <span class="accent">60.0</span> | Host: <span class="accent">localhost:3000</span></p>
    </div>
</body>
</html>
""",
                    gitStatus = null
                )
            )
        ),
        ProjectFile(
            name = "ai_engine.py",
            path = "ai_engine.py",
            extension = "py",
            content = """# NeoCode AI - Python Neural Autofill Engine
import numpy as np
import time

class Cybercompletions:
    def __init__(self, temperature: float = 0.25):
        self.temperature = temperature
        self.model_status = "STABLE"
        print("⚡ Neural Auto-completions engine online.")

    def run_inference(self, prompt: str) -> str:
        # Simulate local LLM processing
        tokens = prompt.split()
        if not tokens:
            return "# Start coding..."
            
        print(f"[AI RAW] Parsing contextual prompt: '{prompt}'")
        time.sleep(0.4)
        
        last_tok = tokens[-1].lower()
        if "def" in last_tok:
            return " calculate_matrix_dimensions(layers: list) -> tuple:\\n    return (len(layers), [l.shape for l in layers])"
        elif "class" in last_tok:
            return " NeoCompilerPlugin:\\n    def __init__(self):\\n        pass"
        elif "import" in last_tok:
            return " torch\\nimport torch.nn as nn"
        
        return " # Suggestion generated via local Gemini link"

if __name__ == "__main__":
    ai = Cybercompletions()
    print(ai.run_inference("def"))
""",
            gitStatus = "added"
        ),
        ProjectFile(
            name = "app.dart",
            path = "app.dart",
            extension = "dart",
            content = """// Flutter Mobile Workspace Preview file
import 'package:flutter/material.dart';

void main() => runApp(const NeoApp());

class NeoApp extends StatelessWidget {
  const NeoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF030303),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF00FFCC),
          secondary: Color(0xFFFF007F),
        ),
      ),
      home: const Dashboard(),
    );
  }
}

class Dashboard extends StatelessWidget {
  const Dashboard({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.bolt, color: Color(0xFF00FFCC), size: 64),
            Text('NeoCode Premium Applet', style: Theme.of(context).textTheme.headlineMedium),
          ],
        ),
      ),
    );
  }
}
""",
            gitStatus = null
        ),
        ProjectFile(
            name = "package.json",
            path = "package.json",
            extension = "json",
            content = """{
  "name": "neocode-hologram-app",
  "version": "1.0.0",
  "description": "Premium React & TypeScript visualizer compiled natively",
  "main": "src/main.ts",
  "scripts": {
    "start": "neocode-serv launch",
    "build": "neocode-compiler compile",
    "lint": "neocode-eslint"
  },
  "dependencies": {
    "typescript": "^5.1.3",
    "@neocode/ai-core": "^2.1.0"
  }
}
""",
            gitStatus = null
        )
    )

    val liveUsers = listOf(
        LiveUser(name = "Kira_Dev", colorHex = "#FF007F", avatarLetters = "KD", cursorRow = 4, cursorCol = 8),
        LiveUser(name = "Zane_Cyber", colorHex = "#00FFCC", avatarLetters = "ZC", cursorRow = 15, cursorCol = 3),
        LiveUser(name = "Hacker_Zero", colorHex = "#9D4EDD", avatarLetters = "HZ", cursorRow = 8, cursorCol = 12, isActive = false)
    )

    val initialDeploymentLogs = listOf(
        DeploymentLog("dep-09", "18:42:01", "Triggered auto-deployment webhook of repo `neocode-hologram-app`", "PENDING"),
        DeploymentLog("dep-08", "18:30:15", "Vercel static build for `src/index.html` completed successfully.", "SUCCESS"),
        DeploymentLog("dep-07", "18:05:32", "Docker Container compile: Rust runtime base image downloaded.", "SUCCESS"),
        DeploymentLog("dep-06", "17:41:10", "Deploy to Netlify failing with code 127: invalid lockfile key.", "FAILED")
    )
}
