package com.example.ui.components

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.example.ui.theme.*

object CodeSyntaxHighlighter {

    private val KEYWORDS = setOf(
        "import", "export", "from", "as", "class", "interface", "extends", "implements",
        "const", "let", "var", "function", "return", "async", "await", "def", "class", "try",
        "except", "finally", "catch", "if", "else", "for", "while", "print", "console", "log",
        "error", "void", "main", "fn", "pub", "struct", "impl", "let", "mut", "use", "mod",
        "struct", "enum", "type", "String", "int", "double", "float", "bool", "boolean"
    )

    fun highlight(code: String, extension: String): AnnotatedString {
        return buildAnnotatedString {
            var i = 0
            val len = code.length

            while (i < len) {
                // Line comment check
                if (code.startsWith("//", i) || (extension == "py" && code[i] == '#')) {
                    val endComment = code.indexOf("\n", i).let { if (it == -1) len else it }
                    pushStyle(SpanStyle(color = CodeComment, fontFamily = FontFamily.Monospace))
                    append(code.substring(i, endComment))
                    pop()
                    i = endComment
                    continue
                }

                // String literals (single or double quotes)
                if (code[i] == '"' || code[i] == '\'') {
                    val quote = code[i]
                    var endQuote = i + 1
                    while (endQuote < len && code[endQuote] != quote) {
                        if (code[endQuote] == '\\' && endQuote + 1 < len) {
                            endQuote += 2
                        } else {
                            endQuote++
                        }
                    }
                    if (endQuote < len) endQuote++ // include closing quote
                    
                    pushStyle(SpanStyle(color = CodeString, fontFamily = FontFamily.Monospace))
                    append(code.substring(i, endQuote))
                    pop()
                    i = endQuote
                    continue
                }

                val char = code[i]

                // Token parsing (alphanumeric strings)
                if (char.isLetter() || char == '_') {
                    var endWord = i
                    while (endWord < len && (code[endWord].isLetterOrDigit() || code[endWord] == '_')) {
                        endWord++
                    }
                    val word = code.substring(i, endWord)
                    
                    val style = when {
                        KEYWORDS.contains(word) -> SpanStyle(color = CodeKeyword, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        word.getOrNull(0)?.isUpperCase() == true -> SpanStyle(color = CodeNumber, fontWeight = FontWeight.SemiBold, fontFamily = FontFamily.Monospace) // class/interface names
                        endWord < len && code[endWord] == '(' -> SpanStyle(color = CodeFunction, fontFamily = FontFamily.Monospace) // function calls
                        else -> SpanStyle(color = CodeVariable, fontFamily = FontFamily.Monospace)
                    }

                    pushStyle(style)
                    append(word)
                    pop()
                    i = endWord
                    continue
                }

                // Numbers check
                if (char.isDigit()) {
                    var endNum = i
                    while (endNum < len && (code[endNum].isDigit() || code[endNum] == '.')) {
                        endNum++
                    }
                    val num = code.substring(i, endNum)
                    pushStyle(SpanStyle(color = CodeNumber, fontFamily = FontFamily.Monospace))
                    append(num)
                    pop()
                    i = endNum
                    continue
                }

                // Standard characters
                val styleSymbol = when (char) {
                    '{', '}', '(', ')', '[', ']' -> SpanStyle(color = Color(0xFFF8F8F2))
                    '+', '-', '*', '/', '=', '!', '<', '>', '&', '|', '^', '%' -> SpanStyle(color = CodeKeyword)
                    else -> SpanStyle(color = Color(0xFFA0A0B0))
                }
                pushStyle(styleSymbol)
                append(char)
                pop()
                i++
            }
        }
    }
}
