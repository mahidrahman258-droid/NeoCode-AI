package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.GeminiService
import com.example.data.models.*
import com.example.data.sample.SampleData
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class Screen {
    SPLASH, ONBOARDING, AUTH, DASHBOARD, WORKSPACE, PREVIEW, SETTINGS, PROFILE, EXTENSIONS, DEPLOY_CENTER, LIVE_COLLAB, AI_CHAT, AI_AGENTS, PROJECT_BRAIN
}

class MainViewModel : ViewModel() {

    // Active screen
    private val _activeScreen = MutableStateFlow(Screen.SPLASH)
    val activeScreen: StateFlow<Screen> = _activeScreen.asStateFlow()

    // Multi-File layout split mode
    private val _isSplitScreen = MutableStateFlow(false)
    val isSplitScreen = _isSplitScreen.asStateFlow()

    private val _splitActiveFile = MutableStateFlow<ProjectFile?>(null)
    val splitActiveFile = _splitActiveFile.asStateFlow()

    // Autonomous coding agents
    private val _isAgentRunning = MutableStateFlow(false)
    val isAgentRunning = _isAgentRunning.asStateFlow()

    private val _agentCurrentStep = MutableStateFlow(0)
    val agentCurrentStep = _agentCurrentStep.asStateFlow()

    private val _agentType = MutableStateFlow("Engine Agent") // "Engine Agent", "Linter Agent", "Deployer Agent"
    val agentType = _agentType.asStateFlow()

    private val _agentLogs = MutableStateFlow<List<String>>(emptyList())
    val agentLogs = _agentLogs.asStateFlow()

    private val _agentTaskInput = MutableStateFlow("Analyze main.ts security layout and apply optimizations")
    val agentTaskInput = _agentTaskInput.asStateFlow()

    // Semantic code search
    private val _semanticQuery = MutableStateFlow("")
    val semanticQuery = _semanticQuery.asStateFlow()

    private val _semanticResults = MutableStateFlow<List<SemanticResult>>(emptyList())
    val semanticResults = _semanticResults.asStateFlow()

    // Voice Controlled Coding
    private val _isVoiceListening = MutableStateFlow(false)
    val isVoiceListening = _isVoiceListening.asStateFlow()

    private val _voiceTranscription = MutableStateFlow("")
    val voiceTranscription = _voiceTranscription.asStateFlow()

    // Workflow automation
    private val _automations = MutableStateFlow<List<WorkflowAutomation>>(emptyList())
    val automations = _automations.asStateFlow()

    // Server Processes
    private val _serverProcesses = MutableStateFlow<List<ServerProcess>>(emptyList())
    val serverProcesses = _serverProcesses.asStateFlow()

    // Copilot Inline suggests
    private val _inlineSuggestion = MutableStateFlow("function processCompilation(code: string) {\n  return { status: 200, output: \"Compiling...\" };\n}")
    val inlineSuggestion = _inlineSuggestion.asStateFlow()

    private val _showInlineSuggestion = MutableStateFlow(true)
    val showInlineSuggestion = _showInlineSuggestion.asStateFlow()

    // Workspace memory store (Project Brain)
    private val _workspaceMemory = MutableStateFlow<Map<String, String>>(emptyMap())
    val workspaceMemory = _workspaceMemory.asStateFlow()

    // Startup Diagnostic Logs & Splash Progress
    private val _splashProgress = MutableStateFlow(0f)
    val splashProgress = _splashProgress.asStateFlow()

    private val _splashLog = MutableStateFlow("Initializing system core...")
    val splashLog = _splashLog.asStateFlow()

    // Project files & editing states
    private val _allFiles = MutableStateFlow<List<ProjectFile>>(emptyList())
    val allFiles = _allFiles.asStateFlow()

    private val _openTabs = MutableStateFlow<List<ProjectFile>>(emptyList())
    val openTabs = _openTabs.asStateFlow()

    private val _activeFile = MutableStateFlow<ProjectFile?>(null)
    val activeFile = _activeFile.asStateFlow()

    // Terminal State
    private val _terminalLogs = MutableStateFlow<List<String>>(emptyList())
    val terminalLogs = _terminalLogs.asStateFlow()

    private val _terminalInput = MutableStateFlow("")
    val terminalInput = _terminalInput.asStateFlow()

    private val _terminalType = MutableStateFlow("sh") // "sh" or "git" or "ssh" or "docker"
    val terminalType = _terminalType.asStateFlow()

    // AI Companion State
    private val _aiChatHistory = MutableStateFlow<List<Pair<String, Boolean>>>(emptyList()) // Pair of Content with IsUser
    val aiChatHistory = _aiChatHistory.asStateFlow()

    private val _aiInput = MutableStateFlow("")
    val aiInput = _aiInput.asStateFlow()

    private val _isAiThinking = MutableStateFlow(false)
    val isAiThinking = _isAiThinking.asStateFlow()

    // Collaboration Simulation State
    private val _collaborationActive = MutableStateFlow(false)
    val collaborationActive = _collaborationActive.asStateFlow()

    private val _cursors = MutableStateFlow<List<LiveUser>>(emptyList())
    val cursors = _cursors.asStateFlow()

    // Extensions & Deploy Center state
    private val _extensions = MutableStateFlow<List<ExtensionPlugin>>(emptyList())
    val extensions = _extensions.asStateFlow()

    private val _deploymentLogs = MutableStateFlow<List<DeploymentLog>>(emptyList())
    val deploymentLogs = _deploymentLogs.asStateFlow()

    // Theme state
    private val _currentTheme = MutableStateFlow("cyberpunk") // "cyberpunk", "dracula", "matrix", "horizon", "classic"
    val currentTheme = _currentTheme.asStateFlow()

    // Simulation metrics
    private val _fps = MutableStateFlow(60.0)
    val fps = _fps.asStateFlow()

    private val _streakDays = MutableStateFlow(25)
    val streakDays = _streakDays.asStateFlow()

    // Search and Replace
    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _replaceQuery = MutableStateFlow("")
    val replaceQuery = _replaceQuery.asStateFlow()

    // Authenticated User Info (Mock)
    private val _username = MutableStateFlow("NeoHacker")
    val username = _username.asStateFlow()

    init {
        // Run splash boot diagnostics
        triggerStartupDiagnostics()

        // Populate sample data
        _allFiles.value = SampleData.defaultFiles
        // Open main.ts by default in tabs
        val tsFile = SampleData.defaultFiles.firstOrNull()?.children?.firstOrNull { it.name == "main.ts" }
        if (tsFile != null) {
            _openTabs.value = listOf(tsFile)
            _activeFile.value = tsFile
        } else {
            val appDart = SampleData.defaultFiles.firstOrNull { it.name == "app.dart" }
            if (appDart != null) {
                _openTabs.value = listOf(appDart)
                _activeFile.value = appDart
            }
        }

        _extensions.value = SampleData.extensionPlugins
        _deploymentLogs.value = SampleData.initialDeploymentLogs
        _cursors.value = SampleData.liveUsers

        _automations.value = listOf(
            WorkflowAutomation("auto_linter", "Code Format On Save", "On File Save", "Format with ESLint analyzer", true),
            WorkflowAutomation("auto_gemini", "Auto-Fix Build Warnings", "On Code Error", "Ask Gemini AI to repair AST", true),
            WorkflowAutomation("auto_deploy", "Live Vercel Auto-Push", "On Git Push", "Re-launch production containers", false)
        )

        _serverProcesses.value = listOf(
            ServerProcess("Vite Compiler Daemon", 3000, "RUNNING", "[Vite] Hot update sockets listening at: http://localhost:3000"),
            ServerProcess("Python Neural Model Provider", 5000, "RUNNING", "⚡ Model weight maps compiled. Temperature scale: 0.25"),
            ServerProcess("Redis Workspace Cache State", 6379, "STOPPED", "Redis server asleep. Local state file fallback loaded.")
        )

        _workspaceMemory.value = mapOf(
            "Project Base" to "Holographic TypeScript/HTML web simulation container",
            "Root File Routing" to "main.ts manages editor states and compiler handshakes",
            "Authentication Layout" to "Auth keys verified against secure SHA-AES signatures",
            "Primary AI Connection" to "Gemini 3.5 Dynamic Flash handles background completions and context"
        )

        // Add default terminal prompt
        clearTerminal()
        addTerminalLog("⚡ NeoCode Core Virtual Environment Online.\nType 'help' for available commands.\n")
        addTerminalLog("neocode@compiler:~$ ")
    }

    private fun triggerStartupDiagnostics() {
        viewModelScope.launch {
            val steps = listOf(
                Pair(0.15f, "Mounting localized virtual workspaces... OK"),
                Pair(0.35f, "Loading lexical analyzers and code outlines... OK"),
                Pair(0.50f, "Binding terminal socket loops to localhost... OK"),
                Pair(0.70f, "Establishing neural pathways linking Gemini-3.5-flash... OK"),
                Pair(0.85f, "Syncing encryption certificates & API access keys... SECURE"),
                Pair(1.00f, "Launching hyper-threading cyberpunk holographic UI... LOADED")
            )

            for (step in steps) {
                delay(350)
                _splashProgress.value = step.first
                _splashLog.value = step.second
            }
            delay(400)
            _activeScreen.value = Screen.ONBOARDING
        }
    }

    fun completeOnboarding() {
        _activeScreen.value = Screen.AUTH
    }

    fun skipAuth() {
        _activeScreen.value = Screen.DASHBOARD
    }

    fun authenticate(user: String) {
        _username.value = user
        _streakDays.value = 26 // increment streak for logging in
        _activeScreen.value = Screen.DASHBOARD
    }

    fun navigateTo(screen: Screen) {
        _activeScreen.value = screen
    }

    // --- File operations ---
    fun selectFile(file: ProjectFile) {
        if (file.isFolder) return
        val currentTabs = _openTabs.value.toMutableList()
        if (!currentTabs.any { it.path == file.path }) {
            currentTabs.add(file)
            _openTabs.value = currentTabs
        }
        _activeFile.value = file
        addTerminalLog("\nOpened tab: ${file.name}\n${getTerminalPrompt()}")
    }

    fun closeTab(file: ProjectFile) {
        val currentTabs = _openTabs.value.toMutableList()
        currentTabs.removeAll { it.path == file.path }
        _openTabs.value = currentTabs
        
        if (_activeFile.value?.path == file.path) {
            _activeFile.value = currentTabs.lastOrNull()
        }
    }

    fun updateActiveFileContent(newContent: String) {
        val active = _activeFile.value ?: return
        val updated = active.copy(content = newContent, gitStatus = "modified")
        
        // Update tabs
        _openTabs.value = _openTabs.value.map {
            if (it.path == active.path) updated else it
        }
        _activeFile.value = updated

        // Update overall files list (deep structure helper)
        _allFiles.value = _allFiles.value.map { file ->
            if (file.path == active.path) {
                updated
            } else if (file.isFolder && file.children != null) {
                file.copy(children = file.children.map { subF ->
                    if (subF.path == active.path) updated else subF
                })
            } else {
                file
            }
        }
    }

    fun createNewFile(name: String, isFolder: Boolean, parentPath: String? = null) {
        val ext = if (isFolder) "" else name.substringAfterLast(".", "")
        val path = if (parentPath != null) "$parentPath/$name" else name
        val defaultContent = when (ext) {
            "html" -> "<!-- New HTML file -->\n<div>Hologram Activated</div>"
            "py" -> "# New python script\nprint('Compiled successfully!')"
            "js" -> "console.log('Script initiated!');"
            "ts" -> "export const code = () => 'NeoCode';"
            "dart" -> "void main() {\n  print('Dart initialed!');\n}"
            "rust" -> "fn main() {\n    println!(\"Rust rules!\");\n}"
            else -> ""
        }
        val newF = ProjectFile(
            name = name,
            path = path,
            extension = ext,
            content = defaultContent,
            isFolder = isFolder,
            children = if (isFolder) emptyList() else null,
            gitStatus = "added"
        )

        val updatedFiles = _allFiles.value.toMutableList()
        if (parentPath != null) {
            _allFiles.value = _allFiles.value.map { file ->
                if (file.path == parentPath && file.isFolder) {
                    file.copy(children = (file.children ?: emptyList()) + newF)
                } else {
                    file
                }
            }
        } else {
            updatedFiles.add(newF)
            _allFiles.value = updatedFiles
        }

        if (!isFolder) {
            selectFile(newF)
        }
        addTerminalLog("\nCreated file: $path\n${getTerminalPrompt()}")
    }

    fun searchAndReplace(search: String, replace: String) {
        _searchQuery.value = search
        _replaceQuery.value = replace
        val active = _activeFile.value ?: return
        if (search.isNotEmpty()) {
            val count = active.content.split(search).size - 1
            if (count > 0) {
                val replaced = active.content.replace(search, replace)
                updateActiveFileContent(replaced)
                addTerminalLog("\nSearch/Replace: Replaced $count instances of '$search' with '$replace'\n${getTerminalPrompt()}")
            }
        }
    }

    // --- Terminal Controls ---
    fun setTerminalInput(text: String) {
        _terminalInput.value = text
    }

    fun setTerminalType(type: String) {
        _terminalType.value = type
        clearTerminal()
        when (type) {
            "sh" -> addTerminalLog("⚡ Virtual Linux Shell v3.3.0 (x86_64).\nneocode@compiler:~$ ")
            "git" -> addTerminalLog("🤖 Git Client v2.41-neo. Current branch: [main]\nneocode@compiler:git:~$ ")
            "ssh" -> addTerminalLog("🔑 Secure Shell Connection Hub.\nType 'connect <ip>' to link remote nodes.\nneocode@ssh:~$ ")
            "docker" -> addTerminalLog("🐳 Container Daemon v24.0.5 local.\nAvailable images: node:slim, rust:alpine, python:3.10\nneocode@docker:~$ ")
        }
    }

    fun submitTerminalCommand(text: String) {
        val cmd = text.trim()
        if (cmd.isEmpty()) return
        
        _terminalInput.value = ""
        addTerminalLog("$cmd\n")

        when (_terminalType.value) {
            "sh" -> handleShellCommand(cmd)
            "git" -> handleGitCommand(cmd)
            "ssh" -> handleSshCommand(cmd)
            "docker" -> handleDockerCommand(cmd)
        }
        
        addTerminalLog(getTerminalPrompt())
    }

    private fun handleShellCommand(cmd: String) {
        val parts = cmd.split(" ")
        when (parts[0]) {
            "help" -> {
                addTerminalLog("Available Local Commands:\n" +
                        "  help                  Show list of virtual commands\n" +
                        "  ls                    List local project files\n" +
                        "  cat <file>            Print content of active files\n" +
                        "  compile <file>        Run compiler token analysis diagnostics on files\n" +
                        "  gemini generate <txt> Use AI to append code directly to current open workspace\n" +
                        "  clear                 Flush terminal bufferlogs\n" +
                        "  neofetch              Display luxury cyberpunk system specification charts")
            }
            "clear" -> clearTerminal()
            "ls" -> {
                val listing = _allFiles.value.joinToString("\n") { file ->
                    if (file.isFolder) "📁 ${file.name}/" else "📄 ${file.name} (.${file.extension})"
                }
                addTerminalLog("Directory Listing inside Workspace:\n$listing")
            }
            "cat" -> {
                if (parts.size < 2) {
                    addTerminalLog("Error: Missing target filename. e.g. 'cat main.ts'")
                    return
                }
                val filename = parts[1]
                val f = findFileByName(filename)
                if (f != null) {
                    addTerminalLog("--- ${f.name} ---\n${f.content}")
                } else {
                    addTerminalLog("File not found in Virtual Tree: $filename")
                }
            }
            "compile" -> {
                if (parts.size < 2) {
                    addTerminalLog("Syntax: compile <filename> -- e.g. compile main.ts")
                    return
                }
                val filename = parts[1]
                val f = findFileByName(filename)
                if (f != null) {
                    addTerminalLog("🚀 Testing code compilation path for [${f.name}]...\n")
                    addTerminalLog("Compiler Output: SUCCESS\nDiagnostic rating: Excellent.\nToken Errors: 0, Syntax Score: 100%.")
                    // trigger mock reload in preview
                    triggerHotReload()
                } else {
                    addTerminalLog("Compile Error: File unrecognized: $filename")
                }
            }
            "gemini" -> {
                if (parts.size < 3 || parts[1] != "generate") {
                    addTerminalLog("Syntax: gemini generate <prompt_describing_code>")
                    return
                }
                val aiPrompt = parts.drop(2).joinToString(" ")
                addTerminalLog("📡 Connecting to Gemini 3.5 Neural Grid...\n")
                viewModelScope.launch {
                    val result = GeminiService.generateContent(
                        "Write simple valid programming code based on requirements: $aiPrompt. Provide ONLY pure executable code without markdown blocks."
                    )
                    addTerminalLog("AI suggestions fetched correctly:\n\n$result\n")
                    // insert to current file
                    val active = _activeFile.value
                    if (active != null) {
                        updateActiveFileContent(active.content + "\n\n" + result)
                        addTerminalLog("Appended suggestion cleanly to the end of your file: ${active.name}.\n")
                    }
                }
            }
            "neofetch" -> {
                addTerminalLog("""
                   .-/+oossssoo+/-.               neocode@aistudio-v36
               `:+ssssssssssssssssss:`            OS: NeoCode Cyber-Android 11.2
             -+ssssssssssssssssssyyssss+-         Kernel: 6.8.0-generic-hologram
           .ossssssssssssssssssdMNNNssyyso.       Uptime: 25 hours, 42 mins
          /ssssssssssshdhyyssbNMMMNyyssssy/       Shell: neocode-cyber-sh v3.3
         /ssssssssshdNMMMNhsNdhyyssyyyssss/       Resolution: 1440x3120 Fluid High-Ref
        .osssssshdMMMMMMNyssssyyoosssssssso       DE: Cyberpunk Glassmorphism M3
        /ssssshNMMMMMNdyysssssssssssssssss/       Theme: Synthwave RGB Gradient
        /ssssssshhdyssssssssssssssssssssss/       Terminal Font: JetBrains Mono 12.0
        .ossssssssssssssssssssssssssssssso        GPU: Holographic Neural TPU v4
         /ssssssssssssssssssssssssssssss/         CPU: Core AI Quantum 12-Core
          /ssssssssssssssssssssssssssss/          Memory: 11250MB / 16384MB (Fast Mode)
           .osssssssssssssssssssssyyso.
             -+ssssssssssssssssyys+-
               `:+ssssssssssssss:`
                   .-/+ooo+/:.
                """.trimIndent())
            }
            else -> addTerminalLog("Command '$cmd' unrecognized. Use 'help' to review simulated commands.")
        }
    }

    private fun handleGitCommand(cmd: String) {
        val parts = cmd.split(" ")
        when (parts[0]) {
            "status" -> {
                val dirty = _allFiles.value.flatMap { 
                    if (it.isFolder) it.children ?: emptyList() else listOf(it) 
                }.filter { it.gitStatus != null }
                if (dirty.isEmpty()) {
                    addTerminalLog("On branch main\nYour branch is up to date with 'origin/main'.\n\nnothing to commit, working tree clean")
                } else {
                    val formatted = dirty.joinToString("\n") { "  ${if (it.gitStatus == "added") "new file:   " else "modified:   "}${it.path}" }
                    addTerminalLog("On branch main\nChanges to be committed:\n$formatted")
                }
            }
            "add" -> {
                addTerminalLog("Stage virtual assets... OK. Indexed all modified nodes.")
            }
            "commit" -> {
                val msg = if (parts.size > 2) parts.drop(2).joinToString(" ") else "Refactored components"
                addTerminalLog("[main aec90e5] $msg\n 3 files changed, 45 insertions(+), 8 deletions(-)")
                // clear git statuses
                _allFiles.value = _allFiles.value.map { file ->
                    val cleanFile = file.copy(gitStatus = null)
                    if (cleanFile.isFolder && cleanFile.children != null) {
                        cleanFile.copy(children = cleanFile.children.map { subF -> subF.copy(gitStatus = null) })
                    } else {
                        cleanFile
                    }
                }
                val active = _activeFile.value
                if (active != null) _activeFile.value = active.copy(gitStatus = null)
                _openTabs.value = _openTabs.value.map { it.copy(gitStatus = null) }
            }
            "push" -> {
                addTerminalLog("Enumerating objects: 7, done.\n" +
                        "Counting objects: 100% (7/7), done.\n" +
                        "Delta compression using up to 12 threads\n" +
                        "Compressing objects: 100% (4/4), done.\n" +
                        "Writing objects: 100% (5/5), 3.42 KiB | push successful.\n" +
                        "To github.com/neocode/cyber-applet.git\n" +
                        "   32ff78..aec90e5  main -> main")
            }
            "log" -> {
                addTerminalLog("commit aec90e59a7f32ee099 (HEAD -> main)\nAuthor: makgdbs9 <makgdbs9@gmail.com>\nDate:   May 25 18:50 2026\n\n    Add cyberpunk workspace layout + live Gemini suggestions\n\ncommit 32ff78be11c349a1aa\nAuthor: makgdbs9 <makgdbs9@gmail.com>\nDate:   May 22 10:14 2026\n\n    Initial configuration skeleton")
            }
            else -> addTerminalLog("Git option unrecognized. Supports: git status, git add, git commit -m 'msg', git push, git log")
        }
    }

    private fun handleSshCommand(cmd: String) {
        if (cmd.startsWith("connect")) {
            val ip = cmd.substringAfter("connect", "").trim()
            if (ip.isEmpty()) {
                addTerminalLog("Syntax: connect <host_address>")
                return
            }
            addTerminalLog("Initiating handshake key handshake with [$ip] on port 22...\n")
            viewModelScope.launch {
                delay(800)
                addTerminalLog("🔐 Connected!\nWelcome to remote micro-node @ $ip\nneocode@remote-node:~$ ")
            }
        } else {
            addTerminalLog("Remote command unknown. Run 'connect <ip>' to link your docker VM / production server.")
        }
    }

    private fun handleDockerCommand(cmd: String) {
        val parts = cmd.split(" ")
        when (parts[0]) {
            "ps" -> {
                addTerminalLog("CONTAINER ID   IMAGE          COMMAND                  CREATED         STATUS         PORTS\n" +
                        "c3e10fa48b4e   node:slim      \"docker-entrypoint.s…\"   2 hours ago     Up 2 hours     0.0.0.0:3000->3000/tcp\n" +
                        "992a5433a92a   rust:alpine    \"/bin/sh\"                5 hours ago     Up 5 hours\n" +
                        "88b8dc82ae22   redis:latest   \"docker-entrypoint.s…\"   25 hours ago    Up 24 hours    6379/tcp")
            }
            "images" -> {
                addTerminalLog("REPOSITORY   TAG       IMAGE ID       CREATED        SIZE\n" +
                        "node         slim      43a0e9bcfa3a   3 days ago     180MB\n" +
                        "rust         alpine    922fccca9a0a   1 week ago     420MB\n" +
                        "python       3.10      bca87b0aaeab   2 weeks ago    310MB\n" +
                        "redis        latest    cdfe80bbaf09   3 weeks ago    110MB")
            }
            "restart" -> {
                if (parts.size < 2) {
                    addTerminalLog("Syntax: restart <container_id>")
                    return
                }
                addTerminalLog("Signaling terminal stop to container [${parts[1]}]...\nRunning reboot hook. Container [${parts[1]}] is back online.")
            }
            else -> addTerminalLog("Docker commands: docker ps, docker images, docker restart <container_id>")
        }
    }

    private fun findFileByName(name: String): ProjectFile? {
        for (f in _allFiles.value) {
            if (f.name == name) return f
            if (f.isFolder && f.children != null) {
                for (sub in f.children) {
                    if (sub.name == name) return sub
                }
            }
        }
        return null
    }

    private fun getTerminalPrompt(): String {
        return when (_terminalType.value) {
            "sh" -> "neocode@compiler:~$ "
            "git" -> "neocode@compiler:git:~$ "
            "ssh" -> "neocode@ssh:~$ "
            "docker" -> "neocode@docker:~$ "
            else -> "neocode:~$ "
        }
    }

    private fun addTerminalLog(log: String) {
        val logs = _terminalLogs.value.toMutableList()
        logs.add(log)
        if (logs.size > 80) logs.removeAt(0) // keep buffer lean
        _terminalLogs.value = logs
    }

    private fun clearTerminal() {
        _terminalLogs.value = emptyList()
    }

    // --- AI Companion Controls ---
    fun setAiInput(text: String) {
        _aiInput.value = text
    }

    fun submitAiPrompt() {
        val prompt = _aiInput.value.trim()
        if (prompt.isEmpty() || _isAiThinking.value) return

        _aiInput.value = ""
        val history = _aiChatHistory.value.toMutableList()
        history.add(Pair(prompt, true))
        _aiChatHistory.value = history

        _isAiThinking.value = true
        
        viewModelScope.launch {
            // Setup specialized system context instruction based on selected file code context
            val currentFileContent = _activeFile.value?.content ?: ""
            val systemContext = """
                You are NeoCode AI, a world-class cyberpunk assistant IDE companion. 
                Your response must are helpful, direct, visually formatted.
                Active Workspace File Content:
                $currentFileContent
            """.trimIndent()

            val response = GeminiService.generateContent(prompt, systemContext)
            
            // Streaming visual effects in updates
            val finalHistory = _aiChatHistory.value.toMutableList()
            finalHistory.add(Pair(response, false))
            _aiChatHistory.value = finalHistory
            _isAiThinking.value = false
            
            // Suggest appending/updating files if the response contains code
            if (response.contains("```") && _activeFile.value != null) {
                addTerminalLog("\nAI suggested code edits for: ${_activeFile.value?.name}. Try 'gemini generate' in shell terminal to append immediately!\n${getTerminalPrompt()}")
            }
        }
    }

    fun triggerAiQuickAction(actionType: String) {
        if (_isAiThinking.value) return
        val active = _activeFile.value
        if (active == null) {
            val history = _aiChatHistory.value.toMutableList()
            history.add(Pair("AI Quick Diagnostics: No open file loaded. Please click any file from directory system.", false))
            _aiChatHistory.value = history
            return
        }

        val prompt = when (actionType) {
            "EXPLAIN" -> "Explain line-by-line of this code, highlight logical optimizations:\n\n${active.content}"
            "FIX" -> "Find potentials errors, security bugs or typing leaks and fix them:\n\n${active.content}"
            "REFACTOR" -> "Refactor this code to follow clean programming architecture. Use modern practices speed-ups:\n\n${active.content}"
            else -> "Inspect this code file: ${active.name}\n\n${active.content}"
        }

        _aiInput.value = ""
        val history = _aiChatHistory.value.toMutableList()
        // human prompt
        history.add(Pair("Quick Task: $actionType on file [${active.name}]", true))
        _aiChatHistory.value = history
        _isAiThinking.value = true

        viewModelScope.launch {
            val systemContext = "You are NeoCode AI, inspecting active file: ${active.name}"
            val response = GeminiService.generateContent(prompt, systemContext)
            
            val finalHistory = _aiChatHistory.value.toMutableList()
            finalHistory.add(Pair(response, false))
            _aiChatHistory.value = finalHistory
            _isAiThinking.value = false
        }
    }

    // --- Collaboration Simulation ---
    fun toggleCollaboration(enabled: Boolean) {
        _collaborationActive.value = enabled
        if (enabled) {
            addTerminalLog("\n🔑 Live Cryptographic Room Generated. ID: neo-collab-77af\n" +
                    "Avatars Kir_Dev and Zane_Cyber connected to shared workspace session.\n${getTerminalPrompt()}")
        } else {
            addTerminalLog("\n📡 Terminated shared collaboration room.\n${getTerminalPrompt()}")
        }
    }

    // --- Live Preview Simulator ---
    private fun triggerHotReload() {
        viewModelScope.launch {
            _fps.value = 52.4
            delay(200)
            _fps.value = 58.9
            delay(150)
            _fps.value = 60.0
            addTerminalLog("\n🔥 Hot reload simulator refreshed in 18ms cleanly.\n${getTerminalPrompt()}")
        }
    }

    fun runLiveSimulator() {
        _activeScreen.value = Screen.PREVIEW
        triggerHotReload()
    }

    // --- Extensions Marketplace ---
    fun toggleExtensionInstalled(id: String) {
        _extensions.value = _extensions.value.map {
            if (it.id == id) {
                val newStatus = !it.isInstalled
                addTerminalLog("\n${if (newStatus) "Installed" else "Removed"} marketplace extension: ${it.name}\n${getTerminalPrompt()}")
                it.copy(isInstalled = newStatus)
            } else {
                it
            }
        }
    }

    // --- Build & Deploy Client ---
    fun runDeployment(platformName: String) {
        val nextId = "dep-" + (10 + _deploymentLogs.value.size)
        val freshLog = DeploymentLog(nextId, "18:50:31", "Deployment to $platformName initialized by user makgdbs9.", "PENDING")
        val currentLogs = _deploymentLogs.value.toMutableList()
        currentLogs.add(0, freshLog)
        _deploymentLogs.value = currentLogs

        viewModelScope.launch {
            delay(1200)
            _deploymentLogs.value = _deploymentLogs.value.map {
                if (it.id == nextId) {
                    addTerminalLog("\n🌍 DEPLOYED SECURELY to $platformName! Server URL: https://$platformName.neocode.app\n${getTerminalPrompt()}")
                    it.copy(status = "SUCCESS")
                } else {
                    it
                }
            }
        }
    }

    // --- Theme Controller ---
    fun changeTheme(theme: String) {
        _currentTheme.value = theme
        addTerminalLog("\n🎨 Cyber Theme updated to: ${theme.uppercase()}\n${getTerminalPrompt()}")
    }

    // --- Multi-File Layout Split Mode ---
    fun toggleSplitScreen() {
        _isSplitScreen.value = !_isSplitScreen.value
        if (_isSplitScreen.value && _splitActiveFile.value == null) {
            val ts = _allFiles.value.flatMap { if (it.isFolder) it.children ?: emptyList() else listOf(it) }
            _splitActiveFile.value = ts.firstOrNull { it.path != _activeFile.value?.path && !it.isFolder }
        }
    }

    fun selectSplitFile(file: ProjectFile) {
        if (file.isFolder) return
        _splitActiveFile.value = file
        addTerminalLog("\nOpened secondary split tab: ${file.name}\n${getTerminalPrompt()}")
    }

    // --- Autonomous Coding Agent Simulator ---
    fun setAgentTaskInput(task: String) {
        _agentTaskInput.value = task
    }

    fun setAgentType(type: String) {
        _agentType.value = type
    }

    fun runAutonomousAgent() {
        if (_isAgentRunning.value) return
        _isAgentRunning.value = true
        _agentCurrentStep.value = 0
        _agentLogs.value = listOf(
            "🤖 Autonomous coding agent [${_agentType.value}] connected.",
            "Objective: ${_agentTaskInput.value}",
            "Memory footprint synchronized cleanly."
        )
        
        viewModelScope.launch {
            val steps = listOf(
                "Analyzing file tree targets & index.html structures...",
                "Drafting 4-point generative pipeline plan...",
                "Performing background lint trials with static checks...",
                "Refined neural vectors under full workspace memory...",
                "Writing clean additions and compiling AST block nodes! (SUCCESS)"
            )
            for (i in steps.indices) {
                delay(1200)
                _agentCurrentStep.value = i + 1
                val cl = _agentLogs.value.toMutableList()
                cl.add("[STEP ${i+1}/5] ${steps[i]}")
                _agentLogs.value = cl
            }
            delay(800)
            _isAgentRunning.value = false
            
            val active = _activeFile.value
            if (active != null) {
                val appendSnippet = "\n// --- Autonomous Additions [${_agentType.value}] ---\n// Task: ${_agentTaskInput.value}\n// Status: Code compiled stably in sandbox environment.\n"
                updateActiveFileContent(active.content + appendSnippet)
                addTerminalLog("\n🤖 ${_agentType.value} completed. Modified: ${active.name}\n${getTerminalPrompt()}")
            }
        }
    }

    // --- Semantic Search ---
    fun runSemanticSearch(query: String) {
        _semanticQuery.value = query
        if (query.isBlank()) {
            _semanticResults.value = emptyList()
            return
        }
        viewModelScope.launch {
            delay(400)
            val allFilesFlat = _allFiles.value.flatMap { if (it.isFolder) it.children ?: emptyList() else listOf(it) }
            val dummySemantics = listOf(
                SemanticResult("src/main.ts", "export async function processCompilation(code: string)", 16, 96, "Core AST parsing and transpilation handshake endpoint."),
                SemanticResult("ai_engine.py", "class Cybercompletions:", 5, 89, "Local neural AI inference provider weighting prompts."),
                SemanticResult("src/index.html", "<div class=\"container\">", 22, 78, "Main visual glassmorphic viewport for Web Simulator preview."),
                SemanticResult("app.dart", "void main() => runApp(const NeoApp());", 4, 72, "Mobile-responsive widget entry container setup.")
            )
            _semanticResults.value = dummySemantics.filter {
                it.filename.contains(query, ignoreCase = true) || 
                it.snippet.contains(query, ignoreCase = true) || 
                it.description.contains(query, ignoreCase = true)
            }
        }
    }

    // --- Voice Control STT ---
    fun toggleVoiceListening() {
        val listening = !_isVoiceListening.value
        _isVoiceListening.value = listening
        if (listening) {
            _voiceTranscription.value = "Establishing mic link..."
            viewModelScope.launch {
                delay(1200)
                _voiceTranscription.value = "Processing speech-to-text semantic tokens..."
                delay(1500)
                _voiceTranscription.value = "Transcript: 'Deploy app.dart mobile interface'"
                delay(1000)
                _isVoiceListening.value = false
                
                val dartFile = findFileByName("app.dart")
                if (dartFile != null) {
                    val searchString = "Text('NeoCode Premium Applet'"
                    val replaceString = "Text('NeoCode World-Class IDE'"
                    if (dartFile.content.contains(searchString)) {
                        val modified = dartFile.content.replace(searchString, replaceString)
                        // update dart file
                        _allFiles.value = _allFiles.value.map { file ->
                            if (file.path == dartFile.path) {
                                file.copy(content = modified, gitStatus = "modified")
                            } else if (file.isFolder && file.children != null) {
                                file.copy(children = file.children.map { sub ->
                                    if (sub.path == dartFile.path) sub.copy(content = modified, gitStatus = "modified") else sub
                                })
                            } else {
                                file
                            }
                        }
                        if (_activeFile.value?.path == dartFile.path) {
                            selectFile(dartFile.copy(content = modified, gitStatus = "modified"))
                        }
                        addTerminalLog("\n🎙️ [Voice-Parser] Matched Dart screen text! Updated 'NeoCode World-Class IDE'.\n${getTerminalPrompt()}")
                    }
                }
            }
        }
    }

    // --- Workflow Automator Rules ---
    fun toggleAutomationEnabled(id: String) {
        _automations.value = _automations.value.map {
            if (it.id == id) {
                val nextVal = !it.isEnabled
                addTerminalLog("\n⚡ Rule [${it.name}] set to: ${if (nextVal) "ACTIVE" else "DEACTIVATED"}\n${getTerminalPrompt()}")
                it.copy(isEnabled = nextVal)
            } else {
                it
            }
        }
    }

    // --- Process Control Toggles ---
    fun toggleServerProcess(name: String) {
        _serverProcesses.value = _serverProcesses.value.map {
            if (it.name == name) {
                val nextStatus = if (it.status == "RUNNING") "STOPPED" else "RUNNING"
                addTerminalLog("\n🐳 Thread group [$name] toggled: $nextStatus\n${getTerminalPrompt()}")
                it.copy(status = nextStatus)
            } else {
                it
            }
        }
    }

    // --- Copilot Inline Completion ---
    fun acceptInlineSuggestion(caretPos: Int) {
        val active = _activeFile.value ?: return
        val currentContent = active.content
        val insertText = _inlineSuggestion.value
        val nextContent = currentContent.substring(0, minOf(caretPos, currentContent.length)) + 
                "\n" + insertText + "\n" + 
                currentContent.substring(minOf(caretPos, currentContent.length))
        
        updateActiveFileContent(nextContent)
        _showInlineSuggestion.value = false
        addTerminalLog("\n🚀 Accept suggest: Integrated Copilot code chunk into active viewport.\n${getTerminalPrompt()}")
    }

    fun dismissInlineSuggestion() {
        _showInlineSuggestion.value = false
    }

    fun triggerNewInlineSuggestion() {
        _showInlineSuggestion.value = true
    }
}
