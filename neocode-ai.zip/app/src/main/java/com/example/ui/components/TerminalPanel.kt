package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.ui.theme.NeoPalette

/**
 * A beautiful cyberpunk-looking integrated hacker terminal panel, with active tab links
 * and custom typing animations for prompt executions.
 */
@Composable
fun TerminalPanel(
    viewModel: MainViewModel,
    palette: NeoPalette,
    modifier: Modifier = Modifier,
    onCloseClick: (() -> Unit)? = null
) {
    val logs by viewModel.terminalLogs.collectAsState()
    val terminalType by viewModel.terminalType.collectAsState()
    val terminalInput by viewModel.terminalInput.collectAsState()

    val listState = rememberLazyListState()

    // Scroll to bottom on log triggers
    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            listState.animateScrollToItem(logs.size - 1)
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .height(260.dp)
            .background(Color(0xFF020205))
            .border(1.dp, palette.primary.copy(alpha = 0.15f))
    ) {
        // 1. Terminal Header bar tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF080812))
                .drawBehind {
                    drawLine(
                        color = palette.primary.copy(alpha = 0.15f),
                        start = Offset(0f, size.height),
                        end = Offset(size.width, size.height),
                        strokeWidth = 2f
                    )
                },
            verticalAlignment = Alignment.CenterVertically
        ) {
            val tabs = listOf(
                Pair("sh", "Shell"),
                Pair("git", "Git VCS"),
                Pair("ssh", "Secure Node"),
                Pair("docker", "Docker Daemon")
            )

            tabs.forEach { (type, label) ->
                val isActive = terminalType == type
                Box(
                    modifier = Modifier
                        .clickable { viewModel.setTerminalType(type) }
                        .background(
                            if (isActive) Color(0xFF020205) else Color.Transparent
                        )
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                        .drawBehind {
                            if (isActive) {
                                drawLine(
                                    color = palette.primary,
                                    start = Offset(0f, size.height - 4f),
                                    end = Offset(size.width, size.height - 4f),
                                    strokeWidth = 6f
                                )
                            }
                        }
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Terminal,
                            contentDescription = null,
                            tint = if (isActive) palette.primary else palette.textSecondary.copy(alpha = 0.5f),
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = label,
                            color = if (isActive) palette.primary else palette.textSecondary,
                            fontSize = 11.sp,
                            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.weight(1f))
            if (onCloseClick != null) {
                IconButton(
                    onClick = onCloseClick,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Collapse terminal",
                        tint = palette.textSecondary,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }

        // 2. Output Logs Scroll
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(vertical = 8.dp, horizontal = 12.dp)
        ) {
            items(logs) { log ->
                Text(
                    text = log,
                    color = when (terminalType) {
                        "sh" -> Color(0xFF00FF66) // bright terminal green
                        "git" -> Color(0xFFF1FA8C) // bright amber
                        "ssh" -> Color(0xFFBD93F9) // nebula purple
                        else -> Color(0xFF8BE9FD) // dynamic cyber cyan
                    },
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    lineHeight = 15.sp
                )
            }
        }

        // 3. User Typing Line
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF010103))
                .padding(vertical = 4.dp, horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val prefix = when (terminalType) {
                "sh" -> "neocode@compiler:~$ "
                "git" -> "neocode@compiler:git:~$ "
                "ssh" -> "neocode@ssh:~$ "
                "docker" -> "neocode@docker:~$ "
                else -> "neocode:~$ "
            }

            Text(
                text = prefix,
                color = palette.primary,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )

            // Blinking cursor simulation in input field
            BasicTextField(
                value = terminalInput,
                onValueChange = { viewModel.setTerminalInput(it) },
                textStyle = TextStyle(
                    color = Color.White,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                ),
                cursorBrush = SolidColor(palette.primary),
                keyboardOptions = KeyboardOptions(
                    imeAction = ImeAction.Go
                ),
                keyboardActions = KeyboardActions(onGo = {
                    viewModel.submitTerminalCommand(terminalInput)
                }),
                singleLine = true,
                modifier = Modifier
                    .weight(1f)
                    .background(Color.Transparent)
            )
        }
    }
}
