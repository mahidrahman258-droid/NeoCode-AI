package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// General syntax highlighting colors
val CodeKeyword = Color(0xFFFF79C6) // Pink
val CodeFunction = Color(0xFF50FA7B) // Green
val CodeString = Color(0xFFF1FA8C) // Yellow
val CodeComment = Color(0xFF6272A4) // Slate grey-blue
val CodeVariable = Color(0xFF8BE9FD) // Cyan
val CodeNumber = Color(0xFFBD93F9) // Purple

// 1. Cyberpunk Neon Theme
val CyberBg = Color(0xFF030008)
val CyberSurface = Color(0xFF120822)
val CyberPrimary = Color(0xFF00F0FF) // Cyber Cyan
val CyberSecondary = Color(0xFFFF007F) // Holographic Pink
val CyberAccent = Color(0xFF9D4EDD) // Nebula Violet

// 2. Dracula AMOLED
val DracBg = Color(0xFF000000)
val DracSurface = Color(0xFF1E1F29)
val DracPrimary = Color(0xFFBD93F9) // Violet
val DracSecondary = Color(0xFF8BE9FD) // Sky Cyan
val DracAccent = Color(0xFF50FA7B) // Lime Green

// 3. Matrix Terminal
val MatrixBg = Color(0xFF000000)
val MatrixSurface = Color(0xFF0A0F0D)
val MatrixPrimary = Color(0xFF00FF33) // Lime Terminal
val MatrixSecondary = Color(0xFF006600) // Deep Terminal Green
val MatrixAccent = Color(0xFF00AA50) // Emerald

// 4. Horizon Sunset
val HorizonBg = Color(0xFF080202)
val HorizonSurface = Color(0xFF1F0D0D)
val HorizonPrimary = Color(0xFFFF7B00) // Solar Orange
val HorizonSecondary = Color(0xFFFF003C) // Flare Red
val HorizonAccent = Color(0xFFE0A96D) // Gold Dust

// 5. Classic VS Code
val VscBg = Color(0xFF1E1E1E)
val VscSurface = Color(0xFF252526)
val VscPrimary = Color(0xFF007ACC) // Dev Blue
val VscSecondary = Color(0xFF4FC1FF) // Sky Blue
val VscAccent = Color(0xFFDCDCAA) // Yellow-Khaki Code
