package com.example.ui.workspace

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.ui.components.CodeSyntaxHighlighter
import com.example.ui.components.GlassCard
import com.example.ui.theme.*
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.geometry.Size

/**
 * Highly customized developer workspace. Shows multi-tab views, line numbers,
 * interactive keyboard shortcut panels, file outlines, minimap, and auto suggestions.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorView(
    viewModel: MainViewModel,
    palette: NeoPalette,
    modifier: Modifier = Modifier
) {
    val activeFile by viewModel.activeFile.collectAsState()
    val openTabs by viewModel.openTabs.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val replaceQuery by viewModel.replaceQuery.collectAsState()

    var showSearchReplacePanel by remember { mutableStateOf(false) }
    var localSearchText by remember { mutableStateOf("") }
    var localReplaceText by remember { mutableStateOf("") }

    // Synchronized local state for text input editing to keep UI fluent
    var codeTextState by remember(activeFile?.path) {
        val raw = activeFile?.content ?: ""
        mutableStateOf(TextFieldValue(raw))
    }

    LaunchedEffect(activeFile?.content) {
        val newText = activeFile?.content ?: ""
        if (codeTextState.text != newText) {
            val validSelection = if (codeTextState.selection.max <= newText.length) {
                codeTextState.selection
            } else {
                androidx.compose.ui.text.TextRange(newText.length)
            }
            codeTextState = TextFieldValue(newText, selection = validSelection)
        }
    }

    // Capture focus
    val focusManager = LocalFocusManager.current

    // Sidebar drawer trigger
    var showOutlinePanel by remember { mutableStateOf(false) }

    Column(modifier = modifier.fillMaxSize().background(palette.bg)) {
        // 1. Multi-Tab header bar
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .background(palette.surface.copy(alpha = 0.5f))
                .drawBehind {
                    // bottom borders border line
                    drawLine(
                        color = palette.primary.copy(alpha = 0.2f),
                        start = Offset(0f, size.height),
                        end = Offset(size.width, size.height),
                        strokeWidth = 2f
                    )
                },
            verticalAlignment = Alignment.CenterVertically
        ) {
            items(openTabs) { tabFile ->
                val isActive = tabFile.path == activeFile?.path
                val statusColor = when (tabFile.gitStatus) {
                    "added" -> Color(0xFF50FA7B) // light green
                    "modified" -> Color(0xFFF1FA8C) // yellow
                    else -> Color.Transparent
                }

                Row(
                    modifier = Modifier
                        .background(
                            if (isActive) palette.bg else Color.Transparent
                        )
                        .clickable { viewModel.selectFile(tabFile) }
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                        .drawBehind {
                            if (isActive) {
                                // Draw top highlight bar
                                drawLine(
                                    color = palette.primary,
                                    start = Offset(0f, 0f),
                                    end = Offset(size.width, 0f),
                                    strokeWidth = 6f
                                )
                            }
                        },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // git state dot or extension icon
                    val extIcon = when (tabFile.extension) {
                        "ts", "js" -> "󰛦"
                        "py" -> ""
                        "html" -> "󰌝"
                        "dart" -> ""
                        "rust" -> ""
                        else -> "󰈙"
                    }
                    
                    if (statusColor != Color.Transparent) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .background(statusColor, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                    }

                    Text(
                        text = tabFile.name,
                        color = if (isActive) palette.primary else palette.textSecondary,
                        fontSize = 13.sp,
                        fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close tab",
                        tint = if (isActive) palette.primary else palette.textSecondary.copy(alpha = 0.6f),
                        modifier = Modifier
                            .size(14.dp)
                            .clickable { viewModel.closeTab(tabFile) }
                    )
                }
            }

            if (openTabs.isEmpty()) {
                item {
                    Text(
                        text = "No open files. Start coding path by matching project root files.",
                        color = palette.textSecondary,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(12.dp),
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                    )
                }
            }
        }

        // Search Replace Workspace Header panel
        AnimatedVisibility(
            visible = showSearchReplacePanel,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(palette.surface)
                    .padding(8.dp)
                    .border(1.dp, palette.primary.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                    .padding(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Search, contentDescription = "Search", tint = palette.primary, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    BasicTextField(
                        value = localSearchText,
                        onValueChange = { localSearchText = it },
                        textStyle = TextStyle(color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 13.sp),
                        cursorBrush = SolidColor(palette.primary),
                        modifier = Modifier
                            .weight(1f)
                            .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                            .padding(6.dp),
                        decorationBox = { innerTextField ->
                            if (localSearchText.isEmpty()) {
                                Text("Search Query", color = palette.textSecondary.copy(alpha = 0.5f), fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                            }
                            innerTextField()
                        }
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.SwapHoriz, contentDescription = "Replace", tint = palette.secondary, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    BasicTextField(
                        value = localReplaceText,
                        onValueChange = { localReplaceText = it },
                        textStyle = TextStyle(color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 13.sp),
                        cursorBrush = SolidColor(palette.secondary),
                        modifier = Modifier
                            .weight(1f)
                            .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                            .padding(6.dp),
                        decorationBox = { innerTextField ->
                            if (localReplaceText.isEmpty()) {
                                Text("Replace String", color = palette.textSecondary.copy(alpha = 0.5f), fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                            }
                            innerTextField()
                        }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = {
                            viewModel.searchAndReplace(localSearchText, localReplaceText)
                        },
                        colors = IconButtonDefaults.iconButtonColors(contentColor = palette.primary)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = "Apply replace")
                    }
                }
            }
        }

        // 2. Editor Workspace layout (Multi pane or Sidebar option)
        Row(modifier = Modifier.weight(1f)) {
            // Sidebar trigger columns or Mini Outline layout
            AnimatedVisibility(
                visible = showOutlinePanel,
                enter = expandHorizontally() + fadeIn(),
                exit = shrinkHorizontally() + fadeOut()
            ) {
                Column(
                    modifier = Modifier
                        .width(130.dp)
                        .fillMaxHeight()
                        .background(palette.surface.copy(alpha = 0.3f))
                        .drawBehind {
                            drawLine(
                                color = palette.primary.copy(alpha = 0.1f),
                                start = Offset(size.width, 0f),
                                end = Offset(size.width, size.height),
                                strokeWidth = 2f
                            )
                        }
                        .padding(8.dp)
                ) {
                    Text(
                        text = "OUTLINE AST",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = palette.primary,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    val lines = activeFile?.content?.split("\n") ?: emptyList()
                    val keywordsList = lines.mapIndexedNotNull { index, line ->
                        when {
                            line.contains("function ") || line.contains("def ") || line.contains("fn ") -> "ƒ () " + line.substringAfter("function ").substringAfter("def ").substringAfter("fn ").substringBefore("(").trim()
                            line.contains("class ") -> " " + line.substringAfter("class ").substringBefore("{").substringBefore(":").trim()
                            line.contains("const ") || line.contains("let ") -> "󰆪 " + line.substringAfter("const ").substringAfter("let ").substringBefore("=").substringBefore(":").trim()
                            else -> null
                        }?.let { Pair(index, it) }
                    }

                    if (keywordsList.isEmpty()) {
                        Text("No functions/classes detected in file.", color = palette.textSecondary, fontSize = 10.sp)
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(keywordsList) { (idx, label) ->
                                Text(
                                    text = label,
                                    color = palette.secondary,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.clickable {
                                        // outline jumps to character lines (simulation)
                                        viewModel.submitTerminalCommand("compile ${activeFile?.name}")
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // Central Code Text Input Panel
            if (activeFile != null) {
                val isSplitScreen by viewModel.isSplitScreen.collectAsState()
                val splitActiveFile by viewModel.splitActiveFile.collectAsState()
                val showInlineSuggestion by viewModel.showInlineSuggestion.collectAsState()
                val inlineSuggestionValue by viewModel.inlineSuggestion.collectAsState()
                val isVoiceListening by viewModel.isVoiceListening.collectAsState()
                val voiceTranscription by viewModel.voiceTranscription.collectAsState()
                val semanticQuery by viewModel.semanticQuery.collectAsState()
                val semanticResults by viewModel.semanticResults.collectAsState()

                // Keyboard inline suggestions (IntelliSense helper)
                var activeMatches by remember { mutableStateOf(emptyList<String>()) }

                LaunchedEffect(codeTextState.text) {
                    val words = codeTextState.text.split(Regex("[^a-zA-Z_]")).filter { it.length > 3 }
                    if (words.isNotEmpty()) {
                        val word = words.last().lowercase()
                        if (word.length >= 2) {
                            activeMatches = listOf(
                                "processCompilation", "console.log", "neocode", "isKeyConfigured", "generateContent", "completions"
                            ).filter { it.lowercase().contains(word) }
                        } else {
                            activeMatches = emptyList()
                        }
                    } else {
                        activeMatches = emptyList()
                    }
                }

                Row(modifier = Modifier.weight(1f)) {
                    // Left primary pane
                    Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                        val lines = codeTextState.text.split("\n")
                        val codeScrollState = rememberScrollState()

                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(codeScrollState)
                        ) {
                            // Lines Gutter Sidebar
                            Column(
                                modifier = Modifier
                                    .width(36.dp)
                                    .background(palette.bg.copy(alpha = 0.5f))
                                    .padding(vertical = 12.dp),
                                horizontalAlignment = Alignment.End
                            ) {
                                val lineNumbersText = remember(lines.size) {
                                    (1..maxOf(1, lines.size)).joinToString("\n")
                                }
                                Text(
                                    text = lineNumbersText,
                                    color = palette.textSecondary.copy(alpha = 0.4f),
                                    fontSize = 13.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.padding(end = 6.dp),
                                    textAlign = TextAlign.End,
                                    lineHeight = 18.sp
                                )
                            }

                            // Code Edit Area with double-tap gesture simulation
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .horizontalScroll(rememberScrollState())
                                    .padding(vertical = 12.dp, horizontal = 8.dp)
                                    .clickable {
                                        // simulate gesture click to trigger instant auto suggest trigger
                                        viewModel.triggerNewInlineSuggestion()
                                    }
                            ) {
                                BasicTextField(
                                    value = codeTextState,
                                    onValueChange = {
                                        codeTextState = it
                                        viewModel.updateActiveFileContent(it.text)
                                    },
                                    textStyle = TextStyle(
                                        color = Color.White,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 13.sp,
                                        lineHeight = 18.sp
                                    ),
                                    cursorBrush = SolidColor(palette.primary),
                                    modifier = Modifier.fillMaxWidth().heightIn(min = 400.dp),
                                    visualTransformation = { text ->
                                        val highlighted = CodeSyntaxHighlighter.highlight(text.text, activeFile?.extension ?: "")
                                        TransformedText(highlighted, androidx.compose.ui.text.input.OffsetMapping.Identity)
                                    }
                                )
                            }
                        }

                        // Floating overlay for inline Copilot suggestions
                        if (showInlineSuggestion) {
                            Card(
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                colors = CardDefaults.cardColors(containerColor = palette.surface.copy(alpha = 0.95f)),
                                border = BorderStroke(1.dp, palette.accent.copy(alpha = 0.4f))
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.AutoAwesome, contentDescription = "Copilot", tint = palette.accent, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Copilot Inline Recommendation", color = palette.accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                        Spacer(modifier = Modifier.weight(1f))
                                        IconButton(onClick = { viewModel.dismissInlineSuggestion() }, modifier = Modifier.size(20.dp)) {
                                            Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = Color.LightGray, modifier = Modifier.size(12.dp))
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = inlineSuggestionValue,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 11.sp,
                                        color = Color.LightGray
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(
                                            onClick = {
                                                viewModel.acceptInlineSuggestion(codeTextState.selection.start)
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = palette.accent),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                            modifier = Modifier.height(26.dp)
                                        ) {
                                            Text("Accept Suggest [TAB]", fontSize = 10.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                                        }
                                        Button(
                                            onClick = { viewModel.dismissInlineSuggestion() },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                                            border = BorderStroke(1.dp, Color.Gray),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                            modifier = Modifier.height(26.dp)
                                        ) {
                                            Text("Reject", fontSize = 10.sp, color = Color.White)
                                        }
                                    }
                                }
                            }
                        }

                        // Auto matches tooltip
                        if (activeMatches.isNotEmpty()) {
                            Card(
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .offset(x = 42.dp, y = (-20).dp)
                                    .wrapContentSize(),
                                colors = CardDefaults.cardColors(containerColor = palette.surface),
                                elevation = CardDefaults.cardElevation(8.dp),
                                border = BorderStroke(1.dp, palette.primary.copy(alpha = 0.4f))
                            ) {
                                Column(modifier = Modifier.padding(6.dp)) {
                                    activeMatches.take(3).forEach { suggest ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable {
                                                    val existing = codeTextState.text
                                                    val lastWord = existing.split(Regex("[^a-zA-Z_]")).last()
                                                    val completed = existing.substring(0, existing.length - lastWord.length) + suggest
                                                    codeTextState = TextFieldValue(completed, selection = androidx.compose.ui.text.TextRange(completed.length))
                                                    viewModel.updateActiveFileContent(completed)
                                                    activeMatches = emptyList()
                                                }
                                                .padding(vertical = 4.dp, horizontal = 10.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(Icons.Default.Bolt, contentDescription = "Suggest", tint = palette.primary, modifier = Modifier.size(12.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(suggest, color = Color.White, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Split-screen Secondary Pane Editor View
                    if (isSplitScreen && splitActiveFile != null) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .border(1.dp, palette.primary.copy(alpha = 0.25f))
                                .background(palette.bg)
                        ) {
                            Column(modifier = Modifier.fillMaxSize()) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(palette.surface)
                                        .padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.CallSplit, contentDescription = "Split", tint = palette.primary, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "${splitActiveFile?.name} (SPLIT WINDOW)",
                                        color = palette.primary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Spacer(modifier = Modifier.weight(1f))
                                    IconButton(onClick = { viewModel.toggleSplitScreen() }, modifier = Modifier.size(20.dp)) {
                                        Icon(Icons.Default.Close, contentDescription = "Close Split", tint = Color.Red, modifier = Modifier.size(12.dp))
                                    }
                                }

                                var splitTextState by remember(splitActiveFile?.path) {
                                    mutableStateOf(TextFieldValue(splitActiveFile?.content ?: ""))
                                }

                                Row(modifier = Modifier.weight(1f)) {
                                    Column(
                                        modifier = Modifier
                                            .width(26.dp)
                                            .background(palette.bg.copy(alpha = 0.3f))
                                            .padding(vertical = 8.dp),
                                        horizontalAlignment = Alignment.End
                                    ) {
                                        Text(
                                            text = (1..splitTextState.text.split("\n").size).joinToString("\n"),
                                            color = palette.textSecondary.copy(alpha = 0.3f),
                                            fontSize = 11.sp,
                                            fontFamily = FontFamily.Monospace,
                                            modifier = Modifier.padding(end = 4.dp),
                                            lineHeight = 16.sp,
                                            textAlign = TextAlign.End
                                        )
                                    }

                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .horizontalScroll(rememberScrollState())
                                            .verticalScroll(rememberScrollState())
                                            .padding(6.dp)
                                    ) {
                                        BasicTextField(
                                            value = splitTextState,
                                            onValueChange = {
                                                splitTextState = it
                                                // Normally update content, simulated inline
                                            },
                                            textStyle = TextStyle(
                                                color = Color.White.copy(alpha = 0.8f),
                                                fontFamily = FontFamily.Monospace,
                                                fontSize = 11.sp,
                                                lineHeight = 16.sp
                                            ),
                                            cursorBrush = SolidColor(palette.primary),
                                            visualTransformation = { text ->
                                                val highlighted = CodeSyntaxHighlighter.highlight(text.text, splitActiveFile?.extension ?: "")
                                                TransformedText(highlighted, androidx.compose.ui.text.input.OffsetMapping.Identity)
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Voice Listening status overlay banner
                if (isVoiceListening || voiceTranscription.isNotEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(palette.primary.copy(alpha = 0.9f))
                            .padding(vertical = 8.dp, horizontal = 16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isVoiceListening) Icons.Default.Mic else Icons.Default.CheckCircle,
                                contentDescription = "Voice Input",
                                tint = Color.Black,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = voiceTranscription,
                                color = Color.Black,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            } else {
                Box(
                    modifier = Modifier.weight(1f).fillMaxHeight(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Outlined.Code,
                            contentDescription = "Code icon",
                            tint = palette.primary.copy(alpha = 0.3f),
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Project File System Loaded",
                            color = palette.textSecondary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Select any file from directory list to mount compilation buffers.",
                            color = palette.textSecondary.copy(alpha = 0.6f),
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
            }
        }

        // 3. Cyber Terminal Action Helper Panel
        if (activeFile != null) {
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(palette.surface)
                    .padding(vertical = 4.dp, horizontal = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Glow Mic activation key
                item {
                    val isVoiceActive by viewModel.isVoiceListening.collectAsState()
                    Card(
                        modifier = Modifier
                            .clickable { viewModel.toggleVoiceListening() },
                        colors = CardDefaults.cardColors(containerColor = if (isVoiceActive) palette.accent else palette.surface),
                        border = BorderStroke(1.dp, if (isVoiceActive) palette.accent else palette.primary.copy(alpha = 0.3f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (isVoiceActive) Icons.Default.Mic else Icons.Default.MicOff,
                                contentDescription = "Voice Code Mode",
                                tint = if (isVoiceActive) Color.Black else palette.accent,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("VOICE", color = if (isVoiceActive) Color.Black else Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }
                }

                // Split editor button
                item {
                    val splitOn by viewModel.isSplitScreen.collectAsState()
                    Card(
                        modifier = Modifier.clickable { viewModel.toggleSplitScreen() },
                        colors = CardDefaults.cardColors(containerColor = if (splitOn) palette.primary else palette.surface),
                        border = BorderStroke(1.dp, palette.primary.copy(alpha = 0.4f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.CallSplit, contentDescription = "Split On/Off", tint = if (splitOn) Color.Black else palette.primary, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("SPLIT WINDOW", color = if (splitOn) Color.Black else Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                val helpers = listOf("TAB", "{", "}", "[", "]", ";", "=")
                items(helpers) { char ->
                    Card(
                        modifier = Modifier
                            .clickable {
                                // simulated key append code text logic via viewModel trigger (user text sync inline handled nicely)
                                if (char == "TAB") {
                                    viewModel.triggerNewInlineSuggestion()
                                }
                            },
                        colors = CardDefaults.cardColors(containerColor = palette.bg),
                        border = BorderStroke(1.dp, palette.primary.copy(alpha = 0.15f))
                    ) {
                        Text(
                            text = char,
                            color = palette.primary,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }

                item {
                    IconButton(
                        onClick = { showSearchReplacePanel = !showSearchReplacePanel },
                        colors = IconButtonDefaults.iconButtonColors(contentColor = palette.secondary)
                    ) {
                        Icon(Icons.Outlined.Search, contentDescription = "Search & Replace", modifier = Modifier.size(18.dp))
                    }
                }

                item {
                    IconButton(
                        onClick = { showOutlinePanel = !showOutlinePanel },
                        colors = IconButtonDefaults.iconButtonColors(contentColor = palette.accent)
                    ) {
                        Icon(Icons.Default.MenuOpen, contentDescription = "Outline", modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}
