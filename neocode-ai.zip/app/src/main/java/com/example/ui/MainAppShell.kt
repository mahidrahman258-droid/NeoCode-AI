package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.BuildConfig
import com.example.data.api.GeminiService
import com.example.data.models.*
import com.example.ui.components.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NeoPalette
import com.example.ui.theme.NeoTheme
import com.example.ui.workspace.EditorView
import com.example.ui.workspace.FileTreeSidebar
import kotlinx.coroutines.delay

@Composable
fun MainAppShell(viewModel: MainViewModel) {
    val activeScreen by viewModel.activeScreen.collectAsState()
    val themeName by viewModel.currentTheme.collectAsState()
    val palette = NeoTheme.getPalette(themeName)

    MyApplicationTheme(themeName = themeName) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = palette.bg
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                // Background Matrix grid falling code bits loop
                if (activeScreen == Screen.SPLASH || activeScreen == Screen.ONBOARDING || activeScreen == Screen.AUTH) {
                    MatrixCanvas(palette = palette)
                }

                // Master Router
                Crossfade(targetState = activeScreen, label = "master_screen_router") { screen ->
                    when (screen) {
                        Screen.SPLASH -> SplashScreenView(viewModel, palette)
                        Screen.ONBOARDING -> OnboardingView(viewModel, palette)
                        Screen.AUTH -> AuthView(viewModel, palette)
                        else -> MainDashboardContainer(viewModel, palette, activeScreen)
                    }
                }
            }
        }
    }
}

// ==========================================
// 1. SPLASH SCREEN (Diagnostic Startup)
// ==========================================
@Composable
fun SplashScreenView(viewModel: MainViewModel, palette: NeoPalette) {
    val progress by viewModel.splashProgress.collectAsState()
    val logStr by viewModel.splashLog.collectAsState()

    val infiniteTransition = rememberInfiniteTransition(label = "logo_rotation")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(2800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "logo_rotation"
    )

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Futuristic Hologram Logo Frame
        Box(
            modifier = Modifier
                .size(100.dp)
                .drawBehind {
                    drawCircle(
                        color = palette.primary.copy(alpha = 0.15f),
                        radius = size.minDimension / 2 + 12.dp.toPx()
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Cyclone,
                contentDescription = null,
                tint = palette.primary,
                modifier = Modifier
                    .size(64.dp)
                    .rotate(rotation)
            )
        }

        Spacer(modifier = Modifier.height(28.dp))
        Text(
            text = "NEOCODE AI",
            color = palette.primary,
            fontSize = 28.sp,
            fontWeight = FontWeight.ExtraBold,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 3.sp,
            textAlign = TextAlign.Center
        )
        Text(
            text = "HOLOGRAPHIC COMPILER ENVIRONMENT",
            color = palette.secondary,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 1.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 4.dp)
        )

        Spacer(modifier = Modifier.height(60.dp))
        GlassCard(
            palette = palette,
            borderGlow = true,
            borderColor = palette.primary.copy(alpha = 0.3f),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
        ) {
            Text(
                text = "SYSTEM BOOT FLOW DIAGNOSTICS",
                color = palette.primary,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Text(
                text = logStr,
                color = Color.White,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                lineHeight = 16.sp,
                modifier = Modifier.height(48.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                color = palette.primary,
                trackColor = palette.surface.copy(alpha = 0.2f)
            )
        }
    }
}

// ==========================================
// 2. ONBOARDING SCREEN
// ==========================================
@Composable
fun OnboardingView(viewModel: MainViewModel, palette: NeoPalette) {
    var stepIndex by remember { mutableStateOf(0) }
    val details = listOf(
        Pair("NEURAL CODING", "Write code 10x faster with our contextual, fine-tuned direct Gemini integrations and code generation blocks."),
        Pair("LIVE REPLICAS", "Simulate instant compilation previews on multiple frameworks with active Hot Reload triggers."),
        Pair("HACKER INTERFACE", "Command multi-pane terminals, dock remote servers over SSH, and control local docker networks effortlessly.")
    )

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Bottom
    ) {
        Spacer(modifier = Modifier.weight(1f))
        
        // Large visual indicator card
        GlassCard(
            palette = palette,
            borderGlow = true,
            modifier = Modifier.fillMaxWidth(),
            borderColor = palette.secondary
        ) {
            Icon(
                imageVector = when (stepIndex) {
                    0 -> Icons.Default.AutoAwesome
                    1 -> Icons.Default.Devices
                    else -> Icons.Default.Terminal
                },
                contentDescription = null,
                tint = palette.primary,
                modifier = Modifier.size(48.dp).align(Alignment.CenterHorizontally)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = details[stepIndex].first,
                color = palette.primary,
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = FontFamily.Monospace,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = details[stepIndex].second,
                color = palette.textSecondary,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                lineHeight = 18.sp,
                modifier = Modifier.fillMaxWidth()
            )
        }

        Spacer(modifier = Modifier.height(40.dp))
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Step dots
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                repeat(3) { d ->
                    Box(
                        modifier = Modifier
                            .size(if (d == stepIndex) 20.dp else 8.dp, 8.dp)
                            .clip(CircleShape)
                            .background(if (d == stepIndex) palette.primary else palette.primary.copy(alpha = 0.2f))
                    )
                }
            }

            NeonButton(
                text = if (stepIndex == 2) "INIT" else "NEXT",
                palette = palette,
                onClick = {
                    if (stepIndex == 2) {
                        viewModel.completeOnboarding()
                    } else {
                        stepIndex++
                    }
                }
            )
        }
    }
}

// ==========================================
// 3. AUTHENTICATION (Cyber credentials)
// ==========================================
@Composable
fun AuthView(viewModel: MainViewModel, palette: NeoPalette) {
    var usernameField by remember { mutableStateOf("NeoHacker") }
    var passwordField by remember { mutableStateOf("••••••••") }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "SECURITY ACCESS KEY",
            color = palette.primary,
            fontSize = 18.sp,
            fontWeight = FontWeight.ExtraBold,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 2.sp,
            modifier = Modifier.padding(bottom = 16.dp).align(Alignment.CenterHorizontally)
        )

        GlassCard(
            palette = palette,
            modifier = Modifier.fillMaxWidth(),
            borderColor = palette.primary
        ) {
            OutlinedTextField(
                value = usernameField,
                onValueChange = { usernameField = it },
                label = { Text("DEVELOPER INTEL-NAME", fontSize = 11.sp, fontFamily = FontFamily.Monospace) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = palette.primary,
                    unfocusedBorderColor = palette.primary.copy(alpha = 0.3f),
                    focusedLabelColor = palette.primary,
                    unfocusedLabelColor = palette.textSecondary
                ),
                textStyle = TextStyle(fontFamily = FontFamily.Monospace, color = Color.White),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(12.dp))
            OutlinedTextField(
                value = passwordField,
                onValueChange = { passwordField = it },
                label = { Text("CREDENTIAL SIGNATURE", fontSize = 11.sp, fontFamily = FontFamily.Monospace) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = palette.primary,
                    unfocusedBorderColor = palette.primary.copy(alpha = 0.3f),
                    focusedLabelColor = palette.primary,
                    unfocusedLabelColor = palette.textSecondary
                ),
                textStyle = TextStyle(fontFamily = FontFamily.Monospace, color = Color.White),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(20.dp))
            NeonButton(
                text = "AUTHORIZE SYSTEM LINK",
                palette = palette,
                onClick = { viewModel.authenticate(usernameField) },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(12.dp))
            TextButton(
                onClick = { viewModel.skipAuth() },
                modifier = Modifier.align(Alignment.CenterHorizontally)
            ) {
                Text("Bypass authorization (Local Sandbox Only)", color = palette.primary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

// ==========================================
// master container navigation & sections
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainDashboardContainer(
    viewModel: MainViewModel,
    palette: NeoPalette,
    activeScreen: Screen
) {
    var sidebarOpen by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Terminal, "Holo Logo", tint = palette.primary, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "NEOCODE AI",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = palette.primary,
                            letterSpacing = 1.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { sidebarOpen = !sidebarOpen }) {
                        Icon(
                            imageVector = if (sidebarOpen) Icons.Default.MenuOpen else Icons.Default.Menu,
                            contentDescription = "Expand Sidebar Workspace",
                            tint = palette.primary
                        )
                    }
                },
                actions = {
                    // Start Hot simulator trigger
                    IconButton(onClick = { viewModel.runLiveSimulator() }) {
                        Icon(Icons.Default.PlayArrow, "Start Live hot reload simulator", tint = palette.secondary)
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = palette.surface,
                    titleContentColor = palette.primary
                )
            )
        },
        bottomBar = {
            // Interactive glowing floating bottom navigation
            NavigationBar(
                containerColor = palette.surface,
                tonalElevation = 8.dp
            ) {
                val navItems = listOf(
                    Triple(Screen.DASHBOARD, Icons.Default.Home, "DASH"),
                    Triple(Screen.WORKSPACE, Icons.Default.Code, "WORKSPACE"),
                    Triple(Screen.AI_CHAT, Icons.Default.AutoAwesome, "CO-PILOT"),
                    Triple(Screen.DEPLOY_CENTER, Icons.Default.CloudUpload, "DEPLOY"),
                    Triple(Screen.PROFILE, Icons.Default.Person, "STACK")
                )

                navItems.forEach { (sc, icon, label) ->
                    val isActive = sc == activeScreen
                    NavigationBarItem(
                        selected = isActive,
                        onClick = { viewModel.navigateTo(sc) },
                        icon = { Icon(icon, null, tint = if (isActive) palette.primary else palette.textSecondary) },
                        label = { Text(label, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal) },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = palette.primary.copy(alpha = 0.15f)
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Interactive File system Sidebar layout
            AnimatedVisibility(
                visible = sidebarOpen,
                enter = expandHorizontally() + fadeIn(),
                exit = shrinkHorizontally() + fadeOut()
            ) {
                FileTreeSidebar(
                    viewModel = viewModel,
                    palette = palette,
                    modifier = Modifier.width(220.dp)
                )
            }

            Box(modifier = Modifier.weight(1f)) {
                // Panel Screens router
                Crossfade(targetState = activeScreen, label = "active_screen_panel") { current ->
                    when (current) {
                        Screen.DASHBOARD -> HomeDashboardView(viewModel, palette)
                        Screen.WORKSPACE -> EditorTerminalView(viewModel, palette)
                        Screen.AI_CHAT -> AiAssistantView(viewModel, palette)
                        Screen.DEPLOY_CENTER -> DeployCenterView(viewModel, palette)
                        Screen.PROFILE -> ProfileView(viewModel, palette)
                        Screen.PREVIEW -> LivePreviewSimulator(viewModel, palette)
                        Screen.SETTINGS -> SettingsView(viewModel, palette)
                        Screen.EXTENSIONS -> ExtensionsMarketView(viewModel, palette)
                        Screen.LIVE_COLLAB -> LiveCollaborationWorkspace(viewModel, palette)
                        Screen.AI_AGENTS -> AiAgentsWorkspaceView(viewModel, palette)
                        Screen.PROJECT_BRAIN -> ProjectBrainView(viewModel, palette)
                        else -> Text("Default View", color = Color.White)
                    }
                }
            }
        }
    }
}

// ==========================================
// 4. HOME DASHBOARD VIEW
// ==========================================
@Composable
fun HomeDashboardView(viewModel: MainViewModel, palette: NeoPalette) {
    val username by viewModel.username.collectAsState()
    val streakDays by viewModel.streakDays.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            // Header Info Widget
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("SYSTEM NODE: SECURE", color = palette.primary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    Text(
                        text = "Hello, dev: $username",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // Cloud Status
                Card(
                    colors = CardDefaults.cardColors(containerColor = palette.primary.copy(alpha = 0.1f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(modifier = Modifier.size(8.dp).background(Color(0xFF00FF66), CircleShape))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("CLOUD SYNCED", color = palette.primary, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            // Stats summary row
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                GlassCard(palette = palette, modifier = Modifier.weight(1f)) {
                    Text("STREAK LOGS", fontSize = 10.sp, color = palette.primary, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("$streakDays DAYS", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = Color.White, fontFamily = FontFamily.Monospace)
                    Text("Active compiler sessions", fontSize = 8.sp, color = palette.textSecondary)
                }

                GlassCard(palette = palette, modifier = Modifier.weight(1f)) {
                    Text("EXTENSIONS", fontSize = 10.sp, color = palette.secondary, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("4 ACTIVE", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = Color.White, fontFamily = FontFamily.Monospace)
                    Text("Optimizations running", fontSize = 8.sp, color = palette.textSecondary)
                }
            }
        }

        item {
            // Quick assistant Actions widgets
            Text(
                text = "ASSISTANT SHORTCUT CHANNELS",
                color = palette.primary,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    Pair("EXPLAIN CODE", "EXPLAIN"),
                    Pair("REFACTOR", "REFACTOR"),
                    Pair("BUG FINDER", "FIX")
                ).forEach { (label, action) ->
                    NeonButton(
                        text = label,
                        palette = palette,
                        onClick = {
                            viewModel.triggerAiQuickAction(action)
                            viewModel.navigateTo(Screen.AI_CHAT)
                        },
                        modifier = Modifier.weight(1f),
                        isSecondary = true
                    )
                }
            }
        }

        item {
            // Quick Dashboard shortcuts
            Text(
                text = "NEO CORE COMPILER MODULES",
                color = palette.secondary,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                val menu = listOf(
                    Triple("Autonomous Coder Agents", "Prompt autonomous bots to analyze, lint or build target AST nodes", Screen.AI_AGENTS),
                    Triple("Project Brain Workspace Memory", "Semantic search index, daemon processes, automatons", Screen.PROJECT_BRAIN),
                    Triple("Extensions Marketplace Store", "Download visual styling, IntelliSense algorithms", Screen.EXTENSIONS),
                    Triple("Cloud Environment Settings", "Customize dark theme colors, load API Keys", Screen.SETTINGS),
                    Triple("Live Sync Room Collab", "Host shared compiler voice rooms with other devs", Screen.LIVE_COLLAB)
                )

                menu.forEach { (label, sub, scr) ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.navigateTo(scr) },
                        colors = CardDefaults.cardColors(containerColor = palette.surface),
                        border = BorderStroke(1.dp, palette.primary.copy(alpha = 0.1f))
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Launch, null, tint = palette.primary, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                Text(sub, color = palette.textSecondary, fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 5. WORKSPACE EDITOR GRID WITH ACTIVE TERMINAL PANEL
// ==========================================
@Composable
fun EditorTerminalView(viewModel: MainViewModel, palette: NeoPalette) {
    var showTerminalBuffer by remember { mutableStateOf(true) }

    Column(modifier = Modifier.fillMaxSize()) {
        // Main multi-tab interactive editor
        EditorView(
            viewModel = viewModel,
            palette = palette,
            modifier = Modifier.weight(1f)
        )

        // Docked panel simulated terminal
        if (showTerminalBuffer) {
            TerminalPanel(
                viewModel = viewModel,
                palette = palette,
                onCloseClick = { showTerminalBuffer = false }
            )
        } else {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF06060E))
                    .clickable { showTerminalBuffer = true }
                    .padding(10.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Terminal, null, tint = palette.primary, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("RESTORE INTEGRATED SHELL TERMINAL", color = palette.primary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

// ==========================================
// 6. AI ASSISTANT CHAT DIALOGUE
// ==========================================
@Composable
fun AiAssistantView(viewModel: MainViewModel, palette: NeoPalette) {
    val chatHistory by viewModel.aiChatHistory.collectAsState()
    val isThinking by viewModel.isAiThinking.collectAsState()
    val aiInput by viewModel.aiInput.collectAsState()

    val keyConfigured = remember { GeminiService.isKeyConfigured() }

    Column(
        modifier = Modifier.fillMaxSize().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Warning if default key empty
        if (!keyConfigured) {
            Card(
                colors = CardDefaults.cardColors(containerColor = palette.secondary.copy(alpha = 0.12f)),
                border = BorderStroke(1.dp, palette.secondary.copy(alpha = 0.4f))
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Warning, "Key warning", tint = palette.secondary, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "SANDBOX SIMULATOR: Insert Gemini API Key via Settings tab to link live LLM.",
                        color = palette.secondary,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Output chats history lazy view
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(chatHistory) { (txt, isUser) ->
                val bubbleColor = if (isUser) palette.primary.copy(alpha = 0.15f) else palette.surface
                val labelColor = if (isUser) palette.primary else palette.secondary
                
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = if (isUser) 16.dp else 4.dp),
                    colors = CardDefaults.cardColors(containerColor = bubbleColor),
                    border = BorderStroke(1.dp, labelColor.copy(alpha = 0.15f))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = if (isUser) "󰅴 DEVELOPER PROMPT" else "󰄛 NEO AI COMPILER",
                            color = labelColor,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                        SelectionContainer {
                            Text(
                                text = txt,
                                color = Color.White,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }
            }

            if (isThinking) {
                item {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(14.dp), color = palette.primary, strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "AI thinking... parsing lexical AST token trees",
                            color = palette.primary,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            if (chatHistory.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier.fillParentMaxHeight(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.AutoAwesome, null, tint = palette.primary.copy(alpha = 0.3f), modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("NEOCONTEXT CHAT SYSTEM", color = palette.primary, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Text("Provide suggestions about your files, ask how to debug warning blocks, or generate code.", color = palette.textSecondary, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(12.dp))
                        }
                    }
                }
            }
        }

        // Dynamic Text Prompt inputs
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = aiInput,
                onValueChange = { viewModel.setAiInput(it) },
                placeholder = { Text("Ask Copilot... (e.g. Write bubble sort rust script)", fontSize = 12.sp, color = palette.textSecondary.copy(alpha = 0.4f)) },
                modifier = Modifier.weight(1f),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = palette.primary,
                    unfocusedBorderColor = palette.primary.copy(alpha = 0.2f)
                ),
                textStyle = TextStyle(fontSize = 12.sp, fontFamily = FontFamily.Monospace, color = Color.White),
                shape = RoundedCornerShape(8.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            IconButton(
                onClick = { viewModel.submitAiPrompt() },
                colors = IconButtonDefaults.iconButtonColors(containerColor = palette.primary, contentColor = Color.Black),
                modifier = Modifier.size(48.dp).clip(RoundedCornerShape(8.dp))
            ) {
                Icon(Icons.Default.Send, contentDescription = "Submit chat")
            }
        }
    }
}

// ==========================================
// 7. DEPLOY WEB/MOBILE PLATFORMS CENTER
// ==========================================
@Composable
fun DeployCenterView(viewModel: MainViewModel, palette: NeoPalette) {
    val logs by viewModel.deploymentLogs.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "NEO INFRASTRUCTURE HOST",
                color = palette.primary,
                fontSize = 14.sp,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
            )
            Text(
                text = "Secure local workspace deployments directly to our CDN cloud cluster hooks",
                color = palette.textSecondary,
                fontSize = 11.sp
            )
        }

        item {
            // Deploy Grid Selection
            val deployOptions = listOf(
                Pair("Vercel", "Fast static CDN hosting"),
                Pair("Docker Daemon", "Remote cloud containers"),
                Pair("Netlify", "Dynamic cloud serverless"),
                Pair("GitHub Pages", "Static file distribution")
            )

            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                deployOptions.forEach { (srv, desc) ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = palette.surface),
                        border = BorderStroke(1.dp, palette.primary.copy(alpha = 0.1f))
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(srv, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, fontFamily = FontFamily.Monospace)
                                Text(desc, color = palette.textSecondary, fontSize = 10.sp)
                            }
                            NeonButton(
                                text = "DEPLOY",
                                palette = palette,
                                onClick = { viewModel.runDeployment(srv) }
                            )
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "HISTORICAL WEBHOOK OPERATIONS",
                color = palette.secondary,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }

        items(logs) { log ->
            val color = when (log.status) {
                "SUCCESS" -> Color(0xFF00FF66)
                "FAILED" -> Color(0xFFFF003C)
                else -> palette.primary
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = palette.bg),
                border = BorderStroke(1.dp, color.copy(alpha = 0.2f))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(6.dp).background(color, CircleShape))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(log.message, color = Color.White, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            Text("Triggered: ${log.timestamp}", color = palette.textSecondary, fontSize = 9.sp)
                        }
                    }
                    Text(
                        text = log.status,
                        color = color,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

// ==========================================
// 8. DEVELOPER PROFILE VIEW
// ==========================================
@Composable
fun ProfileView(viewModel: MainViewModel, palette: NeoPalette) {
    val username by viewModel.username.collectAsState()
    val streakDays by viewModel.streakDays.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .background(palette.primary.copy(alpha = 0.15f), CircleShape)
                    .border(2.dp, palette.primary, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = username.take(2).uppercase(),
                    color = palette.primary,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = username,
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = "SENIOR NEURAL ARCHITECT",
                color = palette.secondary,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }

        item {
            // Contribution streak log grid simulation
            GlassCard(
                palette = palette,
                modifier = Modifier.fillMaxWidth(),
                borderColor = palette.primary.copy(alpha = 0.2f)
            ) {
                Text(
                    text = "CONTRIBUTE STACK GRAPH (LAST 25 DAYS)",
                    color = palette.primary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                // Render grid
                Box(modifier = Modifier.fillMaxWidth()) {
                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(60.dp)
                    ) {
                        val boxes = 25
                        val columns = 5
                        val boxSize = 14.dp.toPx()
                        val padding = 6.dp.toPx()

                        for (i in 0 until boxes) {
                            val col = i / columns
                            val row = i % columns
                            val x = col * (boxSize + padding)
                            val y = row * (boxSize + padding)

                            // color variations mockup
                            val colVar = when {
                                i == 24 -> palette.primary // active today
                                i % 3 == 0 -> palette.secondary.copy(alpha = 0.8f)
                                i % 2 == 0 -> palette.primary.copy(alpha = 0.4f)
                                else -> palette.surface.copy(alpha = 0.2f)
                            }

                            drawRoundRect(
                                color = colVar,
                                topLeft = Offset(x, y),
                                size = Size(boxSize, boxSize),
                                cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Daily Commit Sync: Active streak: $streakDays days. Rating: World Class.",
                    color = palette.textSecondary,
                    fontSize = 9.sp
                )
            }
        }

        item {
            // Pre-saved code snippets
            Text(
                text = "SAVED UTILITIES SNIPPETS",
                color = palette.secondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Start
            )
        }

        items(com.example.data.sample.SampleData.snippets) { snip ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = palette.surface),
                border = BorderStroke(1.dp, palette.primary.copy(alpha = 0.1f))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(snip.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                        Text(snip.language, color = palette.primary, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(snip.description, color = palette.textSecondary, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.Black.copy(alpha = 0.4f))
                            .padding(8.dp)
                    ) {
                        Text(
                            text = snip.snippet,
                            color = Color(0xFF00FF66),
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            maxLines = 3,
                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// 9. LIVE WORKSPACE HOT RELOAD SIMULATOR PREVIEW (World-Class Browser Preview)
// ==========================================
@Composable
fun LivePreviewSimulator(viewModel: MainViewModel, palette: NeoPalette) {
    val activeFile by viewModel.activeFile.collectAsState()
    val fps by viewModel.fps.collectAsState()

    var showLoadingPreview by remember { mutableStateOf(true) }
    var addressUrl by remember { mutableStateOf("https://neocode-sandbox-compiler.local:3000") }
    // Viewport presets: 0 = Mobile, 1 = Tablet, 2 = Desktop
    var viewportMode by remember { mutableStateOf(2) }

    LaunchedEffect(showLoadingPreview) {
        if (showLoadingPreview) {
            delay(1000)
            showLoadingPreview = false
        }
    }

    Column(modifier = Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // Chromium Top Bar & Address Bar controls
        Card(
            colors = CardDefaults.cardColors(containerColor = palette.surface),
            border = BorderStroke(1.dp, palette.primary.copy(alpha = 0.2f)),
            shape = RoundedCornerShape(8.dp)
        ) {
            Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Browser Back / Forward / Sync Reload Controls
                    IconButton(onClick = { showLoadingPreview = true }, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.ArrowBack, "Back", tint = palette.textSecondary, modifier = Modifier.size(14.dp))
                    }
                    IconButton(onClick = { showLoadingPreview = true }, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.ArrowForward, "Forward", tint = palette.textSecondary, modifier = Modifier.size(14.dp))
                    }
                    IconButton(onClick = { showLoadingPreview = true }, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.Refresh, "Reload", tint = palette.primary, modifier = Modifier.size(14.dp))
                    }
                    Spacer(modifier = Modifier.width(6.dp))

                    // Simulated secure Address Input Field
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(28.dp)
                            .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
                            .border(1.dp, palette.primary.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Lock, null, tint = Color(0xFF00FF66), modifier = Modifier.size(10.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = addressUrl,
                                color = Color.White.copy(alpha = 0.8f),
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                maxLines = 1
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Responsive Viewport Selector buttons
                    Row(
                        modifier = Modifier.background(palette.bg, RoundedCornerShape(4.dp)).padding(2.dp),
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        listOf(Icons.Default.Smartphone, Icons.Default.Tablet, Icons.Default.Tv).forEachIndexed { index, icon ->
                            val isSel = viewportMode == index
                            IconButton(
                                onClick = { viewportMode = index },
                                modifier = Modifier
                                    .size(22.dp)
                                    .background(if (isSel) palette.primary.copy(alpha = 0.2f) else Color.Transparent, RoundedCornerShape(2.dp))
                            ) {
                                Icon(icon, null, tint = if (isSel) palette.primary else Color.Gray, modifier = Modifier.size(12.dp))
                            }
                        }
                    }
                }
            }
        }

        // Live Virtual Device Screen frame bounded by responsive width class
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            val containerWidth = when (viewportMode) {
                0 -> 240.dp  // Compact Phone Mock
                1 -> 420.dp  // Tablet Mock
                else -> 560.dp  // Desktop Fullscreen
            }

            Box(
                modifier = Modifier
                    .width(containerWidth)
                    .fillMaxHeight()
                    .background(Color.Black)
                    .border(2.dp, palette.primary.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                    .clip(RoundedCornerShape(12.dp))
            ) {
                if (showLoadingPreview) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = palette.secondary, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Hot compiling sandbox layout nodes...", color = palette.textSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                } else {
                    val renderedText = activeFile?.content ?: "Empty index bundle. Mount compile source buffers to hot preview."
                    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
                        // Embedded console drawer tab header
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().background(palette.surface).padding(6.dp)) {
                            Icon(Icons.Default.BugReport, null, tint = palette.secondary, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("CHROME CORE V8 SANDBOX PREVIEW", color = palette.primary, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }

                        // Sandbox simulation text body
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                                .background(palette.surface.copy(alpha = 0.4f))
                                .padding(8.dp)
                        ) {
                            LazyColumn {
                                item {
                                    Text(
                                        text = "[System Console Render Session Success]",
                                        color = Color(0xFF00FF66),
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = if (renderedText.length > 500) renderedText.take(500) + "\n\n/* Bundle Content Clipped for performance viewport. Code compiled without warnings. */" else renderedText,
                                        color = Color.White.copy(alpha = 0.9f),
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 11.sp,
                                        lineHeight = 16.sp,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            }
                        }

                        // Dynamic Chrome Bottom Error Counter UI
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF0C0C14))
                                .padding(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(modifier = Modifier.size(6.dp).background(Color.Green, CircleShape))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("V8 Console Logs: 0 Warnings | 0 Exceptions | FPS: $fps", color = palette.textSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        NeonButton(
            text = "TRIGGER COMPILER HOT FLASH UPDATE",
            palette = palette,
            onClick = { showLoadingPreview = true },
            modifier = Modifier.fillMaxWidth()
        )
    }
}

// ==========================================
// 12. AUTONOMOUS CODER AGENTS VIEW
// ==========================================
@Composable
fun AiAgentsWorkspaceView(viewModel: MainViewModel, palette: NeoPalette) {
    val isRunning by viewModel.isAgentRunning.collectAsState()
    val step by viewModel.agentCurrentStep.collectAsState()
    val logs by viewModel.agentLogs.collectAsState()
    val taskInput by viewModel.agentTaskInput.collectAsState()
    val agentType by viewModel.agentType.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AutoAwesome, null, tint = palette.accent, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "BACKGROUND CO-PILOT AGENTS",
                    color = palette.accent,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
            }
            Text(
                "Trigger stateful background agents to analyze code patterns, perform lint fixes, or generate draft test bundles.",
                color = palette.textSecondary,
                fontSize = 10.sp
            )
        }

        item {
            GlassCard(palette = palette) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Select Agent Subsystem Persona", color = palette.primary, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Code Engine", "Static Linter", "Bundle Deployer").forEach { type ->
                            val isSel = agentType == type
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { viewModel.setAgentType(type) }
                                    .background(
                                        if (isSel) palette.primary.copy(alpha = 0.2f) else Color.Transparent,
                                        RoundedCornerShape(4.dp)
                                    )
                                    .border(1.dp, if (isSel) palette.primary else Color.DarkGray, RoundedCornerShape(4.dp))
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(type, color = if (isSel) palette.primary else Color.White, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(2.dp))
                    Text("Designate Objective Goal / Prompt Prompt", color = palette.primary, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)

                    OutlinedTextField(
                        value = taskInput,
                        onValueChange = { viewModel.setAgentTaskInput(it) },
                        textStyle = TextStyle(color = Color.White, fontSize = 11.sp, fontFamily = FontFamily.Monospace),
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = palette.primary,
                            unfocusedBorderColor = Color.DarkGray,
                            cursorColor = palette.primary
                        )
                    )

                    Spacer(modifier = Modifier.height(4.dp))
                    NeonButton(
                        text = if (isRunning) "AGENT INTERACTION RUNNING..." else "ASSIGN AGENT TASK",
                        palette = palette,
                        onClick = { viewModel.runAutonomousAgent() },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        if (isRunning || logs.isNotEmpty()) {
            item {
                GlassCard(palette = palette, borderColor = palette.accent) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("DAEMON REASONING LOGICAL LOOP", color = palette.accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Spacer(modifier = Modifier.weight(1f))
                            if (isRunning) {
                                CircularProgressIndicator(color = palette.accent, modifier = Modifier.size(12.dp), strokeWidth = 2.dp)
                            } else {
                                Box(modifier = Modifier.size(6.dp).background(Color.Green, CircleShape))
                            }
                        }

                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text("Task Progress Map Analysis", color = palette.textSecondary, fontSize = 9.sp)
                                Text("Step $step of 5", color = palette.accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                            LinearProgressIndicator(
                                progress = { step / 5f },
                                modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                                color = palette.accent,
                                trackColor = palette.surface
                            )
                        }

                        Text("AST INTERPRETER REALTIME LOGS", color = palette.primary, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 160.dp)
                                .background(Color.Black.copy(alpha = 0.6f))
                                .border(1.dp, Color.DarkGray)
                                .padding(6.dp)
                        ) {
                            LazyColumn {
                                items(logs) { log ->
                                    Text(
                                        text = log,
                                        color = if (log.contains("SUCCESS") || log.contains("COMPLETED")) Color(0xFF00FF66) else Color.White,
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        lineHeight = 14.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 13. PROJECT BRAIN WORKSPACE MEMORY VIEW
// ==========================================
@Composable
fun ProjectBrainView(viewModel: MainViewModel, palette: NeoPalette) {
    var activeTabSub by remember { mutableStateOf("SEMANTIC_SEARCH") }

    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        // Option select tabs bar
        Row(
            modifier = Modifier.fillMaxWidth().background(palette.surface).padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            listOf(
                Triple("SEMANTIC_SEARCH", "Semantic Vector", Icons.Default.Search),
                Triple("MEMORY", "Recall Brain", Icons.Default.Memory),
                Triple("AUTOMATION", "Automations", Icons.Default.FlashOn)
            ).forEach { (tKey, tLabel, tIcon) ->
                val isActive = activeTabSub == tKey
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { activeTabSub = tKey }
                        .background(
                            if (isActive) palette.primary.copy(alpha = 0.15f) else Color.Transparent,
                            RoundedCornerShape(4.dp)
                        )
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(tIcon, null, tint = if (isActive) palette.primary else Color.Gray, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(tLabel, color = if (isActive) palette.primary else Color.White, fontSize = 9.sp, fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal, fontFamily = FontFamily.Monospace)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        when (activeTabSub) {
            "SEMANTIC_SEARCH" -> {
                val semanticQuery by viewModel.semanticQuery.collectAsState()
                val semanticResults by viewModel.semanticResults.collectAsState()

                Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxSize()) {
                    Text("CONCEPTUAL VECTOR SEMANTIC SEARCH", color = palette.primary, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Text("Search concepts instead of matching exact labels (neural-embedded query simulation).", color = palette.textSecondary, fontSize = 9.sp)

                    OutlinedTextField(
                        value = semanticQuery,
                        onValueChange = { viewModel.runSemanticSearch(it) },
                        placeholder = { Text("Search logic... (e.g., 'Database credentials')", color = Color.Gray, fontSize = 10.sp) },
                        textStyle = TextStyle(color = Color.White, fontSize = 11.sp, fontFamily = FontFamily.Monospace),
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = palette.primary, unfocusedBorderColor = Color.DarkGray)
                    )

                    if (semanticResults.isNotEmpty()) {
                        Text("COSINE ACCURACY SEMANTIC RANKINGS", color = palette.accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.weight(1f)) {
                            items(semanticResults) { res ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = palette.surface),
                                    border = BorderStroke(1.dp, palette.primary.copy(alpha = 0.1f))
                                ) {
                                    Column(modifier = Modifier.padding(8.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(res.filename, color = palette.primary, fontWeight = FontWeight.Bold, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                            Spacer(modifier = Modifier.weight(1f))
                                            Text("MATCH: ${res.similarity}%", color = palette.accent, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                         }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text("Line ${res.lineNum}: ${res.snippet}", color = Color.White, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.background(Color.Black).padding(4.dp).fillMaxWidth())
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(res.description, color = palette.textSecondary, fontSize = 9.sp)
                                    }
                                }
                            }
                        }
                    } else {
                        Box(modifier = Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                            Text("Submit query keyword to test local Vector search embeddings", color = palette.textSecondary, fontSize = 10.sp)
                        }
                    }
                }
            }
            "MEMORY" -> {
                val memoryList by viewModel.workspaceMemory.collectAsState()

                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxSize()) {
                    item {
                        Text("WORKSPACE SEMANTIC RECALL BUFFER", color = palette.primary, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        Text("Tracks files indexed, context segments, and semantic mappings.", color = palette.textSecondary, fontSize = 9.sp)
                    }

                    items(memoryList.toList()) { (mKey, mVal) ->
                        GlassCard(palette = palette) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Memory, null, tint = palette.accent, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(mKey, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                    Text(mVal, color = palette.textSecondary, fontSize = 9.sp)
                                }
                            }
                        }
                    }
                }
            }
            "AUTOMATION" -> {
                val optRules by viewModel.automations.collectAsState()
                val activeLogs by viewModel.serverProcesses.collectAsState()

                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxSize()) {
                    item {
                        Text("AI WORKFLOW AUTOMATION ENGINE", color = palette.primary, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        Text("Configured webhook actions and hooks in workspace compilation loops.", color = palette.textSecondary, fontSize = 9.sp)
                    }

                    items(optRules) { rule ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = palette.surface),
                            border = BorderStroke(1.dp, palette.primary.copy(alpha = 0.1f))
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.FlashOn, null, tint = palette.secondary, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(rule.name, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                    Text("Trigger: ${rule.triggerName} • Action: ${rule.actionName}", color = palette.textSecondary, fontSize = 9.sp)
                                }
                                Switch(
                                    checked = rule.isEnabled,
                                    onCheckedChange = { viewModel.toggleAutomationEnabled(rule.id) },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = palette.primary,
                                        checkedTrackColor = palette.primary.copy(alpha = 0.3f)
                                    )
                                )
                            }
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("ACTIVE DAEMON SERVER PROCESSES", color = palette.primary, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }

                    items(activeLogs) { devProc ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = palette.surface),
                            border = BorderStroke(1.dp, palette.primary.copy(alpha = 0.1f))
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Power, null, tint = if (devProc.status == "RUNNING") Color.Green else Color.Red, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(devProc.name, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                    Spacer(modifier = Modifier.weight(1f))
                                    Text("Status: ${devProc.status} • Port: ${devProc.port}", color = palette.textSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                }
                                Text(devProc.logs, color = Color.LightGray.copy(alpha = 0.7f), fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(top = 4.dp))
                                Spacer(modifier = Modifier.height(6.dp))
                                NeonButton(
                                    text = if (devProc.status == "RUNNING") "RESTART/DAEMON STOP" else "BOOT UP",
                                    palette = palette,
                                    onClick = { viewModel.toggleServerProcess(devProc.name) },
                                    modifier = Modifier.fillMaxWidth(),
                                    isSecondary = true
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 10. EXTENSIONS MARKETPLACE VIEW
// ==========================================
@Composable
fun ExtensionsMarketView(viewModel: MainViewModel, palette: NeoPalette) {
    val extensions by viewModel.extensions.collectAsState()

    var activeFilterCategory by remember { mutableStateOf("ALL") }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "NEO PLUGINS STORE",
                color = palette.primary,
                fontSize = 14.sp,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            // Category selectors
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("ALL", "AI", "Themes", "Languages").forEach { cat ->
                    val isActive = activeFilterCategory == cat
                    Card(
                        modifier = Modifier
                            .clickable { activeFilterCategory = cat }
                            .background(Color.Transparent),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isActive) palette.primary else palette.surface
                        ),
                        border = BorderStroke(1.dp, palette.primary.copy(alpha = 0.2f))
                    ) {
                        Text(
                            text = cat,
                            color = if (isActive) Color.Black else Color.White,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }

        val filtered = extensions.filter { activeFilterCategory == "ALL" || it.category == activeFilterCategory }

        items(filtered) { ext ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = palette.surface),
                border = BorderStroke(1.dp, palette.primary.copy(alpha = 0.1f))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(palette.primary.copy(alpha = 0.1f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (ext.category) {
                                "AI" -> Icons.Default.AutoAwesome
                                "Themes" -> Icons.Default.Palette
                                else -> Icons.Default.Code
                            },
                            contentDescription = null,
                            tint = palette.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(ext.name, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        Text("Dev: ${ext.developer} • Downloads: ${ext.downloads}", color = palette.textSecondary, fontSize = 9.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(ext.description, color = palette.textSecondary.copy(alpha = 0.8f), fontSize = 10.sp, lineHeight = 14.sp)
                    }

                    Spacer(modifier = Modifier.width(10.dp))
                    IconButton(
                        onClick = { viewModel.toggleExtensionInstalled(ext.id) },
                        colors = IconButtonDefaults.iconButtonColors(
                            containerColor = if (ext.isInstalled) palette.bg else palette.primary,
                            contentColor = if (ext.isInstalled) palette.primary else Color.Black
                        ),
                        modifier = Modifier.size(36.dp).clip(CircleShape)
                    ) {
                        Icon(
                            imageVector = if (ext.isInstalled) Icons.Default.Check else Icons.Default.Add,
                            contentDescription = "Install Extension",
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// 11. GENERAL SETTINGS AND CONFIGURATIONS View
// ==========================================
@Composable
fun SettingsView(viewModel: MainViewModel, palette: NeoPalette) {
    val themeName by viewModel.currentTheme.collectAsState()

    var apiKeyInput by remember { mutableStateOf(BuildConfig.GEMINI_API_KEY ?: "") }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "NEO CONTROL BOARD",
                color = palette.primary,
                fontSize = 14.sp,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
            )
            Text("Tailor editor key bindings, holographic scales, and API access channels", color = palette.textSecondary, fontSize = 11.sp)
        }

        item {
            // Theme selection Row
            Text("THEME PALETTES SELECTOR", color = palette.secondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    Pair("cyberpunk", "CYBER RGB"),
                    Pair("dracula", "DRACULA"),
                    Pair("matrix", "MATRIX"),
                    Pair("horizon", "HORIZON"),
                    Pair("classic", "CLASSIC VSC")
                ).forEach { (tKey, label) ->
                    val isSelected = themeName == tKey
                    Card(
                        modifier = Modifier
                            .clickable { viewModel.changeTheme(tKey) }
                            .background(Color.Transparent),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) palette.primary else palette.surface
                        ),
                        border = BorderStroke(1.dp, palette.primary.copy(alpha = 0.2f))
                    ) {
                        Text(
                            text = label,
                            color = if (isSelected) Color.Black else Color.White,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                        )
                    }
                }
            }
        }

        item {
            // Secure API configuration Form
            Text("NEURAL API GATEWAY SETTINGS", color = palette.secondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(6.dp))
            GlassCard(palette = palette, modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "To allow the built-in AI chat module to analyze custom scripts via live LLM requests, insert your Google AI Studio token key safely below. Access keys are stored solely in isolated memory spaces.",
                    color = palette.textSecondary,
                    fontSize = 11.sp,
                    lineHeight = 15.sp,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                OutlinedTextField(
                    value = apiKeyInput,
                    onValueChange = { apiKeyInput = it },
                    label = { Text("GEMINI_API_KEY_SECRET", fontSize = 11.sp, fontFamily = FontFamily.Monospace) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = palette.primary,
                        unfocusedBorderColor = palette.primary.copy(alpha = 0.2f),
                        focusedContainerColor = palette.bg
                    ),
                    textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = Color.White),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(10.dp))
                NeonButton(
                    text = "SAVE ENCRYPTED SECRETS",
                    palette = palette,
                    onClick = {
                        // saves cleanly to memory instance (transparent)
                        viewModel.submitTerminalCommand("neofetch")
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = palette.surface),
                border = BorderStroke(1.dp, palette.primary.copy(alpha = 0.1f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("SYSTEM DETAILS", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Product Scale: Enterprise AI IDE Workspace", fontSize = 11.sp, color = palette.textSecondary)
                    Text("Compilation core status: stable (60Hz rendering)", fontSize = 11.sp, color = palette.textSecondary)
                    Text("Encrypted communication nodes: SHA-256 enabled", fontSize = 11.sp, color = palette.textSecondary)
                }
            }
        }
    }
}

// ==========================================
// 12. LIVE COLLABORATION WORKSPACE WORKER
// ==========================================
@Composable
fun LiveCollaborationWorkspace(viewModel: MainViewModel, palette: NeoPalette) {
    val collabActive by viewModel.collaborationActive.collectAsState()
    val cursors by viewModel.cursors.collectAsState()

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "HOLOGRAPHIC SHARE HUB",
            color = palette.primary,
            fontSize = 14.sp,
            fontWeight = FontWeight.ExtraBold,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.sp
        )
        Text(
            text = "Transmit localized compiler scopes to foreign workspace hubs securely",
            color = palette.textSecondary,
            fontSize = 11.sp
        )

        GlassCard(palette = palette, modifier = Modifier.fillMaxWidth(), borderColor = palette.secondary) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("SHARED COMPILE NODE STATUS", color = palette.primary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    Text(
                        text = if (collabActive) "CONNECTIVITY: LINKED" else "CONNECTIVITY: DISCLOSED",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Switch(
                    checked = collabActive,
                    onCheckedChange = { viewModel.toggleCollaboration(it) },
                    colors = SwitchDefaults.colors(checkedThumbColor = palette.secondary)
                )
            }
        }

        if (collabActive) {
            Text(
                text = "ACTIVE NEIGHBOR HANDSHAKES",
                color = palette.secondary,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )

            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(cursors) { user ->
                    val colorHex = Color(android.graphics.Color.parseColor(user.colorHex))
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = palette.surface),
                        border = BorderStroke(1.dp, colorHex.copy(alpha = 0.2f))
                    ) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(colorHex.copy(alpha = 0.1f), CircleShape)
                                    .border(1.dp, colorHex, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(user.avatarLetters, color = colorHex, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(user.name, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                Text("Active in line: row ${user.cursorRow}, col ${user.cursorCol}", color = palette.textSecondary, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        } else {
            Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.GroupAdd, null, tint = palette.primary.copy(alpha = 0.2f), modifier = Modifier.size(54.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Collab channels asleep", color = palette.textSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}
