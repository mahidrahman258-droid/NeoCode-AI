package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

data class NeoPalette(
    val bg: Color,
    val surface: Color,
    val primary: Color,
    val secondary: Color,
    val accent: Color,
    val textPrimary: Color = Color.White,
    val textSecondary: Color = Color(0xFFA0A0B0),
    val terminalBg: Color = Color(0xFF000000)
)

object NeoTheme {
    fun getPalette(themeName: String): NeoPalette {
        return when (themeName.lowercase()) {
            "dracula" -> NeoPalette(
                bg = DracBg,
                surface = DracSurface,
                primary = DracPrimary,
                secondary = DracSecondary,
                accent = DracAccent
            )
            "matrix" -> NeoPalette(
                bg = MatrixBg,
                surface = MatrixSurface,
                primary = MatrixPrimary,
                secondary = MatrixSecondary,
                accent = MatrixAccent
            )
            "horizon" -> NeoPalette(
                bg = HorizonBg,
                surface = HorizonSurface,
                primary = HorizonPrimary,
                secondary = HorizonSecondary,
                accent = HorizonAccent
            )
            "classic" -> NeoPalette(
                bg = VscBg,
                surface = VscSurface,
                primary = VscPrimary,
                secondary = VscSecondary,
                accent = VscAccent
            )
            else -> NeoPalette( // cyberpunk default
                bg = CyberBg,
                surface = CyberSurface,
                primary = CyberPrimary,
                secondary = CyberSecondary,
                accent = CyberAccent
            )
        }
    }
}

@Composable
fun MyApplicationTheme(
    themeName: String = "cyberpunk",
    content: @Composable () -> Unit
) {
    val palette = NeoTheme.getPalette(themeName)
    val materialScheme = darkColorScheme(
        primary = palette.primary,
        secondary = palette.secondary,
        background = palette.bg,
        surface = palette.surface,
        onPrimary = Color.Black,
        onSecondary = Color.White,
        onBackground = palette.textPrimary,
        onSurface = palette.textPrimary
    )

    MaterialTheme(
        colorScheme = materialScheme,
        typography = Typography,
        content = content
    )
}
