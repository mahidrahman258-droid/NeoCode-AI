package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.NeoPalette
import kotlin.random.Random

/**
 * A beautiful Cyberpunk glassmorphic card with colored neon borders, translucent fill,
 * and optional glowing dynamic drop shadows.
 */
@Composable
fun GlassCard(
    palette: NeoPalette,
    modifier: Modifier = Modifier,
    borderGlow: Boolean = true,
    borderColor: Color? = null,
    borderWidth: Dp = 1.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    val finalBorderColor = borderColor ?: palette.primary
    val shape = RoundedCornerShape(12.dp)

    Box(
        modifier = modifier
            .drawBehind {
                if (borderGlow) {
                    // Draw a subtle soft ambient glow behind the card corners
                    drawRoundRect(
                        color = finalBorderColor.copy(alpha = 0.08f),
                        topLeft = Offset(-4f, -4f),
                        size = Size(size.width + 8f, size.height + 8f),
                        cornerRadius = CornerRadius(14.dp.toPx(), 14.dp.toPx())
                    )
                }
            }
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        palette.surface.copy(alpha = 0.7f),
                        palette.surface.copy(alpha = 0.4f)
                    )
                ),
                shape = shape
            )
            .border(
                width = borderWidth,
                brush = Brush.linearGradient(
                    colors = listOf(
                        finalBorderColor.copy(alpha = 0.8f),
                        palette.secondary.copy(alpha = 0.2f)
                    )
                ),
                shape = shape
            )
            .clip(shape)
            .padding(12.dp)
    ) {
        Column {
            content()
        }
    }
}

/**
 * A premium futuristic button with dual border gradients and pulse glow animation.
 */
@Composable
fun NeonButton(
    text: String,
    palette: NeoPalette,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: (@Composable () -> Unit)? = null,
    isSecondary: Boolean = false
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val borderPulseState by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val shape = RoundedCornerShape(8.dp)
    val buttonColors = if (isSecondary) {
        listOf(palette.surface, palette.surface.copy(alpha = 0.6f))
    } else {
        listOf(palette.primary, palette.secondary)
    }

    val glowColor = if (isSecondary) palette.secondary else palette.primary

    Box(
        modifier = modifier
            .drawBehind {
                if (!isSecondary) {
                    drawRoundRect(
                        color = glowColor.copy(alpha = 0.15f * borderPulseState),
                        topLeft = Offset(-6f, -6f),
                        size = Size(size.width + 12f, size.height + 12f),
                        cornerRadius = CornerRadius(10.dp.toPx(), 10.dp.toPx())
                    )
                }
            }
            .background(
                brush = Brush.horizontalGradient(buttonColors),
                shape = shape
            )
            .clickable(onClick = onClick)
            .border(
                width = 1.dp,
                color = if (isSecondary) palette.primary.copy(alpha = 0.5f) else Color.White.copy(alpha = 0.2f),
                shape = shape
            )
            .padding(vertical = 12.dp, horizontal = 16.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            if (icon != null) {
                icon()
                Spacer(modifier = Modifier.width(8.dp))
            }
            Text(
                text = text,
                color = if (isSecondary) palette.primary else Color.Black,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                letterSpacing = 0.5.sp
            )
        }
    }
}

/**
 * An energetic cyberpunk grid overlay with falling code bits to establish the hacker environment.
 */
@Composable
fun MatrixCanvas(
    palette: NeoPalette,
    modifier: Modifier = Modifier
) {
    val codeRain = remember {
        List(25) {
            CodeColumn(
                xPct = Random.nextFloat(),
                chars = List(7) { (Random.nextInt(33, 126).toChar()).toString() },
                speed = Random.nextFloat() * 12f + 4f,
                startOffset = Random.nextFloat() * -500f
            )
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "matrix_rain")
    val ticker by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(10000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "matrix_rain"
    )

    Canvas(modifier = modifier.fillMaxSize().background(palette.bg)) {
        // Draw grid
        val gridDist = maxOf(40f, 60.dp.toPx())
        val w = size.width
        val h = size.height

        if (gridDist > 20f && w > 0 && h > 0) {
            // Horizontal lines
            var y = 0f
            while (y < h) {
                drawLine(
                    color = palette.primary.copy(alpha = 0.03f),
                    start = Offset(0f, y),
                    end = Offset(w, y),
                    strokeWidth = 1f
                )
                y += gridDist
            }

            // Vertical lines
            var x = 0f
            while (x < w) {
                drawLine(
                    color = palette.primary.copy(alpha = 0.03f),
                    start = Offset(x, 0f),
                    end = Offset(x, h),
                    strokeWidth = 1f
                )
                x += gridDist
            }
        }

        // Draw falling digits
        codeRain.forEach { column ->
            val curX = column.xPct * w
            val elapsedTicks = ticker * column.speed
            val curYStart = (column.startOffset + elapsedTicks) % (h + 300f) - 150f

            column.chars.forEachIndexed { index, char ->
                val charY = curYStart + index * 24f
                if (charY in 0f..h) {
                    val opacity = (1f - (index.toFloat() / column.chars.size)) * 0.15f
                    val charColor = if (index == 0) Color.White.copy(alpha = 0.35f) else palette.primary.copy(alpha = opacity)
                    
                    // Simple drawing of falling bytes
                    drawCircle(
                        color = charColor,
                        radius = 4f,
                        center = Offset(curX, charY)
                    )
                }
            }
        }
    }
}

private data class CodeColumn(
    val xPct: Float,
    val chars: List<String>,
    val speed: Float,
    val startOffset: Float
)
