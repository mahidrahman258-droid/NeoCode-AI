package com.example.ui.workspace

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.text.TextStyle
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.NoteAdd
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.ProjectFile
import com.example.ui.MainViewModel
import com.example.ui.components.GlassCard
import com.example.ui.theme.NeoPalette

/**
 * File explorer widget. Renders interactive folders, nested directories, git statuses,
 * and includes full modal support to configure new code files dynamically.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FileTreeSidebar(
    viewModel: MainViewModel,
    palette: NeoPalette,
    modifier: Modifier = Modifier
) {
    val allFiles by viewModel.allFiles.collectAsState()
    val activeFile by viewModel.activeFile.collectAsState()

    var showCreateFileDialog by remember { mutableStateOf(false) }
    var newFileName by remember { mutableStateOf("") }
    var isNewFolder by remember { mutableStateOf(false) }
    var selectedParentPath by remember { mutableStateOf<String?>(null) }

    // Toggle folders track
    val expandedFolders = remember { mutableStateMapOf<String, Boolean>() }

    Column(
        modifier = modifier
            .fillMaxHeight()
            .background(palette.surface.copy(alpha = 0.9f))
            .drawBehind {
                // right border
                drawLine(
                    color = palette.primary.copy(alpha = 0.15f),
                    start = Offset(size.width, 0f),
                    end = Offset(size.width, size.height),
                    strokeWidth = 2f
                )
            }
            .padding(12.dp)
    ) {
        // Explorer Headers action buttons
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.FolderOpen,
                    contentDescription = "Explorer files",
                    tint = palette.primary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "NEO EXPLORER",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = palette.primary,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
            }

            // Create file icon shortcut
            IconButton(
                onClick = {
                    selectedParentPath = null
                    isNewFolder = false
                    newFileName = ""
                    showCreateFileDialog = true
                },
                modifier = Modifier.size(24.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.NoteAdd,
                    contentDescription = "Create File",
                    tint = palette.secondary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        // Search directories quick filter logs
        var filterText by remember { mutableStateOf("") }
        OutlinedTextField(
            value = filterText,
            onValueChange = { filterText = it },
            placeholder = { Text("Filter workspace files", fontSize = 11.sp, color = palette.textSecondary.copy(alpha = 0.4f)) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
                .height(48.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = palette.primary,
                unfocusedBorderColor = palette.primary.copy(alpha = 0.2f),
                unfocusedContainerColor = palette.bg.copy(alpha = 0.5f),
                focusedContainerColor = palette.bg
            ),
            textStyle = TextStyle(fontSize = 12.sp, fontFamily = FontFamily.Monospace, color = Color.White),
            trailingIcon = {
                Icon(Icons.Outlined.Search, null, tint = palette.primary.copy(alpha = 0.5f), modifier = Modifier.size(16.dp))
            },
            shape = RoundedCornerShape(8.dp)
        )

        // File Node listing column
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            allFiles.forEach { rootFile ->
                val matchesFilter = rootFile.name.contains(filterText, ignoreCase = true) || 
                        (rootFile.children?.any { it.name.contains(filterText, ignoreCase = true) } == true)
                
                if (filterText.isEmpty() || matchesFilter) {
                    item {
                        FileNodeItem(
                            file = rootFile,
                            level = 0,
                            palette = palette,
                            isActive = activeFile?.path == rootFile.path,
                            expanded = expandedFolders[rootFile.path] ?: false,
                            onToggleExpand = {
                                expandedFolders[rootFile.path] = !(expandedFolders[rootFile.path] ?: false)
                            },
                            onSelect = { viewModel.selectFile(rootFile) },
                            onCreateSubfile = { isFolder ->
                                selectedParentPath = rootFile.path
                                isNewFolder = isFolder
                                newFileName = ""
                                showCreateFileDialog = true
                            }
                        )
                    }

                    // Render nested folders children
                    if (rootFile.isFolder && (expandedFolders[rootFile.path] == true || filterText.isNotEmpty())) {
                        val filteredChildren = rootFile.children?.filter { 
                            filterText.isEmpty() || it.name.contains(filterText, ignoreCase = true)
                        } ?: emptyList()

                        items(filteredChildren) { subFile ->
                            FileNodeItem(
                                file = subFile,
                                level = 1,
                                palette = palette,
                                isActive = activeFile?.path == subFile.path,
                                expanded = expandedFolders[subFile.path] ?: false,
                                onToggleExpand = {
                                    expandedFolders[subFile.path] = !(expandedFolders[subFile.path] ?: false)
                                },
                                onSelect = { viewModel.selectFile(subFile) },
                                onCreateSubfile = {}
                            )
                        }
                    }
                }
            }
        }

        // Storage analytic footer visual
        Spacer(modifier = Modifier.height(12.dp))
        GlassCard(
            palette = palette,
            borderGlow = false,
            borderColor = palette.primary.copy(alpha = 0.1f)
        ) {
            Text("VIRTUAL LOCAL STACK", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = palette.primary)
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                LinearProgressIndicator(
                    progress = { 0.42f },
                    modifier = Modifier.weight(1f).height(4.dp).clip(CircleShape),
                    color = palette.secondary,
                    trackColor = palette.primary.copy(alpha = 0.1f)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("42% full", fontSize = 8.sp, color = palette.textSecondary)
            }
        }
    }

    // Modal Create File dialog representation
    if (showCreateFileDialog) {
        AlertDialog(
            onDismissRequest = { showCreateFileDialog = false },
            title = {
                Text(
                    text = if (isNewFolder) "CREATE DIRECTORY NODE" else "CREATE SOURCE FILE",
                    color = palette.primary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            },
            text = {
                Column {
                    Text(
                        text = if (selectedParentPath != null) "Location: $selectedParentPath/" else "Location: Project Root Directory",
                        color = palette.textSecondary,
                        fontSize = 11.sp,
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                    OutlinedTextField(
                        value = newFileName,
                        onValueChange = { newFileName = it },
                        placeholder = { Text(if (isNewFolder) "folder_name" else "app.js", fontSize = 12.sp, color = palette.textSecondary.copy(alpha = 0.4f)) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = palette.primary,
                            unfocusedBorderColor = palette.primary.copy(alpha = 0.3f)
                        ),
                        textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = Color.White),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newFileName.trim().isNotEmpty()) {
                            viewModel.createNewFile(newFileName, isNewFolder, selectedParentPath)
                            showCreateFileDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = palette.primary, contentColor = Color.Black)
                ) {
                    Text("BUILD")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateFileDialog = false }) {
                    Text("ABORT", color = palette.secondary)
                }
            },
            containerColor = palette.surface,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.border(1.dp, palette.primary.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
        )
    }
}

@Composable
fun FileNodeItem(
    file: ProjectFile,
    level: Int,
    palette: NeoPalette,
    isActive: Boolean,
    expanded: Boolean,
    onToggleExpand: () -> Unit,
    onSelect: () -> Unit,
    onCreateSubfile: (Boolean) -> Unit
) {
    val gitColor = when (file.gitStatus) {
        "modified" -> Color(0xFFF1FA8C) // yellow
        "added" -> Color(0xFF50FA7B) // light green
        else -> palette.textSecondary
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(
                if (isActive) palette.primary.copy(alpha = 0.1f) else Color.Transparent
            )
            .clickable {
                if (file.isFolder) {
                    onToggleExpand()
                } else {
                    onSelect()
                }
            }
            .padding(start = (level * 16).dp)
            .padding(vertical = 8.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Folder vs File vector icons
        if (file.isFolder) {
            Icon(
                imageVector = if (expanded) Icons.Default.KeyboardArrowDown else Icons.Default.KeyboardArrowRight,
                contentDescription = null,
                tint = palette.primary.copy(alpha = 0.7f),
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
                imageVector = if (expanded) Icons.Default.FolderOpen else Icons.Default.Folder,
                contentDescription = "Folder",
                tint = palette.primary,
                modifier = Modifier.size(18.dp)
            )
        } else {
            Icon(
                imageVector = when (file.extension) {
                    "ts", "js" -> Icons.Default.IntegrationInstructions
                    "py" -> Icons.Default.Polymer
                    "html" -> Icons.Default.Web
                    "dart" -> Icons.Default.CallToAction
                    "rust" -> Icons.Default.Science
                    else -> Icons.Default.Article
                },
                contentDescription = "File",
                tint = gitColor,
                modifier = Modifier.size(16.dp)
            )
        }

        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = file.name,
            color = if (isActive) palette.primary else gitColor,
            fontSize = 12.sp,
            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.weight(1f)
        )

        // Git changed indicators label
        if (file.gitStatus != null) {
            Text(
                text = if (file.gitStatus == "added") "U" else "M",
                color = gitColor,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 6.dp)
            )
        }

        // Create nested subfiles trigger icon overlays (for folder only)
        if (file.isFolder) {
            IconButton(
                onClick = { onCreateSubfile(false) },
                modifier = Modifier.size(20.dp)
            ) {
                Icon(Icons.Default.Add, "New context file", tint = palette.primary.copy(alpha = 0.6f), modifier = Modifier.size(12.dp))
            }
        }
    }
}
