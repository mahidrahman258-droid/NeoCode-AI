package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.ui.MainAppShell
import com.example.ui.MainViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Setup premium edge-to-edge full screen support
        enableEdgeToEdge()

        setContent {
            // Render the cyberpunk NeoCode IDE shell containing all modules
            MainAppShell(viewModel = viewModel)
        }
    }
}
