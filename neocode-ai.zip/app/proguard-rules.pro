# =========================================================================
# Production Proguard/R8 Rules for NeoCode Platform
# Optimized for high stability, max shrinking, and optimal obfuscation
# =========================================================================

# --- General System Optimizations ---
-repackageclasses 'com.aistudio.neocode.internal'
-allowaccessmodification

# Keep line numbers and source file names for crash reporting (Firebase Crashlytics)
-keepattributes SourceFile,LineNumberTable,*Annotation*

# Keep generic signatures for reflection of serialization models (Moshi/Retrofit)
-keepattributes Signature,EnclosingMethod,InnerClasses,InnerClasses

# --- Jetpack Compose & Kotlin rules ---
-keepclassmembers class * extends androidx.lifecycle.ViewModel {
    <init>(...);
}
-keep class androidx.compose.ui.platform.AndroidComposeView { *; }
-keepclassmembers class * {
    @androidx.compose.runtime.Composable *;
}

# --- Coroutines ---
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-keepclassmembernames class kotlinx.coroutines.android.HandlerContext {
    private synthetic <init>(...);
}

# --- Retrofit REST Client & OkHttp ---
-keepattributes RuntimeVisibleAnnotations,RuntimeInvisibleAnnotations,RuntimeVisibleParameterAnnotations,RuntimeInvisibleParameterAnnotations
-keepclassmembers,allowobfuscation interface * {
    @retrofit2.http.* <methods>;
}
-dontwarn retrofit2.**
-keep class retrofit2.** { *; }

-dontwarn okhttp3.**
-dontwarn okio.**
-keep class okhttp3.** { *; }

# --- Moshi Serialization Support ---
# Keep all generated JsonAdapters
-keep class *JsonAdapter { <init>(...); }
-keepclassmembers class * {
    @com.squareup.moshi.Json *;
}
-dontwarn com.squareup.moshi.**

# --- App Domain Models (Keep from being obfuscated/shrank for deep parsing) ---
-keep class com.example.data.models.** { *; }
-keep class com.example.data.api.** { *; }

# --- Android Hardware & System View Optimization ---
-keepclassmembers class * extends android.view.View {
    public void set*(***);
    public *** get*();
}
