package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.util.Log
import android.widget.Toast
import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppStats
import com.example.data.CommandHistory
import com.example.data.VoiceDockDatabase
import com.example.services.SpeechManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class InstalledApp(
    val packageName: String,
    val label: String,
    val category: String,
    val isFavorite: Boolean = false,
    val clickCount: Int = 0,
    val lastLaunched: Long = 0,
    val isSystem: Boolean = false
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext
    private val database = VoiceDockDatabase.getDatabase(context)
    private val appStatsDao = database.appStatsDao()
    private val commandDao = database.commandDao()

    val speechManager = SpeechManager(context)

    // All scanned package apps
    private val _scannedApps = MutableStateFlow<List<InstalledApp>>(emptyList())
    val scannedApps = _scannedApps.asStateFlow()

    // Loading status
    private val _isLoading = MutableStateFlow(true)
    val isLoading = _isLoading.asStateFlow()

    // Selected category filter
    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory = _selectedCategory.asStateFlow()

    // Search queries
    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    // Settings
    private val _voiceSensitivity = MutableStateFlow(0.8f) // 0.0 to 1.0
    val voiceSensitivity = _voiceSensitivity.asStateFlow()

    private val _isDarkMode = MutableStateFlow(true)
    val isDarkMode = _isDarkMode.asStateFlow()

    private val _selectedLanguage = MutableStateFlow("en-US")
    val selectedLanguage = _selectedLanguage.asStateFlow()

    private val _isBatteryOptimizationIgnored = MutableStateFlow(false)
    val isBatteryOptimizationIgnored = _isBatteryOptimizationIgnored.asStateFlow()

    // Custom background/foreground dock service status
    private val _isDockServiceEnabled = MutableStateFlow(true)
    val isDockServiceEnabled = _isDockServiceEnabled.asStateFlow()

    // Recent command executions
    val commandHistory: StateFlow<List<CommandHistory>> = commandDao.getRecentHistoryFlow()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // List of standard supported categories in order
    val categoriesList = listOf(
        "All", "Favorites", "Social", "Productivity", "Coding", "Browser", "Media", "Finance", "Utilities", "Games"
    )

    // Live synced list of installed apps combined with DB stats
    val appList: StateFlow<List<InstalledApp>> = combine(
        _scannedApps,
        appStatsDao.getAllStatsFlow(),
        _selectedCategory,
        _searchQuery
    ) { scannedList, dbStatsList, category, query ->
        val dbStatsMap = dbStatsList.associateBy { it.packageName }
        
        val combined = scannedList.map { app ->
            val stat = dbStatsMap[app.packageName]
            app.copy(
                isFavorite = stat?.isFavorite ?: false,
                clickCount = stat?.clickCount ?: 0,
                lastLaunched = stat?.lastLaunched ?: 0L,
                category = stat?.categoryOverride ?: app.category
            )
        }

        // Apply filters
        var filtered = combined

        if (category == "Favorites") {
            filtered = filtered.filter { it.isFavorite }
        } else if (category != "All") {
            filtered = filtered.filter { it.category.equals(category, ignoreCase = true) }
        }

        if (query.isNotEmpty()) {
            val q = query.lowercase().trim()
            filtered = filtered.filter { 
                it.label.lowercase().contains(q) || 
                it.packageName.lowercase().contains(q) || 
                it.category.lowercase().contains(q)
            }.sortedByDescending { 
                // Prioritize items starting with the query
                it.label.lowercase().startsWith(q)
            }
        } else {
            // Default sorting: Favorite/Frequency first, then alphabetical label
            filtered = filtered.sortedWith(
                compareByDescending<InstalledApp> { it.isFavorite }
                    .thenByDescending { it.clickCount }
                    .thenBy { it.label.lowercase() }
            )
        }

        filtered
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        loadInstalledApps()
        loadLocalSettings()
    }

    fun loadInstalledApps() {
        viewModelScope.launch {
            _isLoading.value = true
            withContext(Dispatchers.IO) {
                try {
                    val pm = context.packageManager
                    val intent = Intent(Intent.ACTION_MAIN, null).apply {
                        addCategory(Intent.CATEGORY_LAUNCHER)
                    }
                    val resolveInfos = pm.queryIntentActivities(intent, 0)
                    
                    val apps = resolveInfos.mapNotNull { info ->
                        val pName = info.activityInfo.packageName
                        val label = info.loadLabel(pm).toString()
                        
                        // Prevent duplicates and mock launch filter
                        if (pName == context.packageName) null 
                        else {
                            val computedCategory = categorizeApp(label, pName)
                            InstalledApp(
                                packageName = pName,
                                label = label,
                                category = computedCategory,
                                isSystem = (info.activityInfo.applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0
                            )
                        }
                    }.distinctBy { it.packageName }

                    // Sync stats inside DB for persistent storage
                    val currentStatsInDb = appStatsDao.getAllStatsList().associateBy { it.packageName }
                    val newlyInstalled = apps.filter { !currentStatsInDb.containsKey(it.packageName) }.map {
                        AppStats(packageName = it.packageName, label = it.label)
                    }

                    if (newlyInstalled.isNotEmpty()) {
                        appStatsDao.insertIgnore(newlyInstalled)
                    }

                    // For debug / empty systems (headless setups/nodes, some emulators with few/no apps)
                    // inject premium pre-populated mock launcher targets so user can fully test!
                    val finalApps = if (apps.isEmpty()) {
                        generateMockData()
                    } else {
                        apps
                    }

                    _scannedApps.value = finalApps
                } catch (e: Exception) {
                    Log.e("MainViewModel", "Scanning apps error: ${e.localizedMessage}")
                    _scannedApps.value = generateMockData()
                } finally {
                    _isLoading.value = false
                }
            }
        }
    }

    private fun generateMockData(): List<InstalledApp> {
        val mockItems = listOf(
            InstalledApp("com.android.chrome", "Chrome", "Browser"),
            InstalledApp("com.facebook.katana", "Facebook", "Social"),
            InstalledApp("com.google.android.gm", "Gmail", "Productivity"),
            InstalledApp("com.instagram.android", "Instagram", "Social"),
            InstalledApp("com.microsoft.vscode", "VS Code", "Coding"),
            InstalledApp("com.openai.chatgpt", "ChatGPT", "Productivity"),
            InstalledApp("com.spotify.music", "Spotify", "Media"),
            InstalledApp("com.netflix.mediaclient", "Netflix", "Media"),
            InstalledApp("com.whatsapp", "WhatsApp", "Social"),
            InstalledApp("com.android.calculator2", "Calculator", "Utilities"),
            InstalledApp("com.android.deskclock", "Clock", "Utilities"),
            InstalledApp("com.supercell.clashofclans", "Clash of Clans", "Games"),
            InstalledApp("com.paypal.android.p2pmobile", "PayPal", "Finance")
        )

        // Seed DB for mocks
        viewModelScope.launch(Dispatchers.IO) {
            val dbMocks = mockItems.map { AppStats(it.packageName, it.label) }
            appStatsDao.insertIgnore(dbMocks)
        }

        return mockItems
    }

    private fun categorizeApp(label: String, packageName: String): String {
        val lowerLabel = label.lowercase()
        val lowerPkg = packageName.lowercase()

        return when {
            lowerLabel.contains("chat") || lowerLabel.contains("messenger") || lowerLabel.contains("facebook") ||
            lowerLabel.contains("instagram") || lowerLabel.contains("snapchat") || lowerLabel.contains("twitter") ||
            lowerLabel.contains("line") || lowerLabel.contains("whatsapp") || lowerLabel.contains("wechat") ||
            lowerLabel.contains("viber") || lowerLabel.contains("telegram") || lowerLabel.contains("discord") ||
            lowerLabel.contains("social") || lowerPkg.contains("social") || lowerPkg.contains("sns") ||
            lowerPkg.contains("messenger") || lowerPkg.contains("facebook") || lowerPkg.contains("instagram") ||
            lowerPkg.contains("whatsapp") || lowerPkg.contains("telegram") || lowerPkg.contains("twitter") -> "Social"

            lowerLabel.contains("code") || lowerLabel.contains("vs code") || lowerLabel.contains("terminal") ||
            lowerLabel.contains("github") || lowerLabel.contains("compiler") || lowerLabel.contains("ide") ||
            lowerLabel.contains("studio") || lowerLabel.contains("repl") || lowerLabel.contains("python") ||
            lowerLabel.contains("java") || lowerLabel.contains("html") || lowerLabel.contains("gitlab") ||
            lowerLabel.contains("git") || lowerPkg.contains("code") || lowerPkg.contains("terminal") ||
            lowerPkg.contains("github") || lowerPkg.contains("studio") -> "Coding"

            lowerLabel.contains("chrome") || lowerLabel.contains("firefox") || lowerLabel.contains("opera") ||
            lowerLabel.contains("browser") || lowerLabel.contains("safari") || lowerLabel.contains("edge") ||
            lowerLabel.contains("internet") || lowerLabel.contains("web") || lowerPkg.contains("browser") ||
            lowerPkg.contains("chrome") || lowerPkg.contains("firefox") || lowerPkg.contains("opera") -> "Browser"

            lowerLabel.contains("youtube") || lowerLabel.contains("netflix") || lowerLabel.contains("spotify") ||
            lowerLabel.contains("music") || lowerLabel.contains("video") || lowerLabel.contains("player") ||
            lowerLabel.contains("tiktok") || lowerLabel.contains("disney") || lowerLabel.contains("hulu") ||
            lowerLabel.contains("prime") || lowerLabel.contains("podcast") || lowerLabel.contains("gallery") ||
            lowerLabel.contains("photo") || lowerLabel.contains("camera") || lowerPkg.contains("youtube") ||
            lowerPkg.contains("spotify") || lowerPkg.contains("player") || lowerPkg.contains("video") ||
            lowerPkg.contains("music") || lowerPkg.contains("gallery") || lowerPkg.contains("camera") -> "Media"

            lowerLabel.contains("pay") || lowerLabel.contains("bank") || lowerLabel.contains("wallet") ||
            lowerLabel.contains("finance") || lowerLabel.contains("crypto") || lowerLabel.contains("cash") ||
            lowerLabel.contains("invest") || lowerLabel.contains("portfolio") || lowerLabel.contains("stock") ||
            lowerLabel.contains("paypal") || lowerLabel.contains("venmo") || lowerPkg.contains("bank") ||
            lowerPkg.contains("wallet") || lowerPkg.contains("finance") || lowerPkg.contains("paypal") -> "Finance"

            lowerLabel.contains("game") || lowerLabel.contains("play") || lowerLabel.contains("arcade") ||
            lowerLabel.contains("puzzle") || lowerLabel.contains("chess") || lowerLabel.contains("subway") ||
            lowerLabel.contains("angry") || lowerLabel.contains("pubg") || lowerLabel.contains("candy") ||
            lowerLabel.contains("fifa") || lowerLabel.contains("mine") || lowerLabel.contains("clash") ||
            lowerPkg.contains("game") || lowerPkg.contains("arcade") || lowerPkg.contains("xbox") -> "Games"

            lowerLabel.contains("gmail") || lowerLabel.contains("email") || lowerLabel.contains("mail") ||
            lowerLabel.contains("doc") || lowerLabel.contains("drive") || lowerLabel.contains("sheet") ||
            lowerLabel.contains("slide") || lowerLabel.contains("office") || lowerLabel.contains("word") ||
            lowerLabel.contains("excel") || lowerLabel.contains("pdf") || lowerLabel.contains("calendar") ||
            lowerLabel.contains("note") || lowerLabel.contains("keep") || lowerLabel.contains("notion") ||
            lowerLabel.contains("todo") || lowerLabel.contains("task") || lowerLabel.contains("workspace") ||
            lowerLabel.contains("assistant") || lowerLabel.contains("ai") || lowerLabel.contains("chatgpt") ||
            lowerPkg.contains("gmail") || lowerPkg.contains("email") || lowerPkg.contains("calendar") ||
            lowerPkg.contains("notion") || lowerPkg.contains("productivity") || lowerPkg.contains("todo") -> "Productivity"

            else -> "Utilities"
        }
    }

    // Command Parser & Matcher
    fun handleVoiceCommand(rawText: String) {
        val command = rawText.trim()
        if (command.isEmpty()) return

        val normalized = command.lowercase().trim()
        
        // Remove common trigger words
        var cleanTarget = normalized
        val launchPrefixes = listOf(
            "open the app", "open app", "launch app", "launch", "open", "run", "start", "go to", "please open"
        )
        for (prefix in launchPrefixes) {
            if (normalized.startsWith(prefix)) {
                cleanTarget = normalized.substring(prefix.length).trim()
                break
            }
        }

        viewModelScope.launch {
            // Wait for apps to load if list is empty
            val apps = appList.value
            if (apps.isEmpty()) {
                withContext(Dispatchers.IO) {
                    recordCommandHistory(command, "FAILED", null)
                }
                return@launch
            }

            // Find best fit app
            var bestMatch: InstalledApp? = null
            
            // 1. Exact match on clean target label
            bestMatch = apps.find { it.label.lowercase() == cleanTarget }

            // 2. Contains match
            if (bestMatch == null) {
                bestMatch = apps.find { 
                    it.label.lowercase().contains(cleanTarget) || cleanTarget.contains(it.label.lowercase())
                }
            }

            // 3. Package name keyword check
            if (bestMatch == null) {
                bestMatch = apps.find { it.packageName.lowercase().contains(cleanTarget) }
            }

            // 4. Fuzzy Levenshtein Distance
            if (bestMatch == null && cleanTarget.length >= 3) {
                val matches = apps.map { app ->
                    val dist = getLevenshteinDistance(cleanTarget, app.label.lowercase())
                    app to dist
                }.sortedBy { it.second }
                
                // If character difference exceeds 40% of the target length, do not auto-match
                val matchCandidate = matches.firstOrNull()
                if (matchCandidate != null && matchCandidate.second <= (cleanTarget.length * 0.4).coerceAtLeast(2.0)) {
                    bestMatch = matchCandidate.first
                }
            }

            if (bestMatch != null) {
                withContext(Dispatchers.IO) {
                    recordCommandHistory(command, "LAUNCHED", bestMatch?.label)
                    // Register launch
                    appStatsDao.insertOrReplace(
                        AppStats(
                            packageName = bestMatch!!.packageName,
                            label = bestMatch!!.label,
                            isFavorite = bestMatch!!.isFavorite,
                            clickCount = bestMatch!!.clickCount + 1,
                            lastLaunched = System.currentTimeMillis()
                        )
                    )
                }
                launchApp(bestMatch!!.packageName)
            } else {
                withContext(Dispatchers.IO) {
                    recordCommandHistory(command, "NOT_FOUND", null)
                }
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "No match found for: '$cleanTarget'", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun getLevenshteinDistance(s1: String, s2: String): Int {
        val dp = Array(s1.length + 1) { IntArray(s2.length + 1) }
        for (i in 0..s1.length) dp[i][0] = i
        for (j in 0..s2.length) dp[0][j] = j
        for (i in 1..s1.length) {
            for (j in 1..s2.length) {
                val cost = if (s1[i - 1] == s2[j - 1]) 0 else 1
                dp[i][j] = minOf(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost)
            }
        }
        return dp[s1.length][s2.length]
    }

    private suspend fun recordCommandHistory(command: String, status: String, appName: String?) {
        commandDao.insertCommand(
            CommandHistory(
                command = command,
                timestamp = System.currentTimeMillis(),
                status = status,
                launchedAppName = appName
            )
        )
    }

    fun launchApp(packageName: String) {
        viewModelScope.launch(Dispatchers.Main) {
            try {
                // If it's a simulated mock package (not really on device but in list)
                // just show launch toast simulation
                val pm = context.packageManager
                val intent = pm.getLaunchIntentForPackage(packageName)
                if (intent != null) {
                    // Actual launch
                    context.startActivity(intent)
                    Toast.makeText(context, "Launching ${pm.getApplicationLabel(pm.getApplicationInfo(packageName, 0))}...", Toast.LENGTH_SHORT).show()
                    
                    // Increment click count and update lastLaunch in background Room DB
                    viewModelScope.launch(Dispatchers.IO) {
                        val stats = appStatsDao.getStats(packageName)
                        if (stats != null) {
                            appStatsDao.recordLaunch(packageName, System.currentTimeMillis())
                        } else {
                            val scanned = _scannedApps.value.find { it.packageName == packageName }
                            if (scanned != null) {
                                appStatsDao.insertOrReplace(
                                    AppStats(
                                        packageName = packageName,
                                        label = scanned.label,
                                        clickCount = 1,
                                        lastLaunched = System.currentTimeMillis()
                                    )
                                )
                            }
                        }
                    }
                } else {
                    // Fallback simulated app screen overlay
                    Toast.makeText(context, "Simulating launch of: $packageName", Toast.LENGTH_SHORT).show()
                    viewModelScope.launch(Dispatchers.IO) {
                        appStatsDao.recordLaunch(packageName, System.currentTimeMillis())
                    }
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Simulating launch of: $packageName", Toast.LENGTH_SHORT).show()
                viewModelScope.launch(Dispatchers.IO) {
                    appStatsDao.recordLaunch(packageName, System.currentTimeMillis())
                }
            }
        }
    }

    // Toggle Favorite
    fun toggleFavorite(app: InstalledApp) {
        viewModelScope.launch(Dispatchers.IO) {
            val stats = appStatsDao.getStats(app.packageName)
            if (stats != null) {
                appStatsDao.updateFavorite(app.packageName, !app.isFavorite)
            } else {
                appStatsDao.insertOrReplace(
                    AppStats(
                        packageName = app.packageName,
                        label = app.label,
                        isFavorite = !app.isFavorite
                    )
                )
            }
        }
    }

    // Override Category
    fun updateAppCategory(packageName: String, category: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val stats = appStatsDao.getStats(packageName)
            if (stats != null) {
                appStatsDao.updateCategoryOverride(packageName, category)
            } else {
                val scanned = _scannedApps.value.find { it.packageName == packageName }
                appStatsDao.insertOrReplace(
                    AppStats(
                        packageName = packageName,
                        label = scanned?.label ?: "Unknown",
                        categoryOverride = category
                    )
                )
            }
        }
    }

    fun setCategoryFilter(category: String) {
        _selectedCategory.value = category
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun clearHistory() {
        viewModelScope.launch(Dispatchers.IO) {
            commandDao.clearHistory()
        }
    }

    // Settings actions
    fun setVoiceSensitivity(value: Float) {
        _voiceSensitivity.value = value
        saveLocalSetting("sensitivity", value.toString())
    }

    fun toggleDarkMode() {
        _isDarkMode.value = !_isDarkMode.value
        saveLocalSetting("dark_mode", _isDarkMode.value.toString())
    }

    fun setLanguage(lang: String) {
        _selectedLanguage.value = lang
        saveLocalSetting("language", lang)
    }

    fun toggleDockService() {
        _isDockServiceEnabled.value = !_isDockServiceEnabled.value
        saveLocalSetting("dock_service", _isDockServiceEnabled.value.toString())
    }

    fun toggleBatteryOptimization() {
        _isBatteryOptimizationIgnored.value = !_isBatteryOptimizationIgnored.value
        saveLocalSetting("battery_opt", _isBatteryOptimizationIgnored.value.toString())
    }

    private fun loadLocalSettings() {
        viewModelScope.launch(Dispatchers.IO) {
            val sharedPref = context.getSharedPreferences("voicedock_prefs", Context.MODE_PRIVATE)
            _voiceSensitivity.value = sharedPref.getFloat("sensitivity", 0.8f)
            _isDarkMode.value = sharedPref.getBoolean("dark_mode", true)
            _selectedLanguage.value = sharedPref.getString("language", "en-US") ?: "en-US"
            _isDockServiceEnabled.value = sharedPref.getBoolean("dock_service", true)
            _isBatteryOptimizationIgnored.value = sharedPref.getBoolean("battery_opt", false)
        }
    }

    private fun saveLocalSetting(key: String, value: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val sharedPref = context.getSharedPreferences("voicedock_prefs", Context.MODE_PRIVATE)
            with(sharedPref.edit()) {
                when (key) {
                    "sensitivity" -> putFloat(key, value.toFloat())
                    "dark_mode" -> putBoolean(key, value.toBoolean())
                    "dock_service" -> putBoolean(key, value.toBoolean())
                    "battery_opt" -> putBoolean(key, value.toBoolean())
                    else -> putString(key, value)
                }
                apply()
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        speechManager.destroy()
    }
}
