package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CommandDao {
    @Query("SELECT * FROM command_history ORDER BY timestamp DESC LIMIT 50")
    fun getRecentHistoryFlow(): Flow<List<CommandHistory>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCommand(history: CommandHistory)

    @Query("DELETE FROM command_history")
    suspend fun clearHistory()
}
