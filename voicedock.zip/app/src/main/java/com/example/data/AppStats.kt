package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "app_stats")
data class AppStats(
    @PrimaryKey val packageName: String,
    val label: String,
    val isFavorite: Boolean = false,
    val clickCount: Int = 0,
    val lastLaunched: Long = 0L,
    val categoryOverride: String? = null
)
