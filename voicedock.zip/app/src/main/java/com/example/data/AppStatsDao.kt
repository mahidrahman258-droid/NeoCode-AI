package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AppStatsDao {
    @Query("SELECT * FROM app_stats")
    fun getAllStatsFlow(): Flow<List<AppStats>>

    @Query("SELECT * FROM app_stats")
    suspend fun getAllStatsList(): List<AppStats>

    @Query("SELECT * FROM app_stats WHERE packageName = :pName LIMIT 1")
    suspend fun getStats(pName: String): AppStats?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrReplace(stats: AppStats)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIgnore(stats: List<AppStats>)

    @Query("UPDATE app_stats SET isFavorite = :isFav WHERE packageName = :pName")
    suspend fun updateFavorite(pName: String, isFav: Boolean)

    @Query("UPDATE app_stats SET clickCount = clickCount + 1, lastLaunched = :timestamp WHERE packageName = :pName")
    suspend fun recordLaunch(pName: String, timestamp: Long)

    @Query("UPDATE app_stats SET categoryOverride = :category WHERE packageName = :pName")
    suspend fun updateCategoryOverride(pName: String, category: String?)

    @Delete
    suspend fun delete(stats: AppStats)
}
