package com.example.ui.screens

import android.content.Context
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.*
import com.example.viewmodel.InstalledApp
import com.example.viewmodel.MainViewModel

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    onNavigateToSettings: () -> Unit
) {
    val context = LocalContext.current
    val appList by viewModel.appList.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()

    // Speech states
    val isListening by viewModel.speechManager.isListening.collectAsState()
    val partialText by viewModel.speechManager.partialText.collectAsState()
    val finalText by viewModel.speechManager.finalText.collectAsState()
    val soundVolume by viewModel.speechManager.soundVolume.collectAsState()
    val voiceError by viewModel.speechManager.error.collectAsState()

    var showHistoryPanel by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberDark)
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Upper Content section taking remaining space
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp)
            ) {
                // 1. BRAND HEADER & ACTION BAR
                HeaderBar(
                    onSettingsClick = onNavigateToSettings,
                    onHistoryToggle = { showHistoryPanel = !showHistoryPanel },
                    isHistoryActive = showHistoryPanel
                )

                // 2. SEARCH UNIT
                ModernSearchBar(
                    query = searchQuery,
                    onQueryChange = { viewModel.setSearchQuery(it) }
                )

                Spacer(modifier = Modifier.height(14.dp))

                // 3. CATEGORIES HORIZONTAL NAVIGATION
                CategoryRowChooser(
                    categories = viewModel.categoriesList,
                    selected = selectedCategory,
                    onSelect = { viewModel.setCategoryFilter(it) }
                )

                Spacer(modifier = Modifier.height(14.dp))

                // 4. MAIN APP CONTENT PANEL OR SEARCH HISTORY
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    if (isLoading) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = CyberNeonBlue)
                        }
                    } else if (appList.isEmpty()) {
                        EmptyAppsPlaceHolder(
                            query = searchQuery,
                            category = selectedCategory,
                            onReset = {
                                viewModel.setCategoryFilter("All")
                                viewModel.setSearchQuery("")
                            }
                        )
                    } else {
                        AppsGrid(
                            apps = appList,
                            onAppClick = { viewModel.launchApp(it.packageName) },
                            onFavoriteToggle = { viewModel.toggleFavorite(it) },
                            onCategoryEdit = { pName, categ -> viewModel.updateAppCategory(pName, categ) },
                            viewModel = viewModel
                        )
                    }

                    // COLLAPSIBLE HISTORY OVERLAY
                    androidx.compose.animation.AnimatedVisibility(
                        visible = showHistoryPanel,
                        enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
                        exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.TopCenter)
                            .background(CyberDark.copy(alpha = 0.95f))
                    ) {
                        CommandHistoryPanel(viewModel = viewModel, onClose = { showHistoryPanel = false })
                    }
                }
            }

            // 5. PERSISTENT MINIMALIST VOICE DOCK PANEL (Match HTML perfectly)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0A0A0A))
                    .border(
                        width = 1.dp,
                        color = Color.White.copy(alpha = 0.1f),
                        shape = androidx.compose.ui.graphics.RectangleShape
                    )
                    .padding(top = 16.dp, bottom = 28.dp)
                    .navigationBarsPadding(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Wave Visualizer (Dynamic if listening, subtle resting flow if idle)
                VoiceWaveform(
                    amplitude = if (isListening) soundVolume else 0.12f,
                    isActive = isListening,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(30.dp)
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Main Command Trigger Button
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.testTag("floating_mic_button")
                ) {
                    // Neon glow layer
                    Box(
                        modifier = Modifier
                            .size(70.dp)
                            .blur(20.dp)
                            .background(CyberNeonBlue.copy(alpha = 0.2f), CircleShape)
                    )

                    // High-precision circular trigger action button
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(68.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(CyberNeonBlue, Color(0xFF0096B8))
                                )
                            )
                            .clickable {
                                if (isListening) {
                                    viewModel.speechManager.stopListening()
                                } else {
                                    viewModel.speechManager.startListening { textResult ->
                                        viewModel.handleVoiceCommand(textResult)
                                    }
                                }
                            }
                    ) {
                        Icon(
                            imageVector = if (isListening) Icons.Default.MicOff else Icons.Default.Mic,
                            contentDescription = "Microphone Trigger",
                            tint = Color.Black,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Speech dynamic hint/transcription overlay label
                Text(
                    text = when {
                        finalText.isNotEmpty() -> "\"$finalText\""
                        partialText.isNotEmpty() -> "\"$partialText\""
                        else -> "\"Open Chrome\""
                    },
                    color = CyberNeonBlue,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp,
                    style = androidx.compose.ui.text.TextStyle(fontStyle = androidx.compose.ui.text.font.FontStyle.Italic),
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }
        }

        // 6. VOICE CONTROL SCREEN OVERLAY
        androidx.compose.animation.AnimatedVisibility(
            visible = isListening || !finalText.isEmpty() && isListening,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically(),
            modifier = Modifier.fillMaxSize()
        ) {
            VoiceAssistantInteractionSheet(
                isListening = isListening,
                partialText = partialText,
                finalText = finalText,
                volume = soundVolume,
                errorMsg = voiceError,
                onClose = {
                    viewModel.speechManager.stopListening()
                },
                onPreconfiguredTrigger = { cleanCommand ->
                    viewModel.speechManager.stopListening()
                    viewModel.handleVoiceCommand(cleanCommand)
                }
            )
        }
    }
}

@Composable
fun HeaderBar(
    onSettingsClick: () -> Unit,
    onHistoryToggle: () -> Unit,
    isHistoryActive: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "VOICE",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "DOCK",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = CyberNeonBlue,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.width(6.dp))
                // Tiny glowing state indicator
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .background(CyberNeonBlue, CircleShape)
                        .blur(3.dp)
                )
            }
            Text(
                "Futuristic Application Organizer",
                fontSize = 11.sp,
                color = CyberMuted,
                fontWeight = FontWeight.Medium
            )
        }

        // Command history logs toggler
        IconButton(
            onClick = onHistoryToggle,
            modifier = Modifier.background(
                if (isHistoryActive) CyberNeonBlue.copy(alpha = 0.15f) else Color.Transparent,
                CircleShape
            ).border(0.5.dp, if (isHistoryActive) CyberNeonBlue else Color.Transparent, CircleShape)
        ) {
            Icon(
                imageVector = Icons.Default.History,
                contentDescription = "Logs",
                tint = if (isHistoryActive) CyberNeonBlue else Color.White
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        // Settings toggler
        IconButton(
            onClick = onSettingsClick,
            modifier = Modifier.border(1.dp, Color.White.copy(alpha = 0.08f), CircleShape)
        ) {
            Icon(
                imageVector = Icons.Default.Settings,
                contentDescription = "Settings",
                tint = Color.White
            )
        }
    }
}

@Composable
fun ModernSearchBar(
    query: String,
    onQueryChange: (String) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(CyberCard)
            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(12.dp)),
        contentAlignment = Alignment.CenterStart
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Search,
                contentDescription = "Search",
                tint = CyberMuted,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            TextField(
                value = query,
                onValueChange = onQueryChange,
                placeholder = { 
                    Text(
                        "Search apps or voice prompts...", 
                        color = CyberMuted, 
                        fontSize = 14.sp
                    ) 
                },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    disabledIndicatorColor = Color.Transparent,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                modifier = Modifier
                    .weight(1f)
                    .testTag("app_search_input")
            )
            if (query.isNotEmpty()) {
                IconButton(onClick = { onQueryChange("") }) {
                    Icon(
                        imageVector = Icons.Default.Clear,
                        contentDescription = "Clear",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun CategoryRowChooser(
    categories: List<String>,
    selected: String,
    onSelect: (String) -> Unit
) {
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
    ) {
        items(categories) { category ->
            val isSelected = category == selected

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(30.dp))
                    .background(
                        if (isSelected) CyberNeonBlue else Color.White.copy(alpha = 0.05f)
                    )
                    .border(
                        width = 1.dp,
                        color = if (isSelected) Color.Transparent else Color.White.copy(alpha = 0.10f),
                        shape = RoundedCornerShape(30.dp)
                    )
                    .clickable { onSelect(category) }
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text(
                    text = category,
                    color = if (isSelected) Color.Black else Color.White.copy(alpha = 0.7f),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun AppsGrid(
    apps: List<InstalledApp>,
    onAppClick: (InstalledApp) -> Unit,
    onFavoriteToggle: (InstalledApp) -> Unit,
    onCategoryEdit: (String, String) -> Unit,
    viewModel: MainViewModel
) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 100.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 90.dp, top = 4.dp)
    ) {
        items(apps, key = { it.packageName }) { app ->
            AppGridCard(
                app = app,
                onClick = { onAppClick(app) },
                onFavoriteToggle = { onFavoriteToggle(app) },
                onCategorySelect = { categ -> onCategoryEdit(app.packageName, categ) },
                categoriesList = viewModel.categoriesList.filter { it != "All" && it != "Favorites" }
            )
        }
    }
}

@Composable
fun AppGridCard(
    app: InstalledApp,
    onClick: () -> Unit,
    onFavoriteToggle: () -> Unit,
    onCategorySelect: (String) -> Unit,
    categoriesList: List<String>
) {
    var showMenu by remember { mutableStateOf(false) }
    val context = LocalContext.current

    // Category specific accent border code
    val neonAccent = when (app.category) {
        "Social" -> CyberNeonGreen
        "Productivity" -> CyberNeonBlue
        "Coding" -> CyberNeonBlue
        "Browser" -> CyberNeonGreen
        "Media" -> CyberNeonPink
        "Finance" -> CyberNeonGreen
        "Games" -> CyberNeonPink
        else -> CyberNeonBlue
    }

    Box(
        modifier = Modifier
            .testTag("app_item_${app.packageName}")
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF1E1E1E), Color(0xFF121212))
                )
            )
            .border(
                0.5.dp, 
                if (app.isFavorite) CyberNeonBlue.copy(alpha = 0.5f) else Color.White.copy(alpha = 0.08f), 
                RoundedCornerShape(20.dp)
            )
            .clickable(onClick = onClick)
            .padding(12.dp),
        contentAlignment = Alignment.TopEnd
    ) {
        // App Core Body Column
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            // Visual App Avatar Icon
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(54.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xFF252525), Color(0xFF151515))
                        )
                    )
                    .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(16.dp))
            ) {
                // Read local actual package icon dynamically
                val pm = context.packageManager
                val iconDrawable = remember(app.packageName) {
                    try {
                        pm.getApplicationIcon(app.packageName)
                    } catch (e: Exception) {
                        null
                    }
                }

                if (iconDrawable != null) {
                    // Render android native apps
                    androidx.compose.foundation.Image(
                        painter = rememberDrawablePainter(iconDrawable),
                        contentDescription = app.label,
                        modifier = Modifier.size(36.dp)
                    )
                } else {
                    // Sleek geometric visual falling initials placeholder
                    Text(
                        text = app.label.take(1).uppercase(),
                        fontWeight = FontWeight.Bold,
                        color = CyberNeonBlue,
                        fontSize = 18.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Label
            Text(
                text = app.label,
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                fontFamily = FontFamily.SansSerif
            )
            
            // App Type details tag
            Text(
                text = app.category,
                color = CyberNeonBlue.copy(alpha = 0.7f),
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp,
                modifier = Modifier.padding(top = 2.dp)
            )

            // Click launch frequencies indices
            if (app.clickCount > 0) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Insights,
                        contentDescription = null,
                        tint = CyberMuted,
                        modifier = Modifier.size(10.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "${app.clickCount} runs",
                        color = CyberMuted,
                        fontSize = 9.sp
                    )
                }
            }
        }

        // Top Actions Bar (Favorite toggle and context catalog categorizer option)
        Row(
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box {
                Icon(
                    imageVector = if (app.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = "Fav",
                    tint = if (app.isFavorite) CyberNeonPink else CyberMuted.copy(alpha = 0.3f),
                    modifier = Modifier
                        .size(16.dp)
                        .clickable { onFavoriteToggle() }
                )
            }
            Spacer(modifier = Modifier.width(6.dp))
            Box {
                Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = "Menu",
                    tint = CyberMuted.copy(alpha = 0.5f),
                    modifier = Modifier
                        .size(16.dp)
                        .clickable { showMenu = true }
                )
                DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = { showMenu = false },
                    modifier = Modifier
                        .background(CyberCard)
                        .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
                ) {
                    Text(
                        "Change Category",
                        color = CyberMuted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                    categoriesList.forEach { categ ->
                        DropdownMenuItem(
                            text = { 
                                Text(
                                    text = categ, 
                                    color = if (app.category == categ) CyberNeonBlue else Color.White,
                                    fontSize = 13.sp
                                ) 
                            },
                            onClick = {
                                onCategorySelect(categ)
                                showMenu = false
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun EmptyAppsPlaceHolder(
    query: String,
    category: String,
    onReset: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(72.dp)
                .background(CyberNeonPink.copy(alpha = 0.1f), CircleShape)
                .border(2.dp, CyberNeonPink.copy(alpha = 0.3f), CircleShape)
        ) {
            Icon(
                imageVector = Icons.Default.SearchOff,
                contentDescription = null,
                tint = CyberNeonPink,
                modifier = Modifier.size(36.dp)
            )
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "No compatible apps found",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
        )
        Text(
            text = if (query.isNotEmpty()) "No results matching keyword: '$query'" else "Empty category '$category'",
            color = CyberMuted,
            fontSize = 12.sp,
            modifier = Modifier.padding(vertical = 4.dp)
        )
        Spacer(modifier = Modifier.height(12.dp))
        NeonButton(text = "Reset Search Filters", onClick = onReset, color = CyberNeonPink)
    }
}

@Composable
fun CommandHistoryPanel(
    viewModel: MainViewModel,
    onClose: () -> Unit
) {
    val history by viewModel.commandHistory.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = 280.dp)
            .border(1.dp, CyberNeonBlue.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
            .background(CyberCard)
            .padding(14.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                "Voice Command Records",
                color = Color.White,
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.weight(1f)
            )
            Text(
                "Clear",
                color = CyberNeonPink,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .clickable { viewModel.clearHistory() }
                    .padding(4.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Close",
                tint = Color.White,
                modifier = Modifier
                    .size(16.dp)
                    .clickable { onClose() }
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        if (history.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "No historic voice actions recorded yet",
                    color = CyberMuted,
                    fontSize = 11.sp
                )
            }
        } else {
            androidx.compose.foundation.lazy.LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(history) { log ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CyberDark.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (log.status == "LAUNCHED") Icons.Default.CheckCircle else Icons.Default.Cancel,
                            contentDescription = null,
                            tint = if (log.status == "LAUNCHED") CyberNeonGreen else CyberNeonPink,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "\"${log.command}\"",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            if (log.launchedAppName != null) {
                                Text(
                                    text = "Resolved action: Opened ${log.launchedAppName}",
                                    color = CyberNeonBlue,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FloatingMicrophoneButton(
    isListening: Boolean,
    onClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val scale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isListening) 1.2f else 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .testTag("floating_mic_button")
            .size(76.dp)
            .clickable(onClick = onClick)
    ) {
        // Glowing Background pulse aura rings
        Box(
            modifier = Modifier
                .size((64f * scale).dp)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            (if (isListening) CyberNeonPink else CyberNeonBlue).copy(alpha = 0.4f),
                            Color.Transparent
                        )
                    ),
                    CircleShape
                )
        )

        // Core capsule button
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(60.dp)
                .background(
                    Brush.verticalGradient(
                        colors = if (isListening) {
                            listOf(CyberNeonPink, CyberNeonPink.copy(alpha = 0.7f))
                        } else {
                            listOf(CyberNeonBlue, CyberNeonBlue.copy(alpha = 0.7f))
                        }
                    ),
                    CircleShape
                )
                .border(
                    width = 2.dp,
                    color = Color.White.copy(alpha = 0.4f),
                    shape = CircleShape
                )
        ) {
            Icon(
                imageVector = if (isListening) Icons.Default.MicOff else Icons.Default.Mic,
                contentDescription = "Microphone Trigger",
                tint = Color.White,
                modifier = Modifier.size(28.dp)
            )
        }
    }
}

@Composable
fun VoiceAssistantInteractionSheet(
    isListening: Boolean,
    partialText: String,
    finalText: String,
    volume: Float,
    errorMsg: String?,
    onClose: () -> Unit,
    onPreconfiguredTrigger: (String) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberDark.copy(alpha = 0.95f))
            .clickable { onClose() }, // Tap outside to abort
        contentAlignment = Alignment.BottomCenter
    ) {
        // Glass Core Capsule sheet with close trigger click blocker to prevent unwanted drops
        Box(
            modifier = Modifier
                .testTag("voice_assistant_sheet")
                .fillMaxWidth()
                .fillMaxHeight(0.68f)
                .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                .background(CyberCard)
                .border(
                    width = 1.dp,
                    brush = Brush.verticalGradient(
                        listOf(CyberNeonBlue.copy(alpha = 0.4f), Color.Transparent)
                    ),
                    shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
                )
                .clickable(enabled = true, onClick = {}), // Block taps falling through
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp)
            ) {
                // Drag top pill handle
                Box(
                    modifier = Modifier
                        .width(42.dp)
                        .height(4.dp)
                        .background(CyberMuted.copy(alpha = 0.3f), CircleShape)
                )
                Spacer(modifier = Modifier.height(20.dp))

                // Glow Visual Header Title Area
                Text(
                    text = if (isListening) "VOICEDOCK LISTENING" else "COMMAND RESOLVING",
                    fontSize = 12.sp,
                    color = if (isListening) CyberNeonBlue else CyberNeonGreen,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 2.sp
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Waves component
                VoiceWaveform(
                    amplitude = volume,
                    isActive = isListening,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Transcriptions Segment
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        if (errorMsg != null) {
                            Text(
                                text = errorMsg,
                                color = CyberNeonPink,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(16.dp)
                            )
                        } else {
                            val displayText = when {
                                finalText.isNotEmpty() -> "\"$finalText\""
                                partialText.isNotEmpty() -> "\"$partialText\""
                                else -> "Speak now: \"Open Chrome\", \"Open Gmail\"..."
                            }
                            Text(
                                text = displayText,
                                color = if (finalText.isNotEmpty()) CyberNeonGreen else Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 16.dp),
                                fontFamily = FontFamily.SansSerif,
                                maxLines = 2
                            )
                        }
                    }
                }

                // SIMULATOR PANEL FOR COMPILER/EMULATOR USERS
                Text(
                    text = "EMULATOR QUICK TRIGGER ACTIONS (TAP TO TEST)",
                    fontSize = 10.sp,
                    color = CyberMuted,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(bottom = 10.dp)
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                ) {
                    val preconfigured = listOf(
                        "Open Chrome" to Icons.Default.Public,
                        "Open Gmail" to Icons.Default.Email,
                        "Open VS Code" to Icons.Default.Source,
                        "Open ChatGPT" to Icons.Default.Code,
                        "Open Spotify" to Icons.Default.MusicNote,
                        "Open Facebook" to Icons.Default.People
                    )
                    items(preconfigured) { (label, icon) ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(CyberDark)
                                .border(0.5.dp, CyberNeonBlue.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                .clickable { onPreconfiguredTrigger(label) }
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Icon(imageVector = icon, contentDescription = null, tint = CyberNeonBlue, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }

                // Explicit manual close button
                NeonButton(
                    text = "CANCEL LISTENING",
                    onClick = onClose,
                    color = CyberNeonPink,
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                )
            }
        }
    }
}

@Composable
fun rememberDrawablePainter(drawable: Drawable): Painter {
    return remember(drawable) {
        val bitmap = if (drawable is BitmapDrawable) {
            drawable.bitmap
        } else {
            val width = drawable.intrinsicWidth.coerceAtLeast(1)
            val height = drawable.intrinsicHeight.coerceAtLeast(1)
            val bmp = android.graphics.Bitmap.createBitmap(width, height, android.graphics.Bitmap.Config.ARGB_8888)
            val canvas = android.graphics.Canvas(bmp)
            drawable.setBounds(0, 0, canvas.width, canvas.height)
            drawable.draw(canvas)
            bmp
        }
        BitmapPainter(bitmap.asImageBitmap())
    }
}
