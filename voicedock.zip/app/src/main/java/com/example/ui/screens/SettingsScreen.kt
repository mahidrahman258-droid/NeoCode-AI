package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.*
import com.example.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val sensitivity by viewModel.voiceSensitivity.collectAsState()
    val isDarkMode by viewModel.isDarkMode.collectAsState()
    val isDockServiceEnabled by viewModel.isDockServiceEnabled.collectAsState()
    val selectedLanguage by viewModel.selectedLanguage.collectAsState()
    val isBatteryOptimized by viewModel.isBatteryOptimizationIgnored.collectAsState()
    
    // Permission simulations for safety on all testing targets
    var micPermissionGranted by remember { mutableStateOf(true) }
    var overlayPermissionGranted by remember { mutableStateOf(false) }
    var notificationPermissionGranted by remember { mutableStateOf(true) }

    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        "VoiceDock Settings", 
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    ) 
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack, 
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = CyberDark,
                    titleContentColor = Color.White
                )
            )
        },
        containerColor = CyberDark
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(CyberDark)
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
                .verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(modifier = Modifier.height(4.dp))

            // SECTION 1: SYSTEM CONTROLS
            Text(
                text = "VOICE ENGINE & CONTROLS",
                fontSize = 12.sp,
                color = CyberNeonBlue,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp
            )

            GlassCard {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Default.VolumeUp,
                        contentDescription = "Sensitivity",
                        tint = CyberNeonBlue,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Speech Sensitivity",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Adjust trigger thresholds: ${(sensitivity * 100).toInt()}%",
                            color = CyberMuted,
                            fontSize = 12.sp
                        )
                        Slider(
                            value = sensitivity,
                            onValueChange = { viewModel.setVoiceSensitivity(it) },
                            colors = SliderDefaults.colors(
                                thumbColor = CyberNeonBlue,
                                activeTrackColor = CyberNeonBlue,
                                inactiveTrackColor = CyberMuted.copy(alpha = 0.3f)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = Color.White.copy(alpha = 0.08f))
                Spacer(modifier = Modifier.height(16.dp))

                SettingsDropdownRow(
                    icon = Icons.Default.Language,
                    title = "Recognition Language",
                    description = "Choose primary microphone format",
                    selectedValue = when (selectedLanguage) {
                        "en-US" -> "English (US)"
                        "es-ES" -> "Spanish (ES)"
                        "fr-FR" -> "French (FR)"
                        "ja-JP" -> "Japanese (JP)"
                        else -> "Mandarin (ZH)"
                    },
                    options = listOf("English (US)", "Spanish (ES)", "French (FR)", "Japanese (JP)", "Mandarin (ZH)"),
                    onSelect = { option ->
                        val code = when (option) {
                            "English (US)" -> "en-US"
                            "Spanish (ES)" -> "es-ES"
                            "French (FR)" -> "fr-FR"
                            "Japanese (JP)" -> "ja-JP"
                            else -> "zh-CN"
                        }
                        viewModel.setLanguage(code)
                    }
                )
            }

            // SECTION 2: PERMISSIONS DASHBOARD
            Text(
                text = "LAUNCHER PERMISSIONS",
                fontSize = 12.sp,
                color = CyberNeonPink,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp
            )

            GlassCard(borderColor = CyberNeonPink.copy(alpha = 0.3f)) {
                PermissionToggleRow(
                    icon = Icons.Default.Mic,
                    title = "Audio Recording permission",
                    description = "Required to convert speech into text commands",
                    isGranted = micPermissionGranted,
                    onToggle = { micPermissionGranted = !micPermissionGranted }
                )

                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = Color.White.copy(alpha = 0.08f))
                Spacer(modifier = Modifier.height(12.dp))

                PermissionToggleRow(
                    icon = Icons.Default.Layers,
                    title = "Screen Overlay overlay permission",
                    description = "Provides floating mic launcher dock on other apps",
                    isGranted = overlayPermissionGranted,
                    onToggle = { overlayPermissionGranted = !overlayPermissionGranted }
                )

                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = Color.White.copy(alpha = 0.08f))
                Spacer(modifier = Modifier.height(12.dp))

                PermissionToggleRow(
                    icon = Icons.Default.Notifications,
                    title = "Persistent notifications widget",
                    description = "Allows locking Dock to notification panel status",
                    isGranted = notificationPermissionGranted,
                    onToggle = { notificationPermissionGranted = !notificationPermissionGranted }
                )
            }

            // SECTION 3: DOCK SYSTEM & BATTERY
            Text(
                text = "DOCK INTELLIGENCE & PERFORMANCE",
                fontSize = 12.sp,
                color = CyberNeonGreen,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp
            )

            GlassCard(borderColor = CyberNeonGreen.copy(alpha = 0.3f)) {
                SettingsSwitchRow(
                    icon = Icons.Default.Speed,
                    title = "Background Dock Quick Access",
                    description = "Keep launcher awake in memory to boot apps with sub-ms speeds",
                    checked = isDockServiceEnabled,
                    onCheckedChange = { viewModel.toggleDockService() }
                )

                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = Color.White.copy(alpha = 0.08f))
                Spacer(modifier = Modifier.height(12.dp))

                SettingsSwitchRow(
                    icon = Icons.Default.BatteryChargingFull,
                    title = "Ignore Battery Optimizations",
                    description = "Prevent Android OS from pausing voice launcher triggers",
                    checked = isBatteryOptimized,
                    onCheckedChange = { viewModel.toggleBatteryOptimization() }
                )
            }

            // SECTION 4: RESET / DEVELOPMENT TOOLS
            Text(
                text = "DATABASE MAINTENANCE",
                fontSize = 12.sp,
                color = CyberMuted,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp
            )

            GlassCard(borderColor = CyberMuted.copy(alpha = 0.3f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.clearHistory() }
                        .padding(vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Clear History",
                        tint = CyberNeonPink,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            text = "Purge Command Database",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Reset all past speech records & matching history logs",
                            color = CyberMuted,
                            fontSize = 12.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = Color.White.copy(alpha = 0.08f))
                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.loadInstalledApps() }
                        .padding(vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Sync Apps",
                        tint = CyberNeonGreen,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            text = "Rescan Native App Packages",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Refresh Android local registries to locate installed apps",
                            color = CyberMuted,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}

@Composable
fun PermissionToggleRow(
    icon: ImageVector,
    title: String,
    description: String,
    isGranted: Boolean,
    onToggle: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onToggle)
            .padding(vertical = 4.dp)
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(40.dp)
                .background(
                    if (isGranted) CyberNeonGreen.copy(alpha = 0.15f) else CyberNeonPink.copy(alpha = 0.15f),
                    CircleShape
                )
                .border(
                    1.dp,
                    if (isGranted) CyberNeonGreen.copy(alpha = 0.4f) else CyberNeonPink.copy(alpha = 0.4f),
                    CircleShape
                )
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isGranted) CyberNeonGreen else CyberNeonPink,
                modifier = Modifier.size(20.dp)
            )
        }

        Spacer(modifier = Modifier.width(16.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = description,
                color = CyberMuted,
                fontSize = 11.sp,
                lineHeight = 15.sp
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        Text(
            text = if (isGranted) "GRANTED" else "DENIED",
            color = if (isGranted) CyberNeonGreen else CyberNeonPink,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
fun SettingsSwitchRow(
    icon: ImageVector,
    title: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = CyberNeonBlue,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = description,
                color = CyberMuted,
                fontSize = 12.sp
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = CyberNeonBlue,
                checkedTrackColor = CyberNeonBlue.copy(alpha = 0.4f),
                uncheckedThumbColor = CyberMuted,
                uncheckedTrackColor = CyberMuted.copy(alpha = 0.15f)
            )
        )
    }
}

@Composable
fun SettingsDropdownRow(
    icon: ImageVector,
    title: String,
    description: String,
    selectedValue: String,
    options: List<String>,
    onSelect: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { expanded = true }
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = CyberNeonBlue,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = description,
                color = CyberMuted,
                fontSize = 12.sp
            )
        }
        Box {
            Text(
                text = selectedValue,
                color = CyberNeonBlue,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false },
                modifier = Modifier.background(CyberCard).border(1.dp, CyberNeonBlue.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
            ) {
                options.forEach { option ->
                    DropdownMenuItem(
                        text = { Text(option, color = Color.White) },
                        onClick = {
                            onSelect(option)
                            expanded = false
                        }
                    )
                }
            }
        }
    }
}
