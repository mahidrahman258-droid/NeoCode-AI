package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import kotlin.math.sin


@Composable
fun VoiceWaveform(
    modifier: Modifier = Modifier,
    amplitude: Float = 0f, // 0.0 to 1.0 (microphone level)
    isActive: Boolean = false
) {
    val infiniteTransition = rememberInfiniteTransition(label = "wave_anim")
    
    // Wave phase animation
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    // Smoothly interpolate current amplitude to avoid jerky motions
    val animAmplitude by animateFloatAsState(
        targetValue = if (isActive) amplitude.coerceIn(0.08f, 1.0f) else 0.02f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "amplitude"
    )

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(100.dp)
    ) {
        val width = size.width
        val height = size.height
        val midY = height / 2f
        
        // Curve parameters (Clean Elegant Monochromatic Waves)
        val waveCount = 3
        val colors = listOf(CyberNeonBlue, CyberNeonBlue.copy(alpha = 0.5f), CyberNeonBlue.copy(alpha = 0.3f))
        val phaseShifts = listOf(0f, 1.2f, 2.4f)
        val frequencies = listOf(2f, 2.8f, 1.6f)
        val opacities = listOf(0.9f, 0.6f, 0.4f)

        for (i in 0 until waveCount) {
            val path = Path()
            val baseShift = phaseShifts[i]
            val freq = frequencies[i]
            val maxAmp = midY * animAmplitude * (1f - (i * 0.15f))
            
            path.moveTo(0f, midY)

            for (x in 0..width.toInt() step 4) {
                val xNorm = x.toFloat() / width
                val angle = (xNorm * Math.PI * 2 * freq) - phase + baseShift
                
                // Fade out amplitude near the left and right edges for a professional organic bubble form
                val envelope = sin(xNorm * Math.PI).toFloat()
                
                val y = midY + (sin(angle).toFloat() * maxAmp * envelope)
                path.lineTo(x.toFloat(), y)
            }

            // Draw with neon drop shadow styling
            drawPath(
                path = path,
                color = colors[i].copy(alpha = opacities[i]),
                style = Stroke(width = if (i == 0) 3.dp.toPx() else 1.5.dp.toPx())
            )
        }
    }
}
