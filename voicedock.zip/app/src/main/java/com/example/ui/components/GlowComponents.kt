package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Cyber / Neon Color Palette (Clean Minimalism Theme)
val CyberDark = Color(0xFF050505)
val CyberCard = Color(0x0DFFFFFF) // Translates to white/5 in the design, on top of #050505
val CyberNeonBlue = Color(0xFF00D1FF) // Clean Minimalism vibrant blue
val CyberNeonPink = Color(0xFFFF007F)
val CyberNeonGreen = Color(0xFF00D2FF).copy(alpha = 0.8f) // Subtle clean green or match blue
val CyberGlass = Color(0x0DFFFFFF)
val CyberMuted = Color(0x66FFFFFF) // Translucent white/40 for crisp minimalist text

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    borderColor: Color = Color.White.copy(alpha = 0.1f), // Clean Minimalism thin subtle border
    content: @Composable ColumnScope.() -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp)) // More rounded, modern look
            .background(Color(0xFF121212).copy(alpha = 0.4f)) // Glass look
            .border(
                width = 1.dp,
                color = borderColor,
                shape = RoundedCornerShape(20.dp)
            )
            .padding(16.dp)
    ) {
        Column {
            content()
        }
    }
}

@Composable
fun NeonButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    color: Color = CyberNeonBlue,
    glow: Boolean = true
) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(
                Brush.horizontalGradient(
                    colors = listOf(
                        color.copy(alpha = 0.15f),
                        color.copy(alpha = 0.05f)
                    )
                )
            )
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        if (glow) {
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .blur(6.dp)
                    .background(color.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
            )
        }
        Text(
            text = text,
            color = Color.White,
            fontSize = 14.sp,
            letterSpacing = 1.sp
        )
    }
}

@Composable
fun GlowingBorder(
    modifier: Modifier = Modifier,
    glowColor: Color = CyberNeonBlue,
    borderRadius: Dp = 16.dp,
    content: @Composable () -> Unit
) {
    Box(modifier = modifier) {
        // Blur background glow layer
        Box(
            modifier = Modifier
                .matchParentSize()
                .blur(8.dp)
                .background(glowColor.copy(alpha = 0.15f), RoundedCornerShape(borderRadius))
        )
        content()
    }
}
